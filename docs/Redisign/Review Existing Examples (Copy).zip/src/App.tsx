import { useState, useEffect, useRef, useCallback, useLayoutEffect } from 'react'

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  bg:   '#06060F',
  s1:   '#0D0D1A',
  s2:   '#141422',
  s3:   '#1B1B2C',
  acc:  '#C9FF47',
  ok:   '#22E87A',
  warn: '#FFAA33',
  err:  '#FF4D70',
  fg:   '#F0F0F8',
  fg2:  '#888898',
  fg3:  '#3E3E50',
  bd:   'rgba(255,255,255,0.07)',
  bd2:  'rgba(255,255,255,0.13)',
}
const bc = (color: string, a: number) => {
  const r = parseInt(color.slice(1, 3), 16)
  const g = parseInt(color.slice(3, 5), 16)
  const b = parseInt(color.slice(5, 7), 16)
  return `rgba(${r},${g},${b},${a})`
}

// ─── ROOT SCREENS ─────────────────────────────────────────────────────────────
type Screen =
  | 'research'
  | 'onboarding'
  | 'home'
  | 'scan'
  | 'equipment'
  | 'exercise'
  | 'workout-player'
  | 'rest-timer'
  | 'workout-done'
  | 'form-check'
  | 'paywall'
  | 'variants'

// ─── SHARED PRIMITIVES ────────────────────────────────────────────────────────
const Label = ({ children, color = C.fg2, mono = false, style }: { children: React.ReactNode; color?: string; mono?: boolean; style?: React.CSSProperties }) => (
  <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color, fontFamily: mono ? 'inherit' : undefined, ...style }}>
    {children}
  </span>
)

const Chip = ({ label, color = C.bd2, text = C.fg2, small = false }: { label: string; color?: string; text?: string; small?: boolean }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', padding: small ? '3px 8px' : '4px 10px', borderRadius: 99, background: color, color: text, fontSize: small ? 11 : 12, fontWeight: 600, whiteSpace: 'nowrap', letterSpacing: '0.02em' }}>
    {label}
  </span>
)

const Btn = ({ label, onClick, variant = 'primary', icon }: { label: string; onClick?: () => void; variant?: 'primary' | 'ghost' | 'outlined'; icon?: string }) => {
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: C.acc, color: '#060F00', fontWeight: 700 },
    ghost: { background: C.s3, color: C.fg, fontWeight: 600 },
    outlined: { background: 'transparent', color: C.fg2, border: `1.5px solid ${C.bd2}`, fontWeight: 600 },
  }
  return (
    <button onClick={onClick} style={{ width: '100%', padding: '15px 20px', borderRadius: 14, border: 'none', cursor: 'pointer', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'opacity 0.15s', ...styles[variant] }}>
      {icon && <span style={{ fontSize: 18 }}>{icon}</span>}{label}
    </button>
  )
}

const Card = ({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{ background: C.s2, borderRadius: 20, border: `1px solid ${C.bd}`, overflow: 'hidden', ...style }}>
    {children}
  </div>
)

// ─── BOTTOM NAV ───────────────────────────────────────────────────────────────
type Tab = 'home' | 'scan' | 'workouts' | 'progress' | 'profile'
const NAV_ITEMS: { id: Tab; icon: string; label: string }[] = [
  { id: 'home',     icon: '⊞', label: 'Главная'   },
  { id: 'scan',     icon: '◎', label: 'Скан'       },
  { id: 'workouts', icon: '◈', label: 'Тренировки' },
  { id: 'progress', icon: '↗', label: 'Прогресс'  },
  { id: 'profile',  icon: '○', label: 'Профиль'   },
]

const BottomNav = ({ active, onTabChange }: { active: Tab; onTabChange: (t: Tab) => void }) => (
  <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 80, background: C.s1, borderTop: `1px solid ${C.bd}`, display: 'flex', alignItems: 'center', paddingBottom: 4, backdropFilter: 'blur(20px)' }}>
    {NAV_ITEMS.map((item) => {
      const isActive = item.id === active
      const isScan   = item.id === 'scan'
      return (
        <button key={item.id} onClick={() => onTabChange(item.id)} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, border: 'none', background: 'none', cursor: 'pointer', padding: '8px 0' }}>
          {isScan ? (
            <div style={{ width: 46, height: 46, borderRadius: '50%', background: isActive ? C.acc : C.s3, border: `2px solid ${isActive ? C.acc : C.bd2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: -18, boxShadow: isActive ? `0 0 20px ${bc(C.acc, 0.4)}` : '0 4px 12px rgba(0,0,0,0.4)' }}>
              <span style={{ fontSize: 20, color: isActive ? '#060F00' : C.fg2 }}>◉</span>
            </div>
          ) : (
            <span style={{ fontSize: 20, color: isActive ? C.acc : C.fg3 }}>{item.icon}</span>
          )}
          <span style={{ fontSize: 10, fontWeight: 600, color: isActive ? (isScan ? C.acc : C.acc) : C.fg3, letterSpacing: '0.04em' }}>{item.label}</span>
        </button>
      )
    })}
  </div>
)

// ══════════════════════════════════════════════════════════════════════════════
// D1 — RESEARCH, AUDIT, IA & DESIGN SYSTEM DIRECTION
// ══════════════════════════════════════════════════════════════════════════════

const AUDIT_PROBLEMS = [
  { text: 'Все функции одинаковыми плитками — нет иерархии', fix: 'Hero-блок + прогрессивное раскрытие' },
  { text: 'Home не отвечает на вопрос «что делать сейчас»', fix: 'Today Workout как единственный primary action' },
  { text: 'Второстепенные блоки сильнее тренировки визуально', fix: 'Строгий Z-order по важности контента' },
  { text: 'Scanner не ощущается главной уникальной функцией', fix: 'Fullscreen camera + glassmorphism, 2-й приоритет на Home' },
  { text: 'Упражнения: мелкие карточки, нет медиа, обрезанный текст', fix: 'Media-first layout с анатомической анимацией' },
  { text: 'Progress: пустые одинаковые tiles без интерпретации', fix: 'Каждый график отвечает на конкретный вопрос' },
  { text: 'AI выглядит как generic chat без контекста', fix: 'Контекстный AI Coach, встроен в каждый флоу' },
  { text: 'Ввод метрик через обычные поля — не premium UX', fix: 'Wheel picker (год), ruler picker (рост/вес)' },
  { text: 'Workout logging плотный и технический', fix: 'Immersive player, одна рука, большие targets' },
  { text: 'Empty / error / permission states не систематизированы', fix: 'Единая система states для каждого feature' },
]

const UX_QUESTIONS = [
  { q: 'Что мне делать сейчас?', where: 'Home' },
  { q: 'Почему именно это рекомендовано?', where: 'Exercise, Plan' },
  { q: 'Как выполнить правильно?', where: 'Exercise, Form Check' },
  { q: 'Как быстро сохранить результат?', where: 'Workout Player' },
  { q: 'Как изменился мой прогресс?', where: 'Progress, Summary' },
  { q: 'Что делать следующим?', where: 'Summary, Home' },
]

const TAKEN = [
  'Один вопрос на экран (onboarding)', 'Wheel/ruler pickers для метрик',
  'Анатомическая карта мышц', 'Media-first карточки упражнений',
  'Hero-блок «Сегодня»', 'Контекстный AI Coach', 'Автотаймер отдыха',
  'Удобный set logger', 'Visual progress comparison', 'Before/after slider',
  'Мягкие contextual reminders', 'Preview плана до аккаунта',
]
const REJECTED = [
  'Countdown timers продаж', 'Scratch cards / скидки', 'Paywall до ценности',
  'BMI как диагноз', 'Body/beauty score', 'Generic AI chat',
  'Автопубликация фото', 'Fake AI analysis', 'Ложная точность сроков',
  'Одинаковые плитки для всех', 'Реклама внутри core flows',
]

const IA_FULL = [
  {
    label: 'Home', color: C.acc,
    subs: ['Greeting', 'Program progress', 'Hero Today Workout', 'Quick Scan card', 'Recovery snapshot', 'Weekly calendar & stats', 'Last achievement', 'Progress photo card*'],
    note: '* только при наличии 2+ фото',
  },
  {
    label: 'Scan', color: '#7C6AFF',
    subs: ['Camera', 'Recognition states', 'Top-3 alternatives', 'Unknown equipment', 'Scan history', 'Saved machine cards'],
  },
  {
    label: 'Workouts', color: '#22CCE2',
    subs: ['Current program', 'Calendar', 'Workout library', 'Exercise library', 'Equipment library', 'Saved workouts', 'Active workout player'],
  },
  {
    label: 'Progress', color: C.ok,
    subs: ['Summary', 'Consistency', 'Volume', 'Key exercise progress', 'Goal progress', 'Muscle load & recovery', 'Measurements', 'Progress Photos', 'Achievements', 'History'],
  },
  {
    label: 'Profile', color: C.warn,
    subs: ['Personal data', 'Goals', 'Units', 'Integrations', 'Notifications', 'Privacy', 'Subscription', 'Help'],
  },
]

const HAPPY_PATH = [
  'First launch', 'Onboarding', 'Body Metrics', 'Generating', 'Plan Preview',
  'Account', 'Home', 'Scan', 'Recognition Result', 'Equipment Page',
  'Exercise Page', 'Workout Player', 'Complete Set', 'Rest Timer',
  'Form Check', 'Workout Summary', 'Progress', 'Add Progress Photo',
  'Add Second Photo', 'Compare', 'Export Preview', 'Home updated',
]

const DESIGN_GATES = [
  { id: 'D1', label: 'Research, Audit, IA & Design System', status: 'done' as const, screens: ['Research', 'Audit', 'IA', 'Token System', 'UX Principles'] },
  { id: 'D2', label: 'Onboarding & Body Metrics', status: 'done' as const, screens: ['Value Prop', 'Goal', 'Level', 'Location', 'Equipment', 'Schedule', 'Injuries', 'Focus', 'Barriers', 'Age', 'Height', 'Weight', 'Target', 'Health Connect', 'Generating', 'Plan Preview', 'Account'] },
  { id: 'D3', label: 'Home & Navigation', status: 'done' as const, screens: ['Home', 'Bottom Nav', 'Recovery', 'Weekly Stats', 'Photo Card'] },
  { id: 'D4', label: 'Scanner & Equipment', status: 'done' as const, screens: ['Camera', 'Analyzing', 'Result Sheet', 'Alternatives', 'Unknown', 'Equipment Page'] },
  { id: 'D5', label: 'Exercise & Workout Player', status: 'done' as const, screens: ['Exercise Page', 'Workout Player', 'Set Logger', 'Rest Timer'] },
  { id: 'D6', label: 'Form Check & Summary', status: 'next' as const, screens: ['Form Check states', 'Skeleton overlay', 'Cues', 'Summary', 'Records', 'Recovery impact'] },
  { id: 'D7', label: 'Progress & Progress Photos', status: 'done' as const, screens: ['Progress screen', 'Photo flow', 'Gallery', 'Compare side-by-side', 'Compare slider', 'Export'] },
  { id: 'D8', label: 'Programs, AI Coach, Profile, Subscription', status: 'pending' as const, screens: ['Programs', 'AI Coach', 'Profile', 'Settings', 'Paywall'] },
  { id: 'D9', label: 'States, Accessibility, Platform, Prototype', status: 'pending' as const, screens: ['Empty states', 'Error states', 'Permission flows', 'Android', 'iOS', 'Light theme', 'End-to-end prototype'] },
]

const TOKEN_COLORS = [
  { token: 'backgroundPrimary',  val: '#06060F', dark: true },
  { token: 'backgroundSecondary',val: '#0D0D1A', dark: true },
  { token: 'surfacePrimary',     val: '#141422', dark: true },
  { token: 'surfaceElevated',    val: '#1B1B2C', dark: true },
  { token: 'surfaceInteractive', val: '#252538', dark: true },
  { token: 'textPrimary',        val: '#F0F0F8', dark: false },
  { token: 'textSecondary',      val: '#888898', dark: false },
  { token: 'textDisabled',       val: '#3E3E50', dark: false },
  { token: 'accentPrimary',      val: '#C9FF47', dark: true },
  { token: 'accentSecondary',    val: '#A8D93A', dark: true },
  { token: 'success',            val: '#22E87A', dark: true },
  { token: 'warning',            val: '#FFAA33', dark: true },
  { token: 'danger',             val: '#FF4D70', dark: true },
  { token: 'outline',            val: 'rgba(255,255,255,0.13)', dark: false },
  { token: 'cameraOverlay',      val: 'rgba(0,0,0,0.55)', dark: false },
  { token: 'poseCorrect',        val: '#22E87A', dark: true },
  { token: 'poseWarning',        val: '#FFAA33', dark: true },
  { token: 'poseError',          val: '#FF4D70', dark: true },
]

const TYPE_SCALE = [
  { role: 'Display',       size: 48, weight: 800, font: 'Barlow Condensed', sample: 'Display' },
  { role: 'H1',            size: 34, weight: 800, font: 'Barlow Condensed', sample: 'H1 — Заголовок' },
  { role: 'H2',            size: 26, weight: 700, font: 'Barlow Condensed', sample: 'H2 — Раздел' },
  { role: 'H3',            size: 20, weight: 700, font: 'Barlow Condensed', sample: 'H3 — Подраздел' },
  { role: 'Title',         size: 16, weight: 600, font: 'Inter',            sample: 'Title — название карточки' },
  { role: 'Body',          size: 15, weight: 400, font: 'Inter',            sample: 'Body — текст инструкции' },
  { role: 'Body Small',    size: 13, weight: 400, font: 'Inter',            sample: 'Body Small — описание' },
  { role: 'Label',         size: 11, weight: 600, font: 'Inter',            sample: 'LABEL · UPPERCASE' },
  { role: 'Caption',       size: 10, weight: 500, font: 'Inter',            sample: 'Caption — meta' },
  { role: 'Numeric Large', size: 40, weight: 800, font: 'monospace',        sample: '01:30' },
  { role: 'Numeric Med',   size: 24, weight: 700, font: 'monospace',        sample: '88.5' },
]

const SPACING = [4, 8, 12, 16, 20, 24, 32, 40, 48]
const RADIUS = [8, 12, 16, 20, 24]

const CORE_COMPONENTS = [
  'Button (primary / ghost / outlined)',
  'Icon Button',
  'Bottom Navigation',
  'Top Bar',
  'Choice Card (single / multi)',
  'Chip (default / accent / danger)',
  'Recommendation Hero',
  'Media Card (exercise)',
  'BodyMetricPicker (wheel / ruler)',
  'Set Logger',
  'Rest Timer',
  'Camera Overlay',
  'Recognition Sheet',
  'AI Insight Card',
  'Progress Card',
  'Progress Photo Timeline',
  'Compare Slider',
  'Empty State',
  'Loading / Skeleton',
  'Error State',
  'Permission State',
]

// ── DECISION REGISTRY ────────────────────────────────────────────────────────
type DecisionStatus = 'open' | 'needs-product' | 'needs-tech' | 'blocker' | 'decided' | 'deferred' | 'locked' | 'duplicate'

interface Decision {
  id: string; gate: string; title: string; owner: string
  status: DecisionStatus; blocking: boolean
  options?: string[]; provisional?: string; detail?: string; correction?: string
}

const ALL_DECISIONS: Decision[] = [
  // D1
  { id:'Q1',  gate:'D1', title:'Light theme — полная система или только ключевые экраны?', owner:'Product + Design', status:'open', blocking:false, options:['Полная система в D9','3–5 экранов','Post-launch'], detail:'Q41 является продолжением этого решения — нужен один ADR.', correction:'Duplicate — linked Q41.' },
  { id:'Q2',  gate:'D1', title:'Developer Handoff — экран в прототипе или только Figma-аннотации?', owner:'Product', status:'deferred', blocking:false, options:['Экран в прототипе','Figma-only'], detail:'Внутреннее решение процесса, не блокирует UX.' },
  { id:'Q3',  gate:'D1', title:'Token naming — финальный словарь до D9?', owner:'Design + Dev', status:'needs-product', blocking:false, options:['Утвердить сейчас','Рефакторинг в D9'] },
  // D2
  { id:'Q4',  gate:'D2', title:'Health integration — Android now, iOS later, или обе платформы вместе?', owner:'Dev + Product', status:'needs-product', blocking:false, options:['Android сейчас, iOS отдельный релиз','Обе платформы в одном релизе','Отложить до D9'], correction:'Переформулировано: platform scope decision, не fake iOS stub.' },
  { id:'Q5',  gate:'D2', title:'Обязательные шаги онбординга — минимум или все 13?', owner:'UX + Product', status:'needs-product', blocking:false, options:['Только Цель + Уровень','Все 13 шагов'] },
  { id:'Q6',  gate:'D2', title:'BMI — показывать или только вес и цель?', owner:'Product', status:'decided', blocking:false, options:['Скрыть','Показать нейтрально'], provisional:'Показывать нейтрально с пояснением — не диагноз.' },
  { id:'Q7',  gate:'D2', title:'Onboarding skip — полный пропуск или минимум 3 шага?', owner:'Product', status:'needs-product', blocking:false, options:['Полный skip','Минимум 3 шага','Нельзя пропустить'] },
  // D3
  { id:'Q8',  gate:'D3', title:'Recovery score — on-device или backend?', owner:'Tech + Product', status:'needs-tech', blocking:false, options:['On-device approximation','Backend endpoint'] },
  { id:'Q9',  gate:'D3', title:'Фото-карточка на Home — когда показывать?', owner:'UX', status:'decided', blocking:false, options:['2+ совместимых фото','Только после milestone'], provisional:'После 2+ совместимых фото одного ракурса.' },
  { id:'Q10', gate:'D3', title:'Notch / Dynamic Island — нативная адаптация header?', owner:'Dev', status:'deferred', blocking:false, options:['Нативная адаптация','Safe area padding достаточно'] },
  // D4
  { id:'Q11', gate:'D4', title:'Offline база оборудования — объём в MVP?', owner:'Product + Dev', status:'needs-product', blocking:false, options:['Топ-50','Топ-200','Полная'] },
  { id:'Q12', gate:'D4', title:'Unknown equipment — отправлять для ML обучения?', owner:'Privacy + Tech', status:'needs-product', blocking:false, options:['Да, с явного согласия','Только local'] },
  { id:'Q13', gate:'D4', title:'Ручной ввод как fallback для нераспознанного тренажёра?', owner:'UX', status:'needs-product', blocking:false, options:['Поиск','Нет fallback','Фото + тикет'] },
  { id:'Q14', gate:'D4', title:'Equipment Page — полноценный экран или bottom sheet?', owner:'UX', status:'decided', blocking:false, options:['Отдельный экран','Bottom sheet'], provisional:'Отдельный экран с hero poster.' },
  // D5
  { id:'Q15', gate:'D5', title:'Автоприрост веса — когда предлагать?', owner:'Product', status:'needs-product', blocking:false, options:['Сразу после +5% рекорда','После 2 тренировок','Никогда'] },
  { id:'Q16', gate:'D5', title:'Rest Timer звук — по умолчанию вкл?', owner:'UX', status:'decided', blocking:false, options:['Вкл','Выкл'], provisional:'Выкл по умолчанию.' },
  { id:'Q17', gate:'D5', title:'Supersets и Drop-sets — в MVP или D8+?', owner:'Product', status:'deferred', blocking:false, options:['MVP','D8','Post-launch'] },
  { id:'Q18', gate:'D5', title:'Замена упражнения — история изменений в workout log?', owner:'Product', status:'needs-product', blocking:false, options:['Да, с пометкой «заменено»','Нет'] },
  // D6 — blockers
  { id:'Q19', gate:'D6', title:'Form Check ML — real on-device Flutter/TFLite или demo prototype?', owner:'Tech + Product', status:'blocker', blocking:true, options:['Реальный on-device ML в текущем Flutter stack','Demo prototype'], correction:'Переформулировано: Flutter/on-device ML, не React Native.' },
  { id:'Q20', gate:'D6', title:'Поддерживаемые упражнения в первом релизе — список согласован?', owner:'Product', status:'blocker', blocking:true, options:['Топ-5 базовых','Топ-15','Все из библиотеки'] },
  { id:'Q21', gate:'D6', title:'Exercise-to-camera-angle matrix — для каких боковой, для каких фронтальный?', owner:'Sport Science', status:'blocker', blocking:true, detail:'Требуется артефакт: упражнение → ракурс → обязательные ключевые точки.' },
  { id:'Q22', gate:'D6', title:'Сохранять историю Form Check в workout log?', owner:'Product', status:'open', blocking:false, options:['Summary linked to workout','Session-only'], provisional:'Только metadata summary; кадры/видео не сохранять до подтверждения storage policy.' },
  { id:'Q23', gate:'D6', title:'Голосовые подсказки — on-device TTS или записанные файлы?', owner:'Dev', status:'blocker', blocking:true, options:['On-device TTS (AVSpeech / Android TTS)','Записанные MP3-файлы'] },
  { id:'Q24', gate:'D6', title:'Язык озвучки — RU only, RU+EN, или язык системы?', owner:'Product', status:'open', blocking:false, options:['Только RU в MVP','RU+EN','Язык приложения / системы'], provisional:'Язык приложения/системы.' },
  { id:'Q25', gate:'D6', title:'Показывать процент уверенности пользователю?', owner:'UX', status:'decided', blocking:false, options:['Raw percent','Human-readable reliability state'], provisional:'Human-readable: «Оценено уверенно» / «Оценено частично» — без raw %.' },
  { id:'Q26', gate:'D6', title:'WorkoutSummary — заменить WorkoutDone или новый экран поверх?', owner:'Dev', status:'blocker', blocking:true, options:['Заменить существующий','Новый экран поверх'] },
  // D7
  { id:'Q27', gate:'D7', title:'Storage policy для Progress Photos — local-only или cloud?', owner:'Privacy + Tech', status:'needs-product', blocking:false, options:['Local-only MVP','Cloud opt-in','Cloud по умолчанию'] },
  { id:'Q28', gate:'D7', title:'Анонимизация лица — опция или авто перед экспортом?', owner:'Privacy + UX', status:'needs-product', blocking:false, options:['Опция (не авто)','Авто по умолчанию','Не включать'] },
  { id:'Q29', gate:'D7', title:'Milestone-теги — стандартные vs пользовательские?', owner:'UX', status:'decided', blocking:false, options:['Только стандартные','Стандартные + custom'], provisional:'Стандартные + custom в MVP.' },
  { id:'Q30', gate:'D7', title:'Сравнение разных ракурсов — запретить или предупредить?', owner:'UX', status:'decided', blocking:false, options:['Запретить','Предупреждение и разрешить'], provisional:'Показать предупреждение, разрешить.' },
  // D8
  { id:'Q31', gate:'D8', title:'Paywall placement — после Plan Preview или по достижению лимита?', owner:'Product', status:'needs-product', blocking:false, options:['После Plan Preview','По достижению лимита'] },
  { id:'Q32', gate:'D8', title:'Free tier лимиты — точные числа?', owner:'Product', status:'needs-product', blocking:false, options:['3 программы / 5 Form Check / 10 фото','Другое'] },
  { id:'Q33', gate:'D8', title:'AI Coach scope — только в тренировке или глобальный?', owner:'Product', status:'needs-product', blocking:false, options:['Только в Workout Player','Глобальный контекстный'] },
  { id:'Q34', gate:'D8', title:'AI Coach backend — contextual API, rule-based, или custom model?', owner:'Tech', status:'needs-tech', blocking:false, options:['Contextual API (Claude)','Rule-based','Custom model'] },
  { id:'Q35', gate:'D8', title:'Периоды подписки — только месяц/год или квартал тоже?', owner:'Product', status:'needs-product', blocking:false, options:['Месяц + год','+ квартал'] },
  { id:'Q36', gate:'D8', title:'Семейная подписка — в scope?', owner:'Product', status:'deferred', blocking:false, options:['Нет','Post-launch','D8'] },
  { id:'Q37', gate:'D8', title:'Profile data export в MVP? (GDPR)', owner:'Legal + Product', status:'needs-product', blocking:false, options:['MVP','Post-launch'] },
  { id:'Q38', gate:'D8', title:'Интеграция с носимыми (Garmin, Polar) — в каком гейте?', owner:'Product', status:'deferred', blocking:false, options:['D8','Post-launch'] },
  // D9
  { id:'Q39', gate:'D9', title:'Mobile implementation stack — Flutter (locked)', owner:'Tech', status:'locked', blocking:false, detail:'Канонический проект уже Flutter. React Native / native rewrite не в scope UI refactor.', correction:'LOCKED — Flutter. Не переформулировать как открытый выбор.' },
  { id:'Q40', gate:'D9', title:'Минимальная версия ОС — Android 10+/iOS 16+ или старше?', owner:'Dev', status:'needs-tech', blocking:false, options:['Android 10+ / iOS 16+','Android 8+ / iOS 15+'] },
  { id:'Q41', gate:'D9', title:'Light theme timing — D9 или post-launch? (dup Q1)', owner:'Product', status:'duplicate', blocking:false, options:['D9','Post-launch','Системная тема'], correction:'Duplicate/continuation of Q1. Одно решение закрывает оба пункта.' },
  { id:'Q42', gate:'D9', title:'Reduced motion — полный набор или только критичные?', owner:'Dev + Design', status:'needs-product', blocking:false, options:['Полный набор альтернатив','Только критичные'] },
  { id:'Q43', gate:'D9', title:'Offline режим — только Workout или Home+Workout+Progress?', owner:'Tech + Product', status:'needs-product', blocking:false, options:['Только Workout Player','Home + Workout + Progress'] },
  { id:'Q44', gate:'D9', title:'Push-уведомления — согласован список типов?', owner:'Product', status:'needs-product', blocking:false, options:['Только напоминание о тренировке','Тренировка + фото + рекорды'] },
]

const STATUS_META: Record<DecisionStatus, { label: string; color: string; short: string }> = {
  'open':          { label: 'Открыт',         color: '#6B7280', short: 'OPEN'    },
  'needs-product': { label: 'Нужно Product',   color: '#F59E0B', short: 'PROD'   },
  'needs-tech':    { label: 'Нужно Tech',      color: '#3B82F6', short: 'TECH'   },
  'blocker':       { label: 'Блокер',          color: '#EF4444', short: 'BLOCK'  },
  'decided':       { label: 'Решено',          color: '#22C55E', short: 'DONE'   },
  'deferred':      { label: 'Отложено',        color: '#6B7280', short: 'DEF'    },
  'locked':        { label: 'Заблокировано',   color: '#8B5CF6', short: 'LOCK'   },
  'duplicate':     { label: 'Дубликат',        color: '#F97316', short: 'DUP'    },
}

const DecisionRegistry = () => {
  const [gateFilter, setGateFilter] = useState<string>('Все')
  const [statusFilter, setStatusFilter] = useState<string>('Все')
  const [blockingFilter, setBlockingFilter] = useState(false)
  const [selected, setSelected] = useState<Decision | null>(null)

  const gates = ['Все', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9']
  const statuses = ['Все', 'Блокер', 'Открыт', 'Нужно Product', 'Нужно Tech', 'Решено', 'Отложено', 'Заблокировано', 'Дубликат']

  const filtered = ALL_DECISIONS.filter(d => {
    if (gateFilter !== 'Все' && d.gate !== gateFilter) return false
    if (blockingFilter && !d.blocking) return false
    if (statusFilter !== 'Все') {
      const meta = STATUS_META[d.status]
      if (meta.label !== statusFilter) return false
    }
    return true
  })

  const summaryNums = [
    { val: '22', label: 'Долг завершённых D1–D5, D7', col: C.ok },
    { val: '8',  label: 'Блокируют D6',               col: C.err },
    { val: '14', label: 'Будущие D8–D9',               col: C.fg3 },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0, position: 'relative' }}>
      {/* Summary header */}
      <div style={{ background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '12px 14px', marginBottom: 10 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>INTERNAL DESIGN GOVERNANCE — NOT END-USER SCOPE</div>
        <div style={{ display: 'flex', gap: 6 }}>
          {summaryNums.map(s => (
            <div key={s.label} style={{ flex: 1, background: C.s3, borderRadius: 10, padding: '8px 6px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 18, fontWeight: 800, color: s.col }}>{s.val}</div>
              <div style={{ fontSize: 9, color: C.fg3, lineHeight: 1.3, marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* D6 blocker callout */}
      {gateFilter === 'Все' && (
        <div style={{ background: bc(C.err, 0.08), borderRadius: 12, border: `1px solid ${bc(C.err, 0.3)}`, padding: '10px 14px', marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.err, marginBottom: 4 }}>НУЖНО РЕШИТЬ ПЕРЕД ПРОДОЛЖЕНИЕМ D6</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>Q19 · Q20 · Q21 · Q23 · Q26 — Hard blockers</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 3 }}>Provisional defaults: Q22 · Q24 · Q25</div>
        </div>
      )}

      {/* Filters */}
      <div style={{ marginBottom: 8 }}>
        <div style={{ display: 'flex', gap: 5, overflowX: 'auto', paddingBottom: 6, marginBottom: 6 }}>
          {gates.map(g => (
            <button key={g} onClick={() => setGateFilter(g)} style={{ padding: '5px 11px', borderRadius: 99, border: `1px solid ${gateFilter === g ? C.acc : C.bd2}`, background: gateFilter === g ? bc(C.acc, 0.15) : C.s3, color: gateFilter === g ? C.acc : C.fg3, fontSize: 11, fontWeight: 700, cursor: 'pointer', flexShrink: 0 }}>
              {g}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 5, overflowX: 'auto', paddingBottom: 4 }}>
          {statuses.map(s => (
            <button key={s} onClick={() => setStatusFilter(s)} style={{ padding: '5px 11px', borderRadius: 99, border: `1px solid ${statusFilter === s ? C.warn : C.bd2}`, background: statusFilter === s ? bc(C.warn, 0.12) : C.s3, color: statusFilter === s ? C.warn : C.fg3, fontSize: 11, fontWeight: 600, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap' }}>
              {s}
            </button>
          ))}
          <button onClick={() => setBlockingFilter(!blockingFilter)} style={{ padding: '5px 11px', borderRadius: 99, border: `1px solid ${blockingFilter ? C.err : C.bd2}`, background: blockingFilter ? bc(C.err, 0.15) : C.s3, color: blockingFilter ? C.err : C.fg3, fontSize: 11, fontWeight: 700, cursor: 'pointer', flexShrink: 0 }}>
            🚫 Только блокеры
          </button>
        </div>
      </div>

      {/* Count */}
      <div style={{ fontSize: 11, color: C.fg3, marginBottom: 8, paddingLeft: 2 }}>{filtered.length} из 44 решений</div>

      {/* Compact rows */}
      <div style={{ background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 12 }}>
        {filtered.map((d, i) => {
          const meta = STATUS_META[d.status]
          return (
            <button key={d.id} onClick={() => setSelected(d)} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderBottom: i < filtered.length - 1 ? `1px solid ${C.bd}` : 'none', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', borderBottomWidth: i < filtered.length - 1 ? 1 : 0, borderBottomStyle: 'solid', borderBottomColor: C.bd }}>
              {/* ID + Gate */}
              <div style={{ flexShrink: 0, width: 42 }}>
                <div style={{ fontSize: 9, fontWeight: 800, color: C.fg3 }}>{d.gate}</div>
                <div style={{ fontSize: 10, fontWeight: 700, color: meta.color }}>{d.id}</div>
              </div>
              {/* Title */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, color: C.fg, lineHeight: 1.35, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const }}>{d.title}</div>
                <div style={{ fontSize: 10, color: C.fg3, marginTop: 2 }}>{d.owner}</div>
              </div>
              {/* Badges */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 3, alignItems: 'flex-end', flexShrink: 0 }}>
                <div style={{ padding: '2px 7px', borderRadius: 99, background: bc(meta.color, 0.15), border: `1px solid ${bc(meta.color, 0.35)}` }}>
                  <span style={{ fontSize: 9, fontWeight: 800, color: meta.color }}>{meta.short}</span>
                </div>
                {d.blocking && (
                  <div style={{ padding: '2px 7px', borderRadius: 99, background: bc(C.err, 0.12), border: `1px solid ${bc(C.err, 0.3)}` }}>
                    <span style={{ fontSize: 9, fontWeight: 800, color: C.err }}>🚫</span>
                  </div>
                )}
                {d.correction && (
                  <div style={{ padding: '2px 7px', borderRadius: 99, background: bc(C.warn, 0.1), border: `1px solid ${bc(C.warn, 0.3)}` }}>
                    <span style={{ fontSize: 9, fontWeight: 700, color: C.warn }}>FIX</span>
                  </div>
                )}
              </div>
              <span style={{ fontSize: 14, color: C.fg3, flexShrink: 0 }}>›</span>
            </button>
          )
        })}
      </div>

      {/* Detail drawer */}
      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', zIndex: 100, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }} onClick={() => setSelected(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: C.s1, borderRadius: '20px 20px 0 0', padding: '0 20px 40px', maxHeight: '80vh', overflowY: 'auto' }}>
            <div style={{ width: 40, height: 4, borderRadius: 99, background: C.bd2, margin: '14px auto 16px' }} />
            {/* Header */}
            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 11, color: C.fg3, fontWeight: 700, marginBottom: 3 }}>{selected.gate} · {selected.id}</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: C.fg, lineHeight: 1.4 }}>{selected.title}</div>
                <div style={{ fontSize: 12, color: C.fg3, marginTop: 4 }}>Owner: {selected.owner}</div>
              </div>
              <div style={{ flexShrink: 0, marginLeft: 'auto' }}>
                {(() => { const m = STATUS_META[selected.status]; return (
                  <div style={{ padding: '5px 12px', borderRadius: 99, background: bc(m.color, 0.15), border: `1px solid ${bc(m.color, 0.35)}` }}>
                    <span style={{ fontSize: 11, fontWeight: 800, color: m.color }}>{m.label}</span>
                  </div>
                )})()}
              </div>
            </div>

            {/* Correction notice */}
            {selected.correction && (
              <div style={{ background: bc(C.warn, 0.08), borderRadius: 10, border: `1px solid ${bc(C.warn, 0.3)}`, padding: '10px 12px', marginBottom: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.warn, marginBottom: 3 }}>ИСПРАВЛЕНИЕ v1.3</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{selected.correction}</div>
              </div>
            )}

            {/* Blocking */}
            {selected.blocking && (
              <div style={{ background: bc(C.err, 0.08), borderRadius: 10, border: `1px solid ${bc(C.err, 0.3)}`, padding: '8px 12px', marginBottom: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ fontSize: 16 }}>🚫</span>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.err }}>Hard blocker D6 — нельзя продолжить без решения</span>
              </div>
            )}

            {/* Options */}
            {selected.options && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.fg2, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Варианты</div>
                {selected.options.map((o, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, padding: '8px 12px', background: C.s2, borderRadius: 10, border: `1px solid ${C.bd}`, marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: C.fg3, flexShrink: 0, minWidth: 16 }}>{String.fromCharCode(65 + i)}.</span>
                    <span style={{ fontSize: 13, color: C.fg }}>{o}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Provisional */}
            {selected.provisional && (
              <div style={{ background: bc(C.acc, 0.07), borderRadius: 10, border: `1px solid ${bc(C.acc, 0.25)}`, padding: '10px 12px', marginBottom: 12 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: C.acc, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>PROVISIONAL DEFAULT</div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>{selected.provisional}</div>
              </div>
            )}

            {/* Detail */}
            {selected.detail && (
              <div style={{ background: C.s2, borderRadius: 10, border: `1px solid ${C.bd}`, padding: '10px 12px', marginBottom: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>КОНТЕКСТ</div>
                <div style={{ fontSize: 12, color: C.fg2, lineHeight: 1.6 }}>{selected.detail}</div>
              </div>
            )}

            <button onClick={() => setSelected(null)} style={{ width: '100%', padding: '13px', borderRadius: 14, border: 'none', background: C.s2, color: C.fg, fontSize: 14, fontWeight: 600, cursor: 'pointer', marginTop: 4 }}>
              Закрыть
            </button>
          </div>
        </div>
      )}

      <div style={{ height: 16 }} />
    </div>
  )
}

const ResearchScreen = ({ onStart, onVariants }: { onStart: () => void; onVariants?: () => void }) => {
  const [tab, setTab] = useState<'audit' | 'ia' | 'system' | 'gates'>('audit')

  const gateStatusColor = (s: 'done' | 'next' | 'pending') =>
    s === 'done' ? C.ok : s === 'next' ? C.acc : C.fg3
  const gateStatusLabel = (s: 'done' | 'next' | 'pending') =>
    s === 'done' ? 'Готово' : s === 'next' ? 'Следующий' : 'Ожидает'

  return (
    <div style={{ height: '100%', background: C.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '52px 20px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.acc }} />
          <Label color={C.acc}>Fitness App Redesign · D1</Label>
        </div>
        <h1 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, lineHeight: 1.05, margin: '0 0 4px' }}>
          Research & Design System
        </h1>
        <p style={{ fontSize: 12, color: C.fg2, margin: 0 }}>Gate D1 — Audit · IA · Tokens · UX Principles</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, padding: '8px 20px', flexShrink: 0, overflowX: 'auto' }}>
        {([
          { id: 'audit', label: 'Аудит' },
          { id: 'ia', label: 'Архит.' },
          { id: 'system', label: 'Система' },
          { id: 'gates', label: 'Решения · 44' },
        ] as const).map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ flexShrink: 0, padding: '7px 14px', borderRadius: 10, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 700, letterSpacing: '0.03em', background: tab === t.id ? C.acc : C.s3, color: tab === t.id ? '#060F00' : C.fg2, transition: 'all 0.15s' }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '4px 20px 0' }}>

        {/* ── AUDIT ─────────────────────────────────────────────────── */}
        {tab === 'audit' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Problems + Fix */}
            <Card style={{ padding: 16 }}>
              <Label color={C.err}>Current UI — проблемы & решения</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {AUDIT_PROBLEMS.map((p, i) => (
                  <div key={i} style={{ background: C.s3, borderRadius: 12, overflow: 'hidden' }}>
                    <div style={{ display: 'flex', gap: 8, padding: '8px 12px', alignItems: 'flex-start' }}>
                      <span style={{ fontSize: 11, color: C.err, fontWeight: 700, marginTop: 2, flexShrink: 0 }}>✕</span>
                      <span style={{ fontSize: 12, color: C.fg2, lineHeight: 1.45 }}>{p.text}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 8, padding: '6px 12px 8px', borderTop: `1px solid ${C.bd}`, alignItems: 'flex-start' }}>
                      <span style={{ fontSize: 11, color: C.acc, fontWeight: 700, marginTop: 1, flexShrink: 0 }}>→</span>
                      <span style={{ fontSize: 11, color: C.acc, lineHeight: 1.45 }}>{p.fix}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* UX Questions */}
            <Card style={{ padding: 16 }}>
              <Label color={C.ok}>Каждый экран отвечает на вопрос</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {UX_QUESTIONS.map((item, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <div style={{ width: 20, height: 20, borderRadius: '50%', background: bc(C.acc, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
                      <span style={{ fontSize: 9, fontWeight: 800, color: C.acc }}>{i + 1}</span>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.fg, lineHeight: 1.3 }}>{item.q}</div>
                      <div style={{ fontSize: 11, color: C.fg3, marginTop: 2 }}>{item.where}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Taken / Rejected */}
            <Card style={{ padding: 16 }}>
              <Label>Из референсов — принято</Label>
              <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {TAKEN.map((t) => <Chip key={t} label={t} color={bc(C.acc, 0.12)} text={C.acc} small />)}
              </div>
            </Card>
            <Card style={{ padding: 16 }}>
              <Label color={C.err}>Отвергнуто</Label>
              <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {REJECTED.map((t) => <Chip key={t} label={t} color={bc(C.err, 0.1)} text={C.err} small />)}
              </div>
            </Card>

            {/* UX Principles */}
            <Card style={{ padding: 16 }}>
              <Label>UX-принципы</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
                {[
                  'Одно доминирующее primary action на экран',
                  'Максимум 3 смысловых блока до первого scroll',
                  'Важные controls доступны одной рукой',
                  'Во время тренировки вторичный контент скрыт',
                  'Grid не универсальное решение',
                  'Не показывать неподтверждённые метрики',
                  'Не смешивать health guidance и медицинский диагноз',
                  'Цвет не единственный сигнал — всегда + иконка/текст',
                ].map((p, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <span style={{ fontSize: 10, color: C.acc, fontWeight: 800, marginTop: 3, flexShrink: 0 }}>◆</span>
                    <span style={{ fontSize: 12, color: C.fg2, lineHeight: 1.45 }}>{p}</span>
                  </div>
                ))}
              </div>
            </Card>
            <div style={{ height: 16 }} />
          </div>
        )}

        {/* ── IA ────────────────────────────────────────────────────── */}
        {tab === 'ia' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ background: C.s2, borderRadius: 14, padding: 14, border: `1px solid ${C.bd}`, fontSize: 13, color: C.fg2, lineHeight: 1.6 }}>
              5 разделов в нижней навигации. <strong style={{ color: C.fg }}>Scan</strong> — центральная выделенная кнопка, уникальная функция продукта. <strong style={{ color: C.fg }}>Today Workout</strong> — главное действие Home.
            </div>

            {IA_FULL.map((node) => (
              <div key={node.label} style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
                <div style={{ padding: '10px 14px', background: bc(node.color, 0.13), display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: node.color, flexShrink: 0 }} />
                  <span className="font-display" style={{ fontSize: 17, fontWeight: 700, color: node.color }}>{node.label}</span>
                </div>
                <div style={{ padding: '10px 14px', display: 'flex', flexDirection: 'column', gap: 5 }}>
                  {node.subs.map((s) => (
                    <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 4, height: 4, borderRadius: '50%', background: node.color, opacity: 0.5, flexShrink: 0 }} />
                      <span style={{ fontSize: 12, color: C.fg2 }}>{s}</span>
                    </div>
                  ))}
                  {'note' in node && node.note && (
                    <div style={{ marginTop: 4, fontSize: 11, color: C.fg3, fontStyle: 'italic' }}>{node.note}</div>
                  )}
                </div>
              </div>
            ))}

            {/* Happy path */}
            <Card style={{ padding: 16 }}>
              <Label>Happy Path — prototype flow</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 0 }}>
                {HAPPY_PATH.map((step, i, arr) => (
                  <div key={step} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                      <div style={{ width: 22, height: 22, borderRadius: '50%', background: i === 0 ? C.acc : i === arr.length - 1 ? C.ok : C.s3, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <span style={{ fontSize: 9, fontWeight: 700, color: i === 0 || i === arr.length - 1 ? '#060F00' : C.fg3 }}>{i + 1}</span>
                      </div>
                      {i < arr.length - 1 && <div style={{ width: 1, height: 14, background: C.bd2 }} />}
                    </div>
                    <span style={{ fontSize: 12, color: i === 0 || i === arr.length - 1 ? C.fg : C.fg2, fontWeight: i === 0 || i === arr.length - 1 ? 600 : 400, paddingBottom: i < arr.length - 1 ? 0 : 0 }}>{step}</span>
                  </div>
                ))}
              </div>
            </Card>
            <div style={{ height: 16 }} />
          </div>
        )}

        {/* ── SYSTEM ────────────────────────────────────────────────── */}
        {tab === 'system' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Typography scale */}
            <Card style={{ padding: 16 }}>
              <Label>Типографика — шкала</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
                {TYPE_SCALE.map((t) => (
                  <div key={t.role} style={{ display: 'flex', alignItems: 'baseline', gap: 10, borderBottom: `1px solid ${C.bd}`, paddingBottom: 6 }}>
                    <div style={{ minWidth: 90, fontSize: 10, color: C.fg3, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', alignSelf: 'center' }}>{t.role}</div>
                    <div
                      className={t.font === 'Barlow Condensed' ? 'font-display' : undefined}
                      style={{ fontFamily: t.font === 'monospace' ? 'monospace' : undefined, fontSize: Math.min(t.size, 32), fontWeight: t.weight, color: t.role.startsWith('Numeric') ? C.acc : C.fg, lineHeight: 1.1, letterSpacing: t.role === 'Label' ? '0.1em' : undefined, textTransform: t.role === 'Label' ? 'uppercase' : undefined }}
                    >
                      {t.sample}
                    </div>
                    <div style={{ marginLeft: 'auto', fontSize: 10, color: C.fg3, flexShrink: 0 }}>{t.size}/{t.weight}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Semantic tokens */}
            <Card style={{ padding: 16 }}>
              <Label>Semantic Color Tokens</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
                {TOKEN_COLORS.map((t) => (
                  <div key={t.token} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 28, height: 28, borderRadius: 8, background: t.val, border: `1px solid ${C.bd2}`, flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: C.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.token}</div>
                      <div style={{ fontSize: 10, color: C.fg3, fontFamily: 'monospace' }}>{t.val}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Spacing */}
            <Card style={{ padding: 16 }}>
              <Label>Spacing Scale</Label>
              <div style={{ marginTop: 10, display: 'flex', gap: 6, alignItems: 'flex-end', flexWrap: 'wrap' }}>
                {SPACING.map((s) => (
                  <div key={s} style={{ textAlign: 'center' }}>
                    <div style={{ width: s, height: s, background: bc(C.acc, 0.3), borderRadius: 3, margin: '0 auto 4px' }} />
                    <div style={{ fontSize: 9, color: C.fg3 }}>{s}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Radius */}
            <Card style={{ padding: 16 }}>
              <Label>Border Radius</Label>
              <div style={{ marginTop: 10, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {RADIUS.map((r) => (
                  <div key={r} style={{ textAlign: 'center' }}>
                    <div style={{ width: 40, height: 40, background: C.s3, border: `1.5px solid ${C.bd2}`, borderRadius: r }} />
                    <div style={{ fontSize: 9, color: C.fg3, marginTop: 4 }}>{r}px</div>
                  </div>
                ))}
                <div style={{ textAlign: 'center' }}>
                  <div style={{ width: 40, height: 40, background: C.s3, border: `1.5px solid ${C.bd2}`, borderRadius: 99 }} />
                  <div style={{ fontSize: 9, color: C.fg3, marginTop: 4 }}>Full</div>
                </div>
              </div>
            </Card>

            {/* Core components list */}
            <Card style={{ padding: 16 }}>
              <Label>Core Components — {CORE_COMPONENTS.length} шт.</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 5 }}>
                {CORE_COMPONENTS.map((c) => (
                  <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 10, color: C.acc, fontWeight: 800, flexShrink: 0 }}>◆</span>
                    <span style={{ fontSize: 12, color: C.fg2 }}>{c}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 12, padding: '10px 12px', background: C.s3, borderRadius: 10, fontSize: 11, color: C.fg3, lineHeight: 1.5 }}>
                Каждый компонент: default · pressed · focused · selected · disabled · loading · error · success
              </div>
            </Card>

            {/* Glassmorphism rules */}
            <Card style={{ padding: 16 }}>
              <Label>Glassmorphism — когда использовать</Label>
              <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 5 }}>
                {['Camera overlays', 'Floating controls', 'Modal sheets', 'Temporary status overlays'].map((s) => (
                  <div key={s} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ fontSize: 10, color: C.ok, fontWeight: 800, flexShrink: 0 }}>✓</span>
                    <span style={{ fontSize: 12, color: C.fg2 }}>{s}</span>
                  </div>
                ))}
                <div style={{ height: 4 }} />
                {['Scrolling cards', 'Exercise list items', 'Regular surfaces'].map((s) => (
                  <div key={s} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ fontSize: 10, color: C.err, fontWeight: 800, flexShrink: 0 }}>✕</span>
                    <span style={{ fontSize: 12, color: C.fg2 }}>{s}</span>
                  </div>
                ))}

              </div>
            </Card>

            {/* Light theme semantic palette */}
            <Card style={{ padding: 16 }}>
              <Label>Light Theme — семантическая палитра (ADR Q1/Q41)</Label>
              <div style={{ marginTop: 4, marginBottom: 10, fontSize: 11, color: C.fg3, lineHeight: 1.5 }}>Статус: открыто (D9 или Post-launch). Токены зафиксированы, ожидают решения по объёму.</div>
              {(() => {
                const LC = {
                  bgPrimary: '#F2F2EE',
                  bgSecondary: '#FFFFFF',
                  surfaceCard: '#FFFFFF',
                  surfaceRaised: '#F8F8F4',
                  accentPrimary: '#4D7A00',
                  accentOnDark: '#C9FF47',
                  textPrimary: '#0F1014',
                  textSecondary: '#4A4A52',
                  textTertiary: '#909098',
                  ok: '#16A34A',
                  warn: '#D97706',
                  err: '#DC2626',
                  border: 'rgba(15,16,20,0.1)',
                  border2: 'rgba(15,16,20,0.18)',
                }
                const tokens = [
                  { token: 'bgPrimary', val: LC.bgPrimary, note: 'Page background' },
                  { token: 'bgSecondary / surfaceCard', val: LC.bgSecondary, note: 'Cards, sheets' },
                  { token: 'surfaceRaised', val: LC.surfaceRaised, note: 'Chips, inputs' },
                  { token: 'accentPrimary', val: LC.accentPrimary, note: 'Lime darkened for light bg' },
                  { token: 'textPrimary', val: LC.textPrimary, note: 'Headlines, body' },
                  { token: 'textSecondary', val: LC.textSecondary, note: 'Labels, captions' },
                  { token: 'textTertiary', val: LC.textTertiary, note: 'Placeholders, hints' },
                  { token: 'ok', val: LC.ok, note: 'Success states' },
                  { token: 'warn', val: LC.warn, note: 'Warnings' },
                  { token: 'err', val: LC.err, note: 'Errors' },
                ]
                return (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {tokens.map(t => (
                      <div key={t.token} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 8, background: t.val, border: `1.5px solid ${C.bd2}`, flexShrink: 0 }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 12, fontWeight: 600, color: C.fg }}>{t.token}</div>
                          <div style={{ fontSize: 10, color: C.fg3, fontFamily: 'monospace' }}>{t.val} — {t.note}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              })()}
            </Card>

            {/* 3 Light anchor screen previews */}
            <div style={{ marginTop: 4 }}>
              <Label style={{ display: 'block', marginBottom: 10 }}>Light Theme — 3 anchor screens (preview)</Label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>

                {/* Anchor 1: Home */}
                <div>
                  <div style={{ fontSize: 11, color: C.fg3, marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>1 · Home Screen</div>
                  <div style={{ borderRadius: 16, overflow: 'hidden', border: `1px solid ${C.bd2}`, aspectRatio: '9/16', maxHeight: 300, background: '#F2F2EE', position: 'relative' }}>
                    {/* status bar */}
                    <div style={{ height: 36, background: '#F2F2EE', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px' }}>
                      <span style={{ fontSize: 10, fontWeight: 700, color: '#0F1014' }}>9:41</span>
                      <div style={{ display: 'flex', gap: 4 }}>
                        {['▪▪▪', '◗', '■'].map(i => <span key={i} style={{ fontSize: 8, color: '#0F1014', opacity: 0.6 }}>{i}</span>)}
                      </div>
                    </div>
                    {/* greeting */}
                    <div style={{ padding: '8px 14px 6px' }}>
                      <div style={{ fontSize: 9, color: '#909098', fontWeight: 600 }}>ДОБРОЕ УТРО</div>
                      <div style={{ fontSize: 16, fontWeight: 900, color: '#0F1014', letterSpacing: '-0.02em' }}>Алексей</div>
                    </div>
                    {/* workout card */}
                    <div style={{ margin: '0 10px', background: '#4D7A00', borderRadius: 12, padding: '10px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: 8, color: 'rgba(255,255,255,0.7)', fontWeight: 600 }}>СЕГОДНЯ</div>
                        <div style={{ fontSize: 12, fontWeight: 800, color: '#fff' }}>Грудь и трицепс</div>
                        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>5 упр · 45 мин</div>
                      </div>
                      <div style={{ width: 28, height: 28, borderRadius: 8, background: 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>▶</div>
                    </div>
                    {/* stats row */}
                    <div style={{ display: 'flex', gap: 6, padding: '8px 10px' }}>
                      {[{ v: '12', l: 'нед' }, { v: '87%', l: 'план' }, { v: '3', l: 'PR' }].map(s => (
                        <div key={s.l} style={{ flex: 1, background: '#FFFFFF', borderRadius: 8, padding: '6px 8px', textAlign: 'center' }}>
                          <div style={{ fontSize: 13, fontWeight: 800, color: '#4D7A00' }}>{s.v}</div>
                          <div style={{ fontSize: 8, color: '#909098', fontWeight: 600 }}>{s.l}</div>
                        </div>
                      ))}
                    </div>
                    {/* bottom nav */}
                    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 40, background: '#FFFFFF', borderTop: '1px solid rgba(15,16,20,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'space-around', padding: '0 8px' }}>
                      {['⌂', '◎', '▶', '↗', '◷'].map((icon, i) => (
                        <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
                          <span style={{ fontSize: i === 2 ? 14 : 11, color: i === 0 ? '#4D7A00' : '#909098' }}>{icon}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Anchor 2: Exercise Page */}
                <div>
                  <div style={{ fontSize: 11, color: C.fg3, marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>2 · Exercise Page</div>
                  <div style={{ borderRadius: 16, overflow: 'hidden', border: `1px solid ${C.bd2}`, background: '#F2F2EE', position: 'relative' }}>
                    {/* hero */}
                    <div style={{ height: 80, background: 'linear-gradient(135deg, #E8E0F8 0%, #D4C8F0 100%)', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 40% 60%, rgba(124,58,237,0.2) 0%, transparent 60%)' }} />
                      <div style={{ fontSize: 28, opacity: 0.5 }}>🏋️</div>
                      <div style={{ position: 'absolute', bottom: 8, left: 12 }}>
                        <div style={{ fontSize: 13, fontWeight: 900, color: '#0F1014' }}>Жим штанги лёжа</div>
                        <div style={{ fontSize: 9, color: '#4A4A52' }}>Грудь · Трицепс</div>
                      </div>
                    </div>
                    <div style={{ padding: '10px 12px' }}>
                      {/* muscle chips */}
                      <div style={{ display: 'flex', gap: 5, marginBottom: 8 }}>
                        {['Большая грудная', 'Трицепс', 'Дельты'].map((m, i) => (
                          <div key={m} style={{ padding: '3px 7px', borderRadius: 99, background: i === 0 ? 'rgba(124,58,237,0.12)' : '#F8F8F4', border: `1px solid ${i === 0 ? 'rgba(124,58,237,0.3)' : 'rgba(15,16,20,0.1)'}`, fontSize: 8, fontWeight: 700, color: i === 0 ? '#7C3AED' : '#4A4A52' }}>{m}</div>
                        ))}
                      </div>
                      {/* tech coach CTA */}
                      <div style={{ background: 'rgba(124,58,237,0.08)', borderRadius: 10, border: '1px solid rgba(124,58,237,0.25)', padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                        <span style={{ fontSize: 14 }}>🎯</span>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: '#7C3AED' }}>Тренер по технике</div>
                          <div style={{ fontSize: 9, color: '#4A4A52' }}>AI-анализ через камеру</div>
                        </div>
                        <span style={{ marginLeft: 'auto', color: '#7C3AED', fontSize: 12 }}>›</span>
                      </div>
                      {/* CTA */}
                      <div style={{ background: '#4D7A00', borderRadius: 10, padding: '8px', textAlign: 'center', fontSize: 11, fontWeight: 800, color: '#fff' }}>▶ Добавить в тренировку</div>
                    </div>
                  </div>
                </div>

                {/* Anchor 3: Workout Player */}
                <div>
                  <div style={{ fontSize: 11, color: C.fg3, marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>3 · Workout Player</div>
                  <div style={{ borderRadius: 16, overflow: 'hidden', border: `1px solid ${C.bd2}`, background: '#F2F2EE' }}>
                    {/* top */}
                    <div style={{ padding: '10px 12px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid rgba(15,16,20,0.08)' }}>
                      <span style={{ fontSize: 10, color: '#909098' }}>‹ Назад</span>
                      <div style={{ fontSize: 9, color: '#4D7A00', fontWeight: 800, background: 'rgba(77,122,0,0.1)', padding: '3px 8px', borderRadius: 99 }}>⏱ 12:34</div>
                    </div>
                    <div style={{ padding: '10px 12px' }}>
                      <div style={{ fontSize: 9, color: '#909098', marginBottom: 2 }}>УПРАЖНЕНИЕ 2 ИЗ 5</div>
                      <div style={{ fontSize: 15, fontWeight: 900, color: '#0F1014', marginBottom: 8 }}>Жим гантелей лёжа</div>
                      {/* sets */}
                      <div style={{ display: 'flex', gap: 5, marginBottom: 10 }}>
                        {[1,2,3,4].map(i => (
                          <div key={i} style={{ flex: 1, height: 24, borderRadius: 6, background: i <= 2 ? '#4D7A00' : '#FFFFFF', border: `1px solid ${i <= 2 ? '#4D7A00' : 'rgba(15,16,20,0.12)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <span style={{ fontSize: 9, fontWeight: 800, color: i <= 2 ? '#fff' : '#909098' }}>С{i}</span>
                          </div>
                        ))}
                      </div>
                      {/* weight/reps row */}
                      <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                        {[{ label: 'Вес (кг)', val: '32.5' }, { label: 'Повторений', val: '10' }].map(f => (
                          <div key={f.label} style={{ flex: 1, background: '#FFFFFF', borderRadius: 10, padding: '6px 10px', border: '1px solid rgba(15,16,20,0.1)' }}>
                            <div style={{ fontSize: 8, color: '#909098', fontWeight: 600, marginBottom: 2 }}>{f.label}</div>
                            <div style={{ fontSize: 18, fontWeight: 900, color: '#0F1014', textAlign: 'center' }}>{f.val}</div>
                          </div>
                        ))}
                      </div>
                      {/* CTA */}
                      <div style={{ background: '#4D7A00', borderRadius: 10, padding: '8px', textAlign: 'center', fontSize: 11, fontWeight: 800, color: '#fff' }}>✓ Подход выполнен</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            <div style={{ height: 16 }} />
          </div>
        )}

        {/* ── GATES ─────────────────────────────────────────────────── */}
        {tab === 'gates' && (
          <DecisionRegistry />
        )}
        {false && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ background: C.s2, borderRadius: 14, padding: 14, border: `1px solid ${C.bd}`, fontSize: 13, color: C.fg2, lineHeight: 1.6 }}>
              Дизайн делается гейт за гейтом.
            </div>
            {DESIGN_GATES.map((gate) => {
              const col = gateStatusColor(gate.status)
              return (
                <div key={gate.id} style={{ background: C.s2, borderRadius: 16, border: `1.5px solid ${gate.status === 'next' ? C.acc : C.bd}`, overflow: 'hidden' }}>
                  <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 10, background: bc(col, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: 11, fontWeight: 800, color: col }}>{gate.id}</span>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: C.fg, lineHeight: 1.2 }}>{gate.label}</div>
                    </div>
                    <div style={{ padding: '4px 10px', borderRadius: 99, background: bc(col, 0.13), fontSize: 11, fontWeight: 700, color: col, flexShrink: 0 }}>
                      {gateStatusLabel(gate.status)}
                    </div>
                  </div>
                  {gate.status !== 'pending' && (
                    <div style={{ padding: '8px 14px 12px', display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                      {gate.screens.map((s) => (
                        <Chip key={s} label={s} color={C.s3} text={gate.status === 'done' ? C.fg3 : C.fg2} small />
                      ))}
                    </div>
                  )}
                </div>
              )
            })}

            {/* D1 rationale */}
            <Card style={{ padding: 16 }}>
              <Label color={C.acc}>D1 — Rationale</Label>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  'Аудит выявил 10 системных проблем с before/after решениями',
                  'IA охватывает все 5 разделов с вложенными подразделами по спеку',
                  '22 semantic токена цвета покрывают все UI и camera states',
                  'Типографическая шкала: 11 ступеней от Display до Caption',
                  'Spacing 4–48, Radius 8–Full, 21 core component',
                  'Happy path prototype: 22 экрана от First Launch до Home updated',
                  'Glassmorphism только в 4 контекстах, не на scroll-карточках',
                ].map((r, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8 }}>
                    <span style={{ fontSize: 11, color: C.acc, fontWeight: 800, flexShrink: 0, marginTop: 1 }}>✓</span>
                    <span style={{ fontSize: 12, color: C.fg2, lineHeight: 1.5 }}>{r}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Unresolved D1–D9 */}
            {[
              {
                id: 'D1', label: 'Research, Audit, IA & Design System', status: 'done' as const,
                questions: [
                  'Light theme — полная система или только ключевые экраны в D9?',
                  'Нужен ли отдельный экран Developer Handoff или только Figma-аннотации?',
                  'Token naming convention — утвердить финальный словарь до D9?',
                ],
              },
              {
                id: 'D2', label: 'Onboarding & Body Metrics', status: 'done' as const,
                questions: [
                  'Health Connect — Android only или stub на iOS тоже?',
                  'Какие метрики обязательны на онбординге, а какие можно перенести в Profile?',
                  'Отображать ли BMI или только вес и цель?',
                  'Onboarding skip — разрешить ли полный пропуск или минимум 3 шага?',
                ],
              },
              {
                id: 'D3', label: 'Home & Navigation', status: 'done' as const,
                questions: [
                  'Recovery score — расчёт на устройстве или серверный endpoint?',
                  'Карточка «Фото прогресса» на Home — показывать всегда или только после milestone?',
                  'Notch / Dynamic Island — нужна ли отдельная адаптация header?',
                ],
              },
              {
                id: 'D4', label: 'Scanner & Equipment', status: 'done' as const,
                questions: [
                  'Offline база оборудования — какой объём покрывать в MVP?',
                  'Unknown equipment — отправлять в коллекцию для обучения модели?',
                  'Нужен ли ручной ввод названия тренажёра как fallback?',
                  'Equipment Page — полноценный экран или только bottom sheet?',
                ],
              },
              {
                id: 'D5', label: 'Exercise & Workout Player', status: 'done' as const,
                questions: [
                  'Автоприрост веса — предлагать сразу или по итогу 2–3 тренировок?',
                  'Rest Timer — звук по умолчанию вкл или выкл?',
                  'Supersets и Drop-sets — в MVP или D8+?',
                  'Замена упражнения во время тренировки — история изменений нужна?',
                ],
              },
              {
                id: 'D6', label: 'Тренер по технике & Workout Summary', status: 'next' as const,
                questions: [
                  'Form Check — real ML модель (MediaPipe/MoveNet) или только анимированный прототип?',
                  'Какие упражнения поддерживаются в первом релизе — список согласован?',
                  'Для каких упражнений требуется боковой ракурс, для каких — фронтальный?',
                  'Сохраняется ли история Form Check сессий в workout log?',
                  'Голосовые подсказки — TTS на устройстве или записанные файлы?',
                  'Нужен ли выбор языка озвучки (RU / EN)?',
                  'Summary — показывать процент «оценено уверенно» пользователю?',
                  'Workout Summary — интегрировать в существующий WorkoutDone или отдельный экран?',
                ],
              },
              {
                id: 'D7', label: 'Progress & Progress Photos', status: 'done' as const,
                questions: [
                  'Storage policy для Progress Photos — local-only vs cloud backup?',
                  'Нужна ли автоматическая анонимизация лица перед экспортом?',
                  'Какие milestone-теги стандартные, а какие пользовательские?',
                  'Сравнение разных ракурсов — запретить или предупредить?',
                ],
              },
              {
                id: 'D8', label: 'Programs, AI Coach, Profile, Subscription', status: 'pending' as const,
                questions: [
                  'Paywall placement — после Plan Preview, сразу при старте или только по достижению лимита?',
                  'Free tier лимиты — сколько программ, сколько сессий Form Check, сколько фото?',
                  'AI Coach — контекстный (только внутри тренировки) или доступен глобально?',
                  'AI Coach backend — Claude API, fine-tuned модель, или правила?',
                  'Стоимость и периоды подписки — только месяц/год или есть квартал?',
                  'Семейная подписка — в scope или нет?',
                  'Profile — экспорт всех данных нужен в MVP?',
                  'Интеграция с носимыми (Garmin, Polar) — в каком гейте?',
                ],
              },
              {
                id: 'D9', label: 'States, Accessibility, Platform & Prototype', status: 'pending' as const,
                questions: [
                  'Поддержка iOS + Android — единая React Native кодовая база или нативные?',
                  'Минимальная версия ОС — Android 8+ / iOS 15+?',
                  'Light theme — делаем в D9 или переносим в post-launch?',
                  'Reduced motion — полный набор альтернативных анимаций нужен?',
                  'Screen reader тестирование — на каком этапе (QA или D9)?',
                  'Offline режим — какие экраны должны работать без сети в MVP?',
                  'Push-уведомления — тренировки, фото, рекорды — согласован список?',
                  'End-to-end prototype — на каком инструменте (Figma / React) финальный?',
                ],
              },
            ].map((gate) => {
              const statusCol = gate.status === 'done' ? C.ok : gate.status === 'next' ? C.acc : C.fg3
              const statusLabel = gate.status === 'done' ? 'Готово' : gate.status === 'next' ? 'В работе' : 'Ожидает'
              return (
                <div key={gate.id} style={{ background: C.s2, borderRadius: 16, border: `1px solid ${gate.status === 'next' ? bc(C.acc, 0.4) : C.bd}`, overflow: 'hidden', marginBottom: 10 }}>
                  {/* Gate header */}
                  <div style={{ padding: '12px 14px 10px', borderBottom: `1px solid ${C.bd}`, display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 28, height: 28, borderRadius: 8, background: bc(statusCol, 0.15), border: `1.5px solid ${bc(statusCol, 0.4)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: 10, fontWeight: 800, color: statusCol }}>{gate.id}</span>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: C.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{gate.label}</div>
                    </div>
                    <div style={{ padding: '3px 9px', borderRadius: 99, background: bc(statusCol, 0.12), border: `1px solid ${bc(statusCol, 0.3)}`, flexShrink: 0 }}>
                      <span style={{ fontSize: 10, fontWeight: 700, color: statusCol }}>{statusLabel}</span>
                    </div>
                  </div>
                  {/* Questions */}
                  <div style={{ padding: '10px 14px 12px' }}>
                    {gate.questions.map((q, i) => (
                      <div key={i} style={{ display: 'flex', gap: 8, marginBottom: i < gate.questions.length - 1 ? 7 : 0 }}>
                        <span style={{ fontSize: 11, color: C.warn, fontWeight: 800, flexShrink: 0, marginTop: 2 }}>?</span>
                        <span style={{ fontSize: 12, color: C.fg2, lineHeight: 1.5 }}>{q}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}

            {/* Summary count */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
              {[
                { label: 'Всего вопросов', val: '44', col: C.fg },
                { label: 'Блокируют D6', val: '8', col: C.warn },
                { label: 'Блокируют D8–D9', val: '16', col: C.err },
              ].map((s) => (
                <div key={s.label} style={{ flex: 1, background: C.s3, borderRadius: 12, border: `1px solid ${C.bd}`, padding: '10px 8px', textAlign: 'center' }}>
                  <div className="font-display" style={{ fontSize: 20, fontWeight: 800, color: s.col }}>{s.val}</div>
                  <div style={{ fontSize: 10, color: C.fg3, marginTop: 2, lineHeight: 1.3 }}>{s.label}</div>
                </div>
              ))}
            </div>

            <div style={{ background: bc(C.acc, 0.08), borderRadius: 14, border: `1px solid ${bc(C.acc, 0.3)}`, padding: '12px 16px', fontSize: 13, color: C.acc, fontWeight: 600, textAlign: 'center' }}>
              Текущий приоритет → D6 Тренер по технике
            </div>
            <div style={{ height: 16 }} />
          </div>
        )}

      </div>

      <div style={{ padding: '12px 20px 28px', flexShrink: 0, background: C.bg, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {onVariants && (
          <button onClick={onVariants} style={{ width: '100%', padding: '13px 20px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, cursor: 'pointer', background: C.s2, color: C.fg, fontSize: 15, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <span>👁</span><span>Сравнить 3 варианта Body Metrics</span>
          </button>
        )}
        <button onClick={onStart} style={{ width: '100%', padding: '16px 20px', borderRadius: 16, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 17, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: `0 0 32px ${bc(C.acc, 0.3)}` }}>
          <span>Запустить прототип D2–D7</span><span style={{ fontSize: 20 }}>→</span>
        </button>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// 2. ONBOARDING FLOW
// ══════════════════════════════════════════════════════════════════════════════
interface OnboardingData {
  goal: string
  level: string
  location: string
  equipment: string[]
  daysPerWeek: number
  duration: number
  injuries: string[]
  focusZones: string[]
  barriers: string[]
  birthYear: number | null
  heightCm: number
  weightKg: number | null
  targetWeightKg: number | null
}

const defaultOb: OnboardingData = {
  goal: '', level: '', location: '', equipment: [], daysPerWeek: 4, duration: 45,
  injuries: [], focusZones: [], barriers: [],
  birthYear: null, heightCm: 178, weightKg: null, targetWeightKg: null,
}

const TOTAL_OB_STEPS = 9

const OBHeader = ({ step, onBack, title, subtitle }: { step: number; onBack: () => void; title: string; subtitle?: string }) => (
  <div style={{ padding: '44px 20px 0', flexShrink: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
      <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: '50%', background: C.s3, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.fg2, fontSize: 16 }}>‹</button>
      <div style={{ flex: 1, height: 3, borderRadius: 99, background: C.s3, overflow: 'hidden' }}>
        <div className="bar-progress" style={{ height: '100%', borderRadius: 99, background: C.acc, width: `${(step / TOTAL_OB_STEPS) * 100}%`, transition: 'width 0.4s cubic-bezier(0.16,1,0.3,1)' }} />
      </div>
      <span style={{ fontSize: 12, fontWeight: 600, color: C.fg3, minWidth: 36, textAlign: 'right' }}>{step}/{TOTAL_OB_STEPS}</span>
    </div>
    <h2 className="font-display" style={{ fontSize: 30, fontWeight: 800, color: C.fg, margin: '0 0 4px', lineHeight: 1.1 }}>{title}</h2>
    {subtitle && <p style={{ fontSize: 13, color: C.fg2, margin: 0, lineHeight: 1.5 }}>{subtitle}</p>}
  </div>
)

const ChoiceCard = ({
  label, desc, icon, selected, onClick, multi
}: { label: string; desc?: string; icon?: string; selected: boolean; onClick: () => void; multi?: boolean }) => (
  <button onClick={onClick} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderRadius: 14, border: `1.5px solid ${selected ? C.acc : C.bd2}`, background: selected ? bc(C.acc, 0.08) : C.s2, cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' }}>
    {icon && <span style={{ fontSize: 20, width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 10, background: selected ? bc(C.acc, 0.15) : C.s3, flexShrink: 0 }}>{icon}</span>}
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 15, fontWeight: 600, color: selected ? C.acc : C.fg, lineHeight: 1.2 }}>{label}</div>
      {desc && <div style={{ fontSize: 12, color: C.fg2, marginTop: 1, lineHeight: 1.35 }}>{desc}</div>}
    </div>
    <div style={{ width: 22, height: 22, borderRadius: multi ? 6 : '50%', border: `2px solid ${selected ? C.acc : C.fg3}`, background: selected ? C.acc : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.15s' }}>
      {selected && <span style={{ color: '#060F00', fontSize: 12, fontWeight: 800 }}>✓</span>}
    </div>
  </button>
)

// ── STEP 0 — Value Proposition ────────────────────────────────────────────────
const Step0 = ({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    {/* Hero visual */}
    <div style={{ flex: 1, background: `linear-gradient(160deg, #0D0D1A 0%, #06060F 100%)`, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
      {/* Animated accent glow */}
      <div style={{ position: 'absolute', width: 280, height: 280, borderRadius: '50%', background: `radial-gradient(circle, ${bc(C.acc, 0.12)} 0%, transparent 70%)`, top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }} />
      {/* Scan icon */}
      <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24 }}>
        <div style={{ width: 120, height: 120, borderRadius: 32, background: C.s2, border: `1.5px solid ${C.bd2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 40px ${bc(C.acc, 0.2)}` }}>
          <span style={{ fontSize: 52 }}>◉</span>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['Скан', 'Упражнение', 'Техника'].map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Chip label={s} color={bc(C.acc, 0.1)} text={C.acc} small />
              {i < 2 && <span style={{ color: C.fg3, fontSize: 12 }}>→</span>}
            </div>
          ))}
        </div>
      </div>
      {/* Grid decoration */}
      <div style={{ position: 'absolute', inset: 0, backgroundImage: `linear-gradient(${C.bd} 1px, transparent 1px), linear-gradient(90deg, ${C.bd} 1px, transparent 1px)`, backgroundSize: '40px 40px', pointerEvents: 'none', maskImage: 'radial-gradient(circle, black 30%, transparent 80%)' }} />
    </div>

    <div style={{ padding: '28px 24px 40px', flexShrink: 0 }}>
      <h1 className="font-display" style={{ fontSize: 40, fontWeight: 900, color: C.fg, margin: '0 0 10px', lineHeight: 1.05 }}>
        Твой AI-помощник<br />в тренажёрном зале
      </h1>
      <p style={{ fontSize: 15, color: C.fg2, margin: '0 0 28px', lineHeight: 1.6 }}>
        Распознавай тренажёры, получай персональные упражнения и проверяй технику камерой.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn label="Настроить мой план" onClick={onNext} />
        <button onClick={onSkip} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg2, padding: '10px 0' }}>Продолжить без регистрации</button>
      </div>
    </div>
  </div>
)

// ── STEP 1 — Goal ─────────────────────────────────────────────────────────────
const GOALS = [
  { label: 'Набрать мышцы',         icon: '💪', desc: 'Увеличить мышечную массу и объём' },
  { label: 'Стать сильнее',         icon: '🏋️', desc: 'Повысить рабочие веса в базовых движениях' },
  { label: 'Снизить вес',           icon: '⚡', desc: 'Сжигание жира и улучшение состава тела' },
  { label: 'Улучшить форму',        icon: '✦',  desc: 'Общий фитнес и функциональность' },
  { label: 'Повысить выносливость', icon: '🔄', desc: 'Кардио и аэробные показатели' },
  { label: 'Вернуться после перерыва', icon: '↩', desc: 'Восстановление уровня после паузы' },
]

// ── STEP 1 — Goal + Level (merged) ───────────────────────────────────────────
const Step1 = ({ goal, level, onGoal, onLevel, onNext, onBack }: {
  goal: string; level: string; onGoal: (v: string) => void; onLevel: (v: string) => void; onNext: () => void; onBack: () => void
}) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <OBHeader step={1} onBack={onBack} title="Цель и уровень" subtitle="Два вопроса — и мы знаем с чего начать" />
    <div style={{ flex: 1, overflowY: 'auto', padding: '12px 20px' }}>
      {/* Goals */}
      <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Главная цель</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 20 }}>
        {GOALS.map((g) => (
          <ChoiceCard key={g.label} label={g.label} desc={g.desc} icon={g.icon} selected={goal === g.label} onClick={() => onGoal(g.label)} />
        ))}
      </div>
      {/* Level */}
      <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Уровень подготовки</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {LEVELS.map((l) => (
          <ChoiceCard key={l.label} label={l.label} desc={l.desc} icon={l.icon} selected={level === l.label} onClick={() => onLevel(l.label)} />
        ))}
      </div>
      <div style={{ height: 12 }} />
    </div>
    <div style={{ padding: '12px 20px 28px', flexShrink: 0 }}>
      <Btn label="Продолжить" onClick={onNext} variant={goal && level ? 'primary' : 'ghost'} />
    </div>
  </div>
)

// ── STEP 2 — Level ────────────────────────────────────────────────────────────
const LEVELS = [
  { label: 'Начинаю впервые',  icon: '○', desc: 'Ещё не занимался с отягощениями' },
  { label: 'Новичок',          icon: '◌', desc: 'До 6 месяцев регулярных тренировок' },
  { label: 'Средний',          icon: '◑', desc: 'От 6 месяцев до 2 лет' },
  { label: 'Опытный',          icon: '●', desc: 'Более 2 лет стабильных тренировок' },
]

// ── STEP 2 — Location + Equipment (merged) ───────────────────────────────────
const LOCATIONS = [
  { label: 'Тренажёрный зал', icon: '🏛', desc: 'Полный набор оборудования' },
  { label: 'Дом',             icon: '🏠', desc: 'Домашние тренировки' },
  { label: 'Улица',           icon: '⛅', desc: 'Воркаут и открытые площадки' },
  { label: 'Смешанный режим', icon: '↔', desc: 'Зал и дом в разные дни' },
]

const EQUIPMENT_OPTIONS = [
  { label: 'Полный тренажёрный зал', icon: '🏋️' },
  { label: 'Отдельные тренажёры',    icon: '⚙' },
  { label: 'Гантели',                icon: '◎' },
  { label: 'Штанга',                 icon: '━' },
  { label: 'Гири',                   icon: '◉' },
  { label: 'Резинки',                icon: '〜' },
  { label: 'Собственный вес',        icon: '○' },
  { label: 'Буду распознавать камерой', icon: '📷' },
]

const Step2 = ({ location, equipment, onLocation, onEquipment, onNext, onBack }: {
  location: string; equipment: string[]; onLocation: (v: string) => void; onEquipment: (v: string[]) => void; onNext: () => void; onBack: () => void
}) => {
  const toggle = (item: string) => onEquipment(equipment.includes(item) ? equipment.filter((v) => v !== item) : [...equipment, item])
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <OBHeader step={2} onBack={onBack} title="Место и оборудование" subtitle="Адаптируем под то, что реально доступно" />
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 20px' }}>
        {/* Location */}
        <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Где тренируешься?</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 20 }}>
          {LOCATIONS.map((l) => (
            <ChoiceCard key={l.label} label={l.label} desc={l.desc} icon={l.icon} selected={location === l.label} onClick={() => onLocation(l.label)} />
          ))}
        </div>
        {/* Equipment */}
        <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Что доступно? <span style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0, fontSize: 11, color: C.fg3 }}>(несколько)</span></div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {EQUIPMENT_OPTIONS.map((e) => {
            const sel = equipment.includes(e.label)
            return (
              <button key={e.label} onClick={() => toggle(e.label)} style={{ padding: '9px 14px', borderRadius: 12, border: `1.5px solid ${sel ? C.acc : C.bd2}`, background: sel ? bc(C.acc, 0.1) : C.s2, color: sel ? C.acc : C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, transition: 'all 0.12s' }}>
                <span>{e.icon}</span>{e.label}
              </button>
            )
          })}
        </div>
        <div style={{ height: 12 }} />
      </div>
      <div style={{ padding: '12px 20px 28px', flexShrink: 0 }}>
        <Btn label="Продолжить" onClick={onNext} variant={location ? 'primary' : 'ghost'} />
      </div>
    </div>
  )
}

// ── STEP 3 — Schedule ─────────────────────────────────────────────────────────
const Step3 = ({ days, duration, onDays, onDuration, onNext, onBack }: {
  days: number; duration: number; onDays: (n: number) => void; onDuration: (n: number) => void; onNext: () => void; onBack: () => void
}) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <OBHeader step={3} onBack={onBack} title="Тренировочный график" subtitle="Реалистичный план — лучший план" />
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Days per week */}
        <Card style={{ padding: 14 }}>
          <Label>Дней в неделю</Label>
          <div className="font-display" style={{ fontSize: 40, fontWeight: 800, color: C.acc, margin: '6px 0 10px', lineHeight: 1 }}>{days}</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {[2, 3, 4, 5, 6].map((d) => (
              <button key={d} onClick={() => onDays(d)} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: `1.5px solid ${days === d ? C.acc : C.bd2}`, background: days === d ? bc(C.acc, 0.12) : C.s3, color: days === d ? C.acc : C.fg2, fontWeight: 700, fontSize: 15, cursor: 'pointer', transition: 'all 0.15s' }}>
                {d}
              </button>
            ))}
          </div>
        </Card>
        {/* Duration */}
        <Card style={{ padding: 14 }}>
          <Label>Длительность занятия</Label>
          <div className="font-display" style={{ fontSize: 40, fontWeight: 800, color: C.acc, margin: '6px 0 10px', lineHeight: 1 }}>{duration}<span style={{ fontSize: 20, color: C.fg2, fontWeight: 600 }}> мин</span></div>
          <div style={{ display: 'flex', gap: 6 }}>
            {[30, 45, 60, 75, 90].map((d) => (
              <button key={d} onClick={() => onDuration(d)} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: `1.5px solid ${duration === d ? C.acc : C.bd2}`, background: duration === d ? bc(C.acc, 0.12) : C.s3, color: duration === d ? C.acc : C.fg2, fontWeight: 700, fontSize: 13, cursor: 'pointer', transition: 'all 0.15s' }}>
                {d}
              </button>
            ))}
          </div>
        </Card>
        {/* Preferred days */}
        <Card style={{ padding: 14 }}>
          <Label>Предпочтительные дни</Label>
          <div style={{ display: 'flex', gap: 5, marginTop: 10 }}>
            {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((d, i) => {
              const active = [0, 2, 4, 6].slice(0, days).includes(i)
              return (
                <div key={d} style={{ flex: 1, padding: '9px 0', borderRadius: 10, border: `1.5px solid ${active ? C.acc : C.bd}`, background: active ? bc(C.acc, 0.12) : 'transparent', color: active ? C.acc : C.fg3, fontWeight: 600, fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {d}
                </div>
              )
            })}
          </div>
          <p style={{ fontSize: 11, color: C.fg3, margin: '8px 0 0', lineHeight: 1.4 }}>Можно изменить после. Уведомления настроим отдельно.</p>
        </Card>
      </div>
    </div>
    <div style={{ padding: '12px 20px 28px', flexShrink: 0 }}>
      <Btn label="Продолжить" onClick={onNext} />
    </div>
  </div>
)

// ── STEP 4 — Body: Injuries + Focus (merged with toggle) ─────────────────────
const INJURY_ZONES = [
  { id: 'shoulder', label: 'Плечо',           x: 0 },
  { id: 'elbow',    label: 'Локоть',           x: 0 },
  { id: 'wrist',    label: 'Запястье',         x: 0 },
  { id: 'upper-back', label: 'Верх спины',    x: 0 },
  { id: 'lower-back', label: 'Поясница',      x: 0 },
  { id: 'hip',      label: 'Тазобедренный',   x: 0 },
  { id: 'knee',     label: 'Колено',           x: 0 },
  { id: 'ankle',    label: 'Голеностоп',       x: 0 },
  { id: 'none',     label: 'Ограничений нет',  x: 0 },
]

const BodyDiagram = ({ selected, onToggle, mode }: { selected: string[]; onToggle: (id: string) => void; mode: 'injury' | 'focus' }) => {
  const zones = mode === 'injury'
    ? [
        { id: 'shoulder',   label: 'Плечо',      cx: 68, cy: 88,  r: 14 },
        { id: 'elbow',      label: 'Локоть',     cx: 46, cy: 132, r: 12 },
        { id: 'wrist',      label: 'Запястье',   cx: 34, cy: 168, r: 10 },
        { id: 'upper-back', label: 'Верх спины', cx: 100, cy: 108, r: 16 },
        { id: 'lower-back', label: 'Поясница',   cx: 100, cy: 148, r: 14 },
        { id: 'hip',        label: 'Таз',        cx: 92, cy: 182, r: 13 },
        { id: 'knee',       label: 'Колено',     cx: 82, cy: 232, r: 12 },
        { id: 'ankle',      label: 'Голень',     cx: 82, cy: 272, r: 10 },
      ]
    : [
        { id: 'chest',      label: 'Грудь',      cx: 100, cy: 108, r: 18 },
        { id: 'back',       label: 'Спина',      cx: 60,  cy: 108, r: 16 },
        { id: 'shoulders',  label: 'Плечи',      cx: 72,  cy: 84,  r: 14 },
        { id: 'arms',       label: 'Руки',       cx: 46,  cy: 128, r: 12 },
        { id: 'core',       label: 'Пресс',      cx: 100, cy: 148, r: 16 },
        { id: 'glutes',     label: 'Ягодицы',    cx: 80,  cy: 178, r: 14 },
        { id: 'legs',       label: 'Ноги',       cx: 86,  cy: 232, r: 18 },
      ]

  return (
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <svg viewBox="0 0 160 310" width={180} height={310}>
        {/* Body silhouette */}
        <ellipse cx="100" cy="36" rx="18" ry="20" fill={C.s3} />
        <rect x="75" y="54" width="50" height="8" rx="4" fill={C.s3} />
        <rect x="62" y="62" width="76" height="80" rx="12" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        <rect x="28" y="64" width="32" height="80" rx="10" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        <rect x="140" y="64" width="32" height="80" rx="10" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        <rect x="70" y="142" width="60" height="65" rx="10" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        <rect x="68" y="207" width="26" height="75" rx="8" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        <rect x="106" y="207" width="26" height="75" rx="8" fill={C.s2} stroke={C.bd2} strokeWidth="1" />
        {/* Zone hotspots */}
        {zones.map((z) => {
          const sel = selected.includes(z.id)
          return (
            <g key={z.id} style={{ cursor: 'pointer' }} onClick={() => onToggle(z.id)}>
              <circle cx={z.cx} cy={z.cy} r={z.r + 2} fill={sel ? bc(mode === 'injury' ? C.err : C.acc, 0.2) : 'transparent'} />
              <circle cx={z.cx} cy={z.cy} r={z.r} fill={sel ? (mode === 'injury' ? C.err : C.acc) : C.s3} stroke={sel ? 'transparent' : C.bd2} strokeWidth="1.5" opacity={sel ? 1 : 0.7} />
              {sel && <text x={z.cx} y={z.cy + 4} textAnchor="middle" fontSize="10" fill={mode === 'injury' ? '#fff' : '#060F00'} fontWeight="700">✓</text>}
            </g>
          )
        })}
      </svg>
    </div>
  )
}

const FOCUS_ZONES_OPT = ['Грудь', 'Спина', 'Плечи', 'Руки', 'Пресс', 'Ягодицы', 'Ноги', 'Всё тело']

const Step4 = ({ injuries, focusZones, onInjuries, onFocus, onNext, onBack }: {
  injuries: string[]; focusZones: string[]; onInjuries: (v: string[]) => void; onFocus: (v: string[]) => void; onNext: () => void; onBack: () => void
}) => {
  const [mode, setMode] = useState<'injury' | 'focus'>('injury')

  const toggleInjury = (id: string) => {
    if (id === 'none') { onInjuries(['none']); return }
    const without = injuries.filter((v) => v !== 'none')
    onInjuries(without.includes(id) ? without.filter((v) => v !== id) : [...without, id])
  }
  const toggleFocus = (item: string) => {
    if (item === 'Всё тело') { onFocus(['Всё тело']); return }
    const without = focusZones.filter((v) => v !== 'Всё тело')
    onFocus(without.includes(item) ? without.filter((v) => v !== item) : [...without, item])
  }

  const isInjury = mode === 'injury'
  const chips = isInjury ? INJURY_ZONES : FOCUS_ZONES_OPT.map((l) => ({ id: l.toLowerCase(), label: l }))

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <OBHeader step={4} onBack={onBack} title="Тело" subtitle={isInjury ? 'Что обходим стороной?' : 'На чём сосредоточиться?'} />

      {/* Mode toggle */}
      <div style={{ padding: '0 20px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', background: C.s2, borderRadius: 12, padding: 3, gap: 2, border: `1px solid ${C.bd}` }}>
          {(['injury', 'focus'] as const).map((m) => (
            <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: '9px', borderRadius: 9, border: 'none', cursor: 'pointer', background: mode === m ? (m === 'injury' ? bc(C.err, 0.18) : bc(C.acc, 0.15)) : 'transparent', color: mode === m ? (m === 'injury' ? C.err : C.acc) : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s' }}>
              {m === 'injury' ? '⚠ Ограничения' : '◎ Приоритеты'}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Body diagram */}
        <BodyDiagram
          selected={isInjury ? injuries : focusZones.map((v) => v.toLowerCase())}
          onToggle={isInjury ? toggleInjury : (id) => toggleFocus(FOCUS_ZONES_OPT.find((z) => z.toLowerCase() === id) ?? id)}
          mode={mode}
        />
        {/* Chips */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
          {isInjury
            ? INJURY_ZONES.map((z) => {
                const sel = injuries.includes(z.id)
                return (
                  <button key={z.id} onClick={() => toggleInjury(z.id)} style={{ padding: '7px 13px', borderRadius: 99, border: `1.5px solid ${sel ? C.err : C.bd2}`, background: sel ? bc(C.err, 0.12) : C.s2, color: sel ? C.err : C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'all 0.12s' }}>
                    {z.label}
                  </button>
                )
              })
            : FOCUS_ZONES_OPT.map((z) => {
                const sel = focusZones.includes(z)
                return (
                  <button key={z} onClick={() => toggleFocus(z)} style={{ padding: '7px 13px', borderRadius: 99, border: `1.5px solid ${sel ? C.acc : C.bd2}`, background: sel ? bc(C.acc, 0.12) : C.s2, color: sel ? C.acc : C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'all 0.12s' }}>
                    {z}
                  </button>
                )
              })
          }
        </div>
        <div style={{ height: 12 }} />
      </div>
      <div style={{ padding: '12px 20px 28px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {isInjury
          ? <Btn label="К приоритетам →" onClick={() => setMode('focus')} />
          : <Btn label="Продолжить" onClick={onNext} />
        }
        <button onClick={onNext} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg3 }}>Пропустить этот шаг</button>
      </div>
    </div>
  )
}

// ── STEP 5 — Barriers ─────────────────────────────────────────────────────────
const BARRIERS = [
  { label: 'Не знаю, какие упражнения выбрать', icon: '?' },
  { label: 'Не понимаю, как пользоваться тренажёрами', icon: '⚙' },
  { label: 'Сомневаюсь в правильности техники', icon: '👁' },
  { label: 'Не хватает времени', icon: '⏱' },
  { label: 'Сложно сохранять регулярность', icon: '↻' },
  { label: 'Есть дискомфорт или ограничения', icon: '⚠' },
  { label: 'Ничего из перечисленного', icon: '✓' },
]

const Step5 = ({ value, onChange, onNext, onBack }: { value: string[]; onChange: (v: string[]) => void; onNext: () => void; onBack: () => void }) => {
  const toggle = (item: string) => {
    if (item === 'Ничего из перечисленного') { onChange([item]); return }
    const without = value.filter((v) => v !== 'Ничего из перечисленного')
    onChange(without.includes(item) ? without.filter((v) => v !== item) : [...without, item])
  }
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <OBHeader step={5} onBack={onBack} title="Что обычно мешает?" subtitle="Поможем именно с вашими барьерами" />
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {BARRIERS.map((b) => (
            <ChoiceCard key={b.label} label={b.label} icon={b.icon} selected={value.includes(b.label)} onClick={() => toggle(b.label)} multi />
          ))}
        </div>
      </div>
      <div style={{ padding: '12px 20px 28px', flexShrink: 0 }}>
        <Btn label={value.length > 0 ? 'Продолжить' : 'Пропустить'} onClick={onNext} variant={value.length > 0 ? 'primary' : 'ghost'} />
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// BODY METRICS — Shared helpers + picker components
// ══════════════════════════════════════════════════════════════════════════════

// BMI helpers
function calcBMI(weightKg: number, heightCm: number) {
  const hm = heightCm / 100
  const bmi = Math.round((weightKg / (hm * hm)) * 10) / 10
  const low  = Math.round(18.5 * hm * hm * 10) / 10
  const high = Math.round(24.9 * hm * hm * 10) / 10
  const status = bmi < 18.5 ? 'below' : bmi < 25 ? 'within' : bmi < 30 ? 'above' : 'high'
  const diffLow  = Math.round((weightKg - low)  * 10) / 10
  const diffHigh = Math.round((weightKg - high) * 10) / 10
  return { bmi, low, high, status, diffLow, diffHigh }
}

// Unit toggle
const UnitToggle = ({ options, active, onChange }: { options: string[]; active: string; onChange: (v: string) => void }) => (
  <div style={{ display: 'flex', flexDirection: 'column', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd2}`, overflow: 'hidden', flexShrink: 0 }}>
    {options.map((o) => (
      <button key={o} onClick={() => onChange(o)} style={{ padding: '8px 14px', background: active === o ? C.acc : 'transparent', color: active === o ? '#060F00' : C.fg2, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 700, transition: 'all 0.15s' }}>
        {o}
      </button>
    ))}
  </div>
)

// ── WHEEL YEAR PICKER ─────────────────────────────────────────────────────────
const YEARS = Array.from({ length: 71 }, (_, i) => 1940 + i)
const WHEEL_ITEM_H = 68

const WheelYear = ({ value, onChange }: { value: number; onChange: (v: number) => void }) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const preventRef   = useRef(false)

  // Sync scroll → selected year
  const handleScroll = useCallback(() => {
    if (preventRef.current) return
    const el = containerRef.current
    if (!el) return
    const idx = Math.round(el.scrollTop / WHEEL_ITEM_H)
    const clamped = Math.max(0, Math.min(YEARS.length - 1, idx))
    if (YEARS[clamped] !== value) onChange(YEARS[clamped])
  }, [value, onChange])

  // Sync value → scroll (only when changed from outside / initial)
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const idx = YEARS.indexOf(value)
    if (idx < 0) return
    const target = idx * WHEEL_ITEM_H
    if (Math.abs(el.scrollTop - target) < 2) return
    preventRef.current = true
    el.scrollTo({ top: target, behavior: 'smooth' })
    const t = setTimeout(() => { preventRef.current = false }, 400)
    return () => clearTimeout(t)
  }, [value])

  // Initial scroll (no animation)
  useLayoutEffect(() => {
    const el = containerRef.current
    if (!el) return
    const idx = YEARS.indexOf(value)
    if (idx >= 0) { preventRef.current = true; el.scrollTop = idx * WHEEL_ITEM_H; setTimeout(() => { preventRef.current = false }, 50) }
  }, []) // eslint-disable-line

  const selIdx = YEARS.indexOf(value)

  return (
    <div style={{ position: 'relative', height: WHEEL_ITEM_H * 5, overflow: 'hidden', cursor: 'ns-resize' }}>
      {/* Top fade */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '38%', background: `linear-gradient(to bottom, ${C.bg} 0%, transparent 100%)`, pointerEvents: 'none', zIndex: 3 }} />
      {/* Bottom fade */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '38%', background: `linear-gradient(to top, ${C.bg} 0%, transparent 100%)`, pointerEvents: 'none', zIndex: 3 }} />
      {/* Selected highlight band */}
      <div style={{ position: 'absolute', top: '50%', transform: 'translateY(-50%)', left: 24, right: 24, height: WHEEL_ITEM_H, background: bc(C.acc, 0.07), border: `1.5px solid ${bc(C.acc, 0.22)}`, borderRadius: 16, zIndex: 1, pointerEvents: 'none' }} />
      {/* Scroll container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        style={{ height: '100%', overflowY: 'scroll', scrollSnapType: 'y mandatory', paddingTop: WHEEL_ITEM_H * 2, paddingBottom: WHEEL_ITEM_H * 2 }}
      >
        {YEARS.map((year, idx) => {
          const dist = Math.abs(selIdx - idx)
          return (
            <div
              key={year}
              style={{ height: WHEEL_ITEM_H, scrollSnapAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
              onClick={() => {
                const el = containerRef.current
                if (el) { preventRef.current = true; el.scrollTo({ top: idx * WHEEL_ITEM_H, behavior: 'smooth' }); setTimeout(() => { preventRef.current = false }, 400) }
                onChange(year)
              }}
            >
              <span className="font-display" style={{ fontSize: dist === 0 ? 46 : dist === 1 ? 32 : 24, fontWeight: dist === 0 ? 800 : 500, color: dist === 0 ? C.fg : C.fg2, opacity: Math.max(0.1, 1 - dist * 0.22), lineHeight: 1, userSelect: 'none', transition: 'font-size 0.12s, opacity 0.12s' }}>
                {year}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── HORIZONTAL RULER PICKER (weight) ──────────────────────────────────────────
// valueTenths = value × 10 (integer), e.g. 75.4 kg → 754
const H_PX = 12 // pixels per 0.1 unit

interface HRulerProps {
  valueTenths: number
  minTenths: number
  maxTenths: number
  onChangeTenths: (v: number) => void
  accentTenths?: number  // secondary marker (current weight on target screen)
  height?: number
}

const HRuler = ({ valueTenths, minTenths, maxTenths, onChangeTenths, accentTenths, height = 88 }: HRulerProps) => {
  const canvasRef   = useRef<HTMLCanvasElement>(null)
  const sizeRef     = useRef({ w: 390, h: height, dpr: 1 })
  const dragRef     = useRef<{ startX: number; startVal: number } | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const { w: W, h: H, dpr } = sizeRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.clearRect(0, 0, W * dpr, H * dpr)
    ctx.save()
    ctx.scale(dpr, dpr)

    const cx = W / 2

    // Range fill between accent and center
    if (accentTenths !== undefined) {
      const ax = cx + (accentTenths - valueTenths) * H_PX
      const l = Math.min(ax, cx), r = Math.max(ax, cx)
      ctx.fillStyle = bc(C.acc, 0.09)
      ctx.fillRect(l, 0, r - l, H)
    }

    // Ticks
    for (let t = minTenths; t <= maxTenths; t++) {
      const x = cx + (t - valueTenths) * H_PX
      if (x < -H_PX * 2 || x > W + H_PX * 2) continue
      const is5u  = t % 50 === 0   // every 5 kg
      const is1u  = t % 10 === 0   // every 1 kg
      const tickH = is5u ? 36 : is1u ? 24 : 11
      const alpha = is5u ? 0.9 : is1u ? 0.55 : 0.22
      const lw    = is5u ? 2 : is1u ? 1.5 : 0.75
      ctx.strokeStyle = `rgba(255,255,255,${alpha})`
      ctx.lineWidth = lw
      ctx.beginPath()
      ctx.moveTo(x, H - 6)
      ctx.lineTo(x, H - 6 - tickH)
      ctx.stroke()
      if (is5u) {
        ctx.fillStyle = 'rgba(255,255,255,0.5)'
        ctx.font = '600 11px Inter, sans-serif'
        ctx.textAlign = 'center'
        ctx.fillText((t / 10).toFixed(0), x, H - 6 - tickH - 5)
      }
    }

    // Accent marker (current weight on target screen)
    if (accentTenths !== undefined) {
      const ax = cx + (accentTenths - valueTenths) * H_PX
      if (ax > -10 && ax < W + 10) {
        ctx.strokeStyle = 'rgba(255,255,255,0.45)'
        ctx.lineWidth = 1.5
        ctx.setLineDash([4, 4])
        ctx.beginPath()
        ctx.moveTo(ax, 0)
        ctx.lineTo(ax, H - 6)
        ctx.stroke()
        ctx.setLineDash([])
      }
    }

    // Lime center indicator
    ctx.strokeStyle = C.acc
    ctx.lineWidth = 2.5
    ctx.beginPath()
    ctx.moveTo(cx, 0)
    ctx.lineTo(cx, H - 6)
    ctx.stroke()
    // Triangle pointer at bottom
    ctx.fillStyle = C.acc
    ctx.beginPath()
    ctx.moveTo(cx - 6, H)
    ctx.lineTo(cx + 6, H)
    ctx.lineTo(cx, H - 11)
    ctx.closePath()
    ctx.fill()

    ctx.restore()
  }, [valueTenths, accentTenths, minTenths, maxTenths])

  // Size canvas on mount
  useLayoutEffect(() => {
    const canvas = canvasRef.current
    const cont   = containerRef.current
    if (!canvas || !cont) return
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const w = cont.offsetWidth || 390
    sizeRef.current = { w, h: height, dpr }
    canvas.width  = w * dpr
    canvas.height = height * dpr
    canvas.style.width  = w + 'px'
    canvas.style.height = height + 'px'
    draw()
  }, []) // eslint-disable-line

  useEffect(() => { draw() }, [draw])

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    dragRef.current = { startX: e.clientX, startVal: valueTenths }
  }
  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!dragRef.current) return
    const dx    = dragRef.current.startX - e.clientX
    const delta = Math.round(dx / H_PX)
    onChangeTenths(Math.max(minTenths, Math.min(maxTenths, dragRef.current.startVal + delta)))
  }
  const onPointerUp = () => { dragRef.current = null }

  return (
    <div ref={containerRef} style={{ width: '100%' }}>
      <canvas
        ref={canvasRef}
        style={{ display: 'block', cursor: 'ew-resize', touchAction: 'none' }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      />
    </div>
  )
}

// ── VERTICAL RULER PICKER (height) ────────────────────────────────────────────
const V_PX = 24 // pixels per cm

interface VRulerProps {
  valueCm: number
  minCm: number
  maxCm: number
  onChangeCm: (v: number) => void
  width?: number
}

const VRuler = ({ valueCm, minCm, maxCm, onChangeCm, width = 80 }: VRulerProps) => {
  const canvasRef  = useRef<HTMLCanvasElement>(null)
  const sizeRef    = useRef({ w: width, h: 480, dpr: 1 })
  const dragRef    = useRef<{ startY: number; startVal: number } | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const { w: W, h: H, dpr } = sizeRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.clearRect(0, 0, W * dpr, H * dpr)
    ctx.save()
    ctx.scale(dpr, dpr)

    const cy = H / 2

    for (let v = minCm; v <= maxCm; v++) {
      const y = cy - (v - valueCm) * V_PX
      if (y < -V_PX * 2 || y > H + V_PX * 2) continue
      const is10 = v % 10 === 0
      const is5  = v % 5  === 0
      const tickW = is10 ? 34 : is5 ? 22 : 11
      const alpha = is10 ? 0.92 : is5 ? 0.6 : 0.28
      const lw    = is10 ? 2 : 1
      ctx.strokeStyle = `rgba(255,255,255,${alpha})`
      ctx.lineWidth = lw
      ctx.beginPath()
      ctx.moveTo(W - 4, y)
      ctx.lineTo(W - 4 - tickW, y)
      ctx.stroke()
      if (is10) {
        ctx.fillStyle = 'rgba(255,255,255,0.55)'
        ctx.font = '500 11px Inter, sans-serif'
        ctx.textAlign = 'right'
        ctx.fillText(v.toString(), W - 4 - tickW - 4, y + 4)
      }
    }

    // Lime horizontal indicator at center
    ctx.strokeStyle = C.acc
    ctx.lineWidth = 2.5
    ctx.beginPath()
    ctx.moveTo(0, cy)
    ctx.lineTo(W - 2, cy)
    ctx.stroke()
    // Right-pointing triangle
    ctx.fillStyle = C.acc
    ctx.beginPath()
    ctx.moveTo(W, cy - 6)
    ctx.lineTo(W, cy + 6)
    ctx.lineTo(W - 10, cy)
    ctx.closePath()
    ctx.fill()

    ctx.restore()
  }, [valueCm, minCm, maxCm])

  useLayoutEffect(() => {
    const canvas = canvasRef.current
    const cont   = containerRef.current
    if (!canvas || !cont) return
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const h   = cont.offsetHeight || 480
    sizeRef.current = { w: width, h, dpr }
    canvas.width  = width * dpr
    canvas.height = h * dpr
    canvas.style.width  = width + 'px'
    canvas.style.height = h + 'px'
    draw()
  }, []) // eslint-disable-line

  useEffect(() => { draw() }, [draw])

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    dragRef.current = { startY: e.clientY, startVal: valueCm }
  }
  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!dragRef.current) return
    const dy    = dragRef.current.startY - e.clientY // up = increase
    const delta = Math.round(dy / V_PX)
    onChangeCm(Math.max(minCm, Math.min(maxCm, dragRef.current.startVal + delta)))
  }
  const onPointerUp = () => { dragRef.current = null }

  return (
    <div ref={containerRef} style={{ width, height: '100%' }}>
      <canvas
        ref={canvasRef}
        style={{ display: 'block', cursor: 'ns-resize', touchAction: 'none' }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      />
    </div>
  )
}

// ── BMI CARD ─────────────────────────────────────────────────────────────────
const BMICard = ({ weightKg, heightCm, birthYear }: { weightKg: number; heightCm: number; birthYear: number | null }) => {
  const currentYear = 2026
  const age = birthYear ? currentYear - birthYear : null
  const isUnder20 = age !== null && age < 20

  if (isUnder20) {
    return (
      <div style={{ background: bc(C.warn, 0.08), borderRadius: 16, border: `1px solid ${bc(C.warn, 0.2)}`, padding: '14px 16px' }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.warn, marginBottom: 4 }}>Ориентировочная оценка</div>
        <p style={{ fontSize: 13, color: C.fg2, margin: 0, lineHeight: 1.55 }}>Для оценки роста и веса в этом возрасте используются отдельные возрастные нормы. Мы сохраним данные для настройки тренировок, но не будем показывать взрослую BMI-оценку.</p>
      </div>
    )
  }

  const { bmi, low, high, status, diffLow, diffHigh } = calcBMI(weightKg, heightCm)
  const statusConfig = {
    below:  { color: '#22CCE2', text: `На ${Math.abs(diffLow)} кг ниже ориентировочного диапазона для твоего роста.` },
    within: { color: C.ok,     text: `Вес находится внутри ориентировочного диапазона для твоего роста.` },
    above:  { color: C.warn,   text: `На ${Math.abs(diffHigh).toFixed(1)} кг выше верхней границы ориентировочного диапазона.` },
    high:   { color: C.err,    text: `На ${Math.abs(diffHigh).toFixed(1)} кг выше верхней границы ориентировочного диапазона.` },
  }[status] ?? { color: C.fg2, text: '' }

  return (
    <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '14px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: C.fg2 }}>Ориентировочная оценка</span>
        <span style={{ fontSize: 13, fontWeight: 800, color: statusConfig.color, fontFamily: "'Barlow Condensed', sans-serif" }}>BMI {bmi}</span>
      </div>
      <p style={{ fontSize: 13, color: C.fg2, margin: '0 0 6px', lineHeight: 1.5 }}>{statusConfig.text}</p>
      <p style={{ fontSize: 11, color: C.fg3, margin: 0, lineHeight: 1.4 }}>Ориентировочный диапазон для роста {heightCm} см: {low}–{high} кг. BMI — скрининговая оценка. Не учитывает мышечную массу.</p>
    </div>
  )
}

// ── DELTA CARD ────────────────────────────────────────────────────────────────
const DeltaCard = ({ currentKg, targetKg, heightCm }: { currentKg: number; targetKg: number; heightCm: number }) => {
  const diff    = Math.round((targetKg - currentKg) * 10) / 10
  const pct     = Math.round(Math.abs(diff) / currentKg * 1000) / 10
  const isGain  = diff > 0
  const isNone  = diff === 0
  const { low, high } = calcBMI(targetKg, heightCm)
  const outOfRange = targetKg < low || targetKg > high

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '14px 16px' }}>
        <div style={{ display: 'flex', gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: C.fg3, marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>Изменение</div>
            <div className="font-display" style={{ fontSize: 30, fontWeight: 800, color: isNone ? C.fg2 : isGain ? C.ok : C.acc, lineHeight: 1 }}>
              {isNone ? '±0' : (isGain ? '+' : '') + diff.toFixed(1)} кг
            </div>
          </div>
          {!isNone && (
            <div>
              <div style={{ fontSize: 11, color: C.fg3, marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>От текущего</div>
              <div className="font-display" style={{ fontSize: 30, fontWeight: 800, color: isGain ? C.ok : C.acc, lineHeight: 1 }}>
                {isGain ? '+' : '−'}{pct}%
              </div>
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <div style={{ flex: 1, fontSize: 12, color: C.fg3 }}>
            Текущий: <strong style={{ color: C.fg }}>{currentKg.toFixed(1)} кг</strong>
          </div>
          <div style={{ flex: 1, fontSize: 12, color: C.fg3 }}>
            Цель: <strong style={{ color: C.fg }}>{targetKg.toFixed(1)} кг</strong>
          </div>
        </div>
      </div>
      {outOfRange && (
        <div style={{ background: bc(C.warn, 0.08), borderRadius: 14, border: `1px solid ${bc(C.warn, 0.2)}`, padding: '10px 14px' }}>
          <p style={{ fontSize: 12, color: C.fg2, margin: 0, lineHeight: 1.5 }}>Эта цель находится вне ориентировочного диапазона веса для твоего роста. BMI не учитывает мышечную массу — воспринимай оценку как справочную.</p>
        </div>
      )}
    </div>
  )
}

// ── STEP 9 — BIRTH YEAR ───────────────────────────────────────────────────────
// ── STEP 6 — Year + Height (merged, vertical scroll) ─────────────────────────
const Step6_YearHeight = ({ birthYear, heightCm, onBirthYear, onHeightCm, onNext, onBack }: {
  birthYear: number | null; heightCm: number;
  onBirthYear: (v: number) => void; onHeightCm: (v: number) => void;
  onNext: () => void; onBack: () => void
}) => {
  const [heightUnit, setHeightUnit] = useState<'см' | 'ft'>('см')
  const year = birthYear ?? 1990
  useEffect(() => { if (!birthYear) onBirthYear(1990) }, []) // eslint-disable-line
  const age = 2026 - year

  const fmtH = () => heightUnit === 'см' ? `${heightCm}` : `${Math.floor(heightCm / 30.48)}'${Math.round(((heightCm / 30.48) % 1) * 12)}"`

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <OBHeader step={6} onBack={onBack} title="Год рождения и рост" subtitle="Поможет точнее настроить нагрузку. Необязательно." />
      <div style={{ flex: 1, overflowY: 'auto' }}>

        {/* ── Year section ── */}
        <div style={{ padding: '4px 20px 0' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Год рождения</div>
        </div>
        <div style={{ padding: '0 20px' }}>
          <div style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 20 }}>
            <div style={{ textAlign: 'center', padding: '12px 0 4px', fontSize: 13, color: C.fg2, fontWeight: 600 }}>
              {age} {age === 1 ? 'год' : age < 5 ? 'года' : 'лет'}
            </div>
            <WheelYear value={year} onChange={onBirthYear} />
          </div>
        </div>

        {/* ── Height section ── */}
        <div style={{ padding: '0 20px 4px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Рост</div>
          <UnitToggle options={['см', 'ft']} active={heightUnit} onChange={(v) => setHeightUnit(v as 'см' | 'ft')} />
        </div>
        <div style={{ padding: '0 20px 24px' }}>
          <div style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
            <div style={{ display: 'flex', alignItems: 'center', minHeight: 200 }}>
              <div style={{ flex: 1, padding: '20px 0 20px 24px' }}>
                <div className="font-display" style={{ fontSize: 80, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmtH()}</div>
                <div style={{ fontSize: 18, color: C.fg2, fontWeight: 600, marginTop: 4 }}>{heightUnit}</div>
              </div>
              <div style={{ width: 72, height: 200 }}>
                <VRuler valueCm={heightCm} minCm={100} maxCm={220} onChangeCm={onHeightCm} width={72} />
              </div>
            </div>
            <div style={{ display: 'flex', borderTop: `1px solid ${C.bd}` }}>
              <button onClick={() => onHeightCm(Math.max(100, heightCm - 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg3, fontSize: 20, cursor: 'pointer', fontWeight: 700 }}>−</button>
              <div style={{ width: 1, background: C.bd }} />
              <button onClick={() => onHeightCm(Math.min(220, heightCm + 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg3, fontSize: 20, cursor: 'pointer', fontWeight: 700 }}>+</button>
            </div>
          </div>
        </div>
      </div>
      <div style={{ padding: '12px 20px 28px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Btn label="Продолжить" onClick={onNext} />
        <button onClick={onNext} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg3 }}>Пропустить</button>
      </div>
    </div>
  )
}

// ── STEP 7 — Current + Target Weight (merged, vertical scroll) ────────────────
const GOAL_NO_TARGET = ['Стать сильнее', 'Улучшить форму', 'Повысить выносливость']

const Step7_WeightTarget = ({ weightKg, targetKg, heightCm, birthYear, goal, onWeight, onTarget, onNext, onBack, onSkipTarget }: {
  weightKg: number | null; targetKg: number | null; heightCm: number; birthYear: number | null;
  goal: string; onWeight: (v: number) => void; onTarget: (v: number) => void;
  onNext: () => void; onBack: () => void; onSkipTarget: () => void
}) => {
  const [unit, setUnit] = useState<'кг' | 'lbs'>('кг')
  const wTenths  = Math.round((weightKg ?? 75) * 10)
  const baseKg   = weightKg ?? 75
  const tKg      = targetKg ?? Math.round((baseKg - 5) * 10) / 10
  const tTenths  = Math.round(tKg * 10)

  useEffect(() => { if (!weightKg) onWeight(75) }, []) // eslint-disable-line
  useEffect(() => { if (!targetKg) onTarget(tKg) }, []) // eslint-disable-line

  const fmt = (kg: number) => unit === 'кг' ? kg.toFixed(1) : (kg * 2.2046).toFixed(1)
  const isOptional = GOAL_NO_TARGET.includes(goal)

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <OBHeader step={7} onBack={onBack} title="Вес" subtitle="Данные хранятся только на устройстве." />

      {/* Global unit toggle */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 20px 8px', flexShrink: 0 }}>
        <UnitToggle options={['кг', 'lbs']} active={unit} onChange={(v) => setUnit(v as 'кг' | 'lbs')} />
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>

        {/* ── Current weight ── */}
        <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 6 }}>Текущий вес</div>
        <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 8 }}>
          <div style={{ padding: '12px 20px 0', display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <div className="font-display" style={{ fontSize: 56, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmt(baseKg)}</div>
            <div style={{ fontSize: 14, color: C.fg3, fontWeight: 600 }}>{unit}</div>
          </div>
          <HRuler valueTenths={wTenths} minTenths={300} maxTenths={2000} onChangeTenths={(t) => onWeight(t / 10)} />
        </div>
        {/* BMI card */}
        {heightCm > 0 && weightKg !== null && (
          <div style={{ marginBottom: 16 }}>
            <BMICard weightKg={baseKg} heightCm={heightCm} birthYear={birthYear} />
          </div>
        )}

        {/* ── Target weight ── */}
        <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 6 }}>
          Желаемый вес
          {isOptional && <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11, marginLeft: 6 }}>— необязательно</span>}
        </div>
        <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 10 }}>
          <div style={{ padding: '12px 20px 0', display: 'flex', alignItems: 'baseline', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <div className="font-display" style={{ fontSize: 56, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmt(tKg)}</div>
              <div style={{ fontSize: 14, color: C.fg3, fontWeight: 600 }}>{unit}</div>
            </div>
            {weightKg !== null && (
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 5, paddingBottom: 2 }}>
                <span style={{ fontSize: 12, color: C.fg3 }}>сейчас</span>
                <span className="font-display" style={{ fontSize: 20, fontWeight: 700, color: C.fg2 }}>◀ {fmt(baseKg)}</span>
              </div>
            )}
          </div>
          <HRuler valueTenths={tTenths} minTenths={300} maxTenths={2000} onChangeTenths={(t) => onTarget(t / 10)} accentTenths={wTenths} height={80} />
        </div>
        {/* Delta card */}
        {weightKg !== null && heightCm > 0 && (
          <DeltaCard currentKg={baseKg} targetKg={tKg} heightCm={heightCm} />
        )}
        <div style={{ height: 12 }} />
      </div>

      <div style={{ padding: '12px 20px 28px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Btn label="Продолжить" onClick={onNext} />
        <button onClick={onSkipTarget} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg3 }}>Не ставить цель по весу</button>
      </div>
    </div>
  )
}

// ── STEP 8 — HEALTH CONNECT ───────────────────────────────────────────────────
const Step8_Health = ({ onNext, onBack }: { onNext: () => void; onBack: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <OBHeader step={8} onBack={onBack} title="Подключить данные о восстановлении?" subtitle="Необязательно. Можно настроить позже в профиле." />
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 24px', gap: 20 }}>
      {/* Icon */}
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: 80, height: 80, borderRadius: 24, background: bc('#22CCE2', 0.12), border: `1.5px solid ${bc('#22CCE2', 0.3)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40 }}>💙</div>
      </div>
      {/* Health Connect name */}
      <div style={{ textAlign: 'center' }}>
        <div className="font-display" style={{ fontSize: 28, fontWeight: 800, color: C.fg, marginBottom: 6 }}>Health Connect</div>
        <p style={{ fontSize: 14, color: C.fg2, margin: 0, lineHeight: 1.6 }}>Данные о шагах, сне, активности и восстановлении помогут точнее строить программу.</p>
      </div>
      {/* Features */}
      <div style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[['👟', 'Шаги и активность', 'Учитываем в общей нагрузке'], ['😴', 'Сон', 'Для рекомендаций по восстановлению'], ['💪', 'Тренировки', 'Синхронизация с историей активности']].map(([icon, title, desc]) => (
          <div key={title} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 22 }}>{icon}</span>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.fg }}>{title}</div>
              <div style={{ fontSize: 12, color: C.fg2 }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>
      <p style={{ fontSize: 12, color: C.fg3, margin: 0, textAlign: 'center', lineHeight: 1.5 }}>Системный запрос разрешений откроется только после нажатия «Подключить».</p>
    </div>
    <div style={{ padding: '12px 24px 32px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <Btn label="Подключить" onClick={onNext} />
      <Btn label="Позже" onClick={onNext} variant="outlined" />
    </div>
  </div>
)

// ── STEP 10 — Generating ──────────────────────────────────────────────────────
const GENERATING_PARAMS = [
  { label: 'Цель',            value: 'Стать сильнее' },
  { label: 'Уровень',         value: 'Средний' },
  { label: 'Место',           value: 'Тренажёрный зал' },
  { label: 'Оборудование',    value: 'Полный зал' },
  { label: 'График',          value: '4 дня в неделю' },
  { label: 'Ограничения',     value: 'Нет' },
  { label: 'Приоритет',       value: 'Спина, грудь, ноги' },
]

const Step10 = ({ onDone }: { onDone: () => void }) => {
  const [revealed, setRevealed] = useState(0)
  useEffect(() => {
    if (revealed < GENERATING_PARAMS.length) {
      const t = setTimeout(() => setRevealed((r) => r + 1), 420)
      return () => clearTimeout(t)
    } else {
      const t = setTimeout(onDone, 900)
      return () => clearTimeout(t)
    }
  }, [revealed, onDone])

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: C.bg, padding: '0 24px' }}>
      <div style={{ width: 64, height: 64, borderRadius: '50%', border: `3px solid ${C.s3}`, borderTopColor: C.acc, marginBottom: 32 }} className="animate-spin" />
      <h2 className="font-display" style={{ fontSize: 32, fontWeight: 800, color: C.fg, margin: '0 0 8px', textAlign: 'center' }}>Подбираем первую неделю тренировок</h2>
      <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 32px', textAlign: 'center' }}>Учитываем ваши параметры</p>
      <div style={{ width: '100%', maxWidth: 320, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {GENERATING_PARAMS.map((p, i) => (
          <div key={p.label} style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: i < revealed ? 1 : 0, transform: i < revealed ? 'none' : 'translateY(6px)', transition: 'all 0.3s ease' }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: bc(C.acc, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <span style={{ fontSize: 11, color: C.acc, fontWeight: 800 }}>✓</span>
            </div>
            <span style={{ fontSize: 13, color: C.fg2 }}>{p.label}: <strong style={{ color: C.fg }}>{p.value}</strong></span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── STEP 11 — Plan Preview ────────────────────────────────────────────────────
const Step11 = ({ onNext }: { onNext: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <div style={{ padding: '56px 20px 0', flexShrink: 0 }}>
      <Chip label="✓ Первая неделя готова" color={bc(C.acc, 0.12)} text={C.acc} />
      <h2 className="font-display" style={{ fontSize: 38, fontWeight: 900, color: C.fg, margin: '12px 0 0', lineHeight: 1.05 }}>Твой план на неделю</h2>
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Plan summary */}
        <div style={{ display: 'flex', gap: 8 }}>
          {[['4', 'тренировки'], ['45', 'минут'], ['8', 'нед']].map(([val, lbl]) => (
            <div key={lbl} style={{ flex: 1, background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '14px 12px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 28, fontWeight: 800, color: C.acc }}>{val}</div>
              <div style={{ fontSize: 11, color: C.fg2, marginTop: 2 }}>{lbl}</div>
            </div>
          ))}
        </div>
        {/* Location + focus */}
        <Card style={{ padding: 16 }}>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <Chip label="🏛 Тренажёрный зал" color={C.s3} text={C.fg2} />
            <Chip label="Спина" color={bc(C.ok, 0.12)} text={C.ok} />
            <Chip label="Грудь" color={bc('#7C6AFF', 0.12)} text="#B0A8FF" />
            <Chip label="Ноги" color={bc(C.warn, 0.12)} text={C.warn} />
          </div>
        </Card>
        {/* Today */}
        <div style={{ background: `linear-gradient(135deg, ${C.s2} 0%, ${bc(C.acc, 0.06)} 100%)`, borderRadius: 20, border: `1px solid ${bc(C.acc, 0.2)}`, padding: 20 }}>
          <Label color={C.acc}>Сегодня</Label>
          <h3 className="font-display" style={{ fontSize: 28, fontWeight: 800, color: C.fg, margin: '6px 0 4px' }}>Спина и бицепс</h3>
          <p style={{ fontSize: 13, color: C.fg2, margin: '0 0 14px' }}>7 упражнений · 48 минут</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {['Тяга верхнего блока', 'Тяга горизонтального блока', 'Подтягивания с весом'].map((ex, i) => (
              <div key={ex} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: C.s3, borderRadius: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: ['#7C3AED', '#2563EB', '#059669'][i], display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <span style={{ fontSize: 16 }}>▶</span>
                </div>
                <span style={{ fontSize: 14, color: C.fg, fontWeight: 500 }}>{ex}</span>
              </div>
            ))}
            <div style={{ padding: '10px 12px', borderRadius: 12, border: `1px dashed ${C.bd2}`, textAlign: 'center' }}>
              <span style={{ fontSize: 13, color: C.fg3 }}>+ ещё 4 упражнения</span>
            </div>
          </div>
        </div>
        {/* Week view */}
        <Card style={{ padding: 16 }}>
          <Label>Расписание недели</Label>
          <div style={{ marginTop: 12, display: 'flex', gap: 4 }}>
            {[
              { day: 'Пн', name: 'Спина + бицепс', active: true },
              { day: 'Вт', name: 'Отдых', active: false },
              { day: 'Ср', name: 'Грудь + трицепс', active: true },
              { day: 'Чт', name: 'Отдых', active: false },
              { day: 'Пт', name: 'Ноги', active: true },
              { day: 'Сб', name: 'Плечи', active: true },
              { day: 'Вс', name: 'Отдых', active: false },
            ].map((d) => (
              <div key={d.day} style={{ flex: 1, borderRadius: 10, background: d.active ? bc(C.acc, 0.12) : C.s3, border: `1px solid ${d.active ? bc(C.acc, 0.3) : C.bd}`, padding: '8px 0', textAlign: 'center' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: d.active ? C.acc : C.fg3 }}>{d.day}</div>
                <div style={{ width: 4, height: 4, borderRadius: '50%', background: d.active ? C.acc : C.fg3, margin: '4px auto 0' }} />
              </div>
            ))}
          </div>
        </Card>
        <div style={{ height: 8 }} />
      </div>
    </div>
    <div style={{ padding: '12px 20px 28px', flexShrink: 0 }}>
      <Btn label="Посмотреть тренировку →" onClick={onNext} />
    </div>
  </div>
)

// ── STEP 12 — Account ─────────────────────────────────────────────────────────
const Step12 = ({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 24px' }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: bc(C.acc, 0.12), display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20, fontSize: 32 }}>🔐</div>
      <h2 className="font-display" style={{ fontSize: 36, fontWeight: 900, color: C.fg, margin: '0 0 10px', textAlign: 'center', lineHeight: 1.1 }}>Сохрани программу и прогресс</h2>
      <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 32px', textAlign: 'center', lineHeight: 1.6 }}>Создай аккаунт — и твой план, история тренировок и результаты будут в безопасности.</p>
      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { label: 'Продолжить с Google',  icon: '🔵', onClick: onNext },
          { label: 'Продолжить с Apple',   icon: '⬛', onClick: onNext },
          { label: 'Войти через Email',     icon: '✉',  onClick: onNext },
        ].map((opt) => (
          <button key={opt.label} onClick={opt.onClick} style={{ width: '100%', padding: '14px 18px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg, fontSize: 15, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, cursor: 'pointer' }}>
            <span>{opt.icon}</span>{opt.label}
          </button>
        ))}
      </div>
    </div>
    <div style={{ padding: '0 24px 40px', flexShrink: 0 }}>
      <button onClick={onSkip} style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg2, padding: '12px 0' }}>Пока продолжить без аккаунта</button>
    </div>
  </div>
)

// ── STEP 13 — Notifications ───────────────────────────────────────────────────
const Step13 = ({ onDone }: { onDone: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: C.bg, padding: '0 24px' }}>
    <div style={{ width: 72, height: 72, borderRadius: 22, background: bc(C.warn, 0.12), display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24, fontSize: 36 }}>🔔</div>
    <h2 className="font-display" style={{ fontSize: 34, fontWeight: 900, color: C.fg, margin: '0 0 10px', textAlign: 'center', lineHeight: 1.1 }}>Напомнить о тренировке в понедельник в 19:00?</h2>
    <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 32px', textAlign: 'center', lineHeight: 1.6 }}>Следующая тренировка: Спина и бицепс. Чтобы включить — нажми «Да».</p>
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
      <Btn label="Да, напомни" onClick={onDone} />
      <Btn label="Нет, я сам" onClick={onDone} variant="outlined" />
    </div>
  </div>
)

// ── ONBOARDING FLOW ORCHESTRATOR ──────────────────────────────────────────────
const OnboardingFlow = ({ onComplete }: { onComplete: () => void }) => {
  const [step, setStep] = useState(0)
  const [data, setData] = useState<OnboardingData>(defaultOb)

  const next = () => setStep((s) => s + 1)
  const back = () => setStep((s) => Math.max(0, s - 1))
  const upd = <K extends keyof OnboardingData>(key: K, val: OnboardingData[K]) => setData((d) => ({ ...d, [key]: val }))

  if (step === 0) return <Step0 onNext={next} onSkip={() => setStep(9)} />
  // Step 1: Goal + Level
  if (step === 1) return <Step1 goal={data.goal} level={data.level} onGoal={(v) => upd('goal', v)} onLevel={(v) => upd('level', v)} onNext={next} onBack={back} />
  // Step 2: Location + Equipment
  if (step === 2) return <Step2 location={data.location} equipment={data.equipment} onLocation={(v) => upd('location', v)} onEquipment={(v) => upd('equipment', v)} onNext={next} onBack={back} />
  // Step 3: Schedule
  if (step === 3) return <Step3 days={data.daysPerWeek} duration={data.duration} onDays={(n) => upd('daysPerWeek', n)} onDuration={(n) => upd('duration', n)} onNext={next} onBack={back} />
  // Step 4: Body — Injuries + Focus
  if (step === 4) return <Step4 injuries={data.injuries} focusZones={data.focusZones} onInjuries={(v) => upd('injuries', v)} onFocus={(v) => upd('focusZones', v)} onNext={next} onBack={back} />
  // Step 5: Barriers
  if (step === 5) return <Step5 value={data.barriers} onChange={(v) => upd('barriers', v)} onNext={next} onBack={back} />
  // Step 6: Year + Height
  if (step === 6) return <Step6_YearHeight birthYear={data.birthYear} heightCm={data.heightCm} onBirthYear={(v) => upd('birthYear', v)} onHeightCm={(v) => upd('heightCm', v)} onNext={next} onBack={back} />
  // Step 7: Weight + Target Weight
  if (step === 7) return <Step7_WeightTarget weightKg={data.weightKg} targetKg={data.targetWeightKg} heightCm={data.heightCm} birthYear={data.birthYear} goal={data.goal} onWeight={(v) => upd('weightKg', v)} onTarget={(v) => upd('targetWeightKg', v)} onNext={next} onBack={back} onSkipTarget={() => { upd('targetWeightKg', null); next() }} />
  // Step 8: Health Connect
  if (step === 8) return <Step8_Health onNext={next} onBack={back} />
  // Step 9: Generating
  if (step === 9) return <Step10 onDone={next} />
  // Step 10: Plan Preview
  if (step === 10) return <Step11 onNext={next} />
  // Step 11: Account
  if (step === 11) return <Step12 onNext={next} onSkip={next} />
  // Step 12: Notifications
  return <Step13 onDone={onComplete} />
}

// ══════════════════════════════════════════════════════════════════════════════
// 3. HOME SCREEN
// ══════════════════════════════════════════════════════════════════════════════
const RECOVERY = [
  { muscle: 'Грудь',   status: 'recovering', label: 'Восстанавливается', color: '' },
  { muscle: 'Спина',   status: 'high',       label: 'Высокая',           color: '' },
  { muscle: 'Ноги',    status: 'ready',      label: 'Готовы',            color: '' },
  { muscle: 'Плечи',   status: 'medium',     label: 'Средняя',           color: '' },
  { muscle: 'Руки',    status: 'recovering', label: 'Восст.',             color: '' },
]

function recoveryColor(status: string) {
  if (status === 'high' || status === 'ready') return C.ok
  if (status === 'medium') return C.warn
  return C.err
}

const WEEK_DAYS = [
  { day: 'Пн', done: true },
  { day: 'Вт', done: false, rest: true },
  { day: 'Ср', done: true },
  { day: 'Чт', done: false, rest: true },
  { day: 'Пт', done: false, active: true },
  { day: 'Сб', done: false },
  { day: 'Вс', done: false },
]

const HomeScreen = ({ onScan, onWorkoutStart, onPhotoCompare }: { onScan: () => void; onWorkoutStart: () => void; onPhotoCompare?: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    {/* Header */}
    <div style={{ padding: '54px 20px 0', flexShrink: 0 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <p style={{ fontSize: 13, color: C.fg2, margin: '0 0 2px' }}>Добрый вечер</p>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, margin: 0, lineHeight: 1.1 }}>Иван</h1>
        </div>
        <button style={{ width: 42, height: 42, borderRadius: '50%', background: C.s2, border: `1px solid ${C.bd2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 18 }}>🔔</button>
      </div>
      {/* Program progress */}
      <div style={{ marginTop: 14, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <span style={{ fontSize: 12, color: C.fg2, fontWeight: 500 }}>Силовая база · Неделя 2 из 8</span>
            <span style={{ fontSize: 12, color: C.acc, fontWeight: 700 }}>28%</span>
          </div>
          <div style={{ height: 4, borderRadius: 99, background: C.s3, overflow: 'hidden' }}>
            <div style={{ width: '28%', height: '100%', borderRadius: 99, background: C.acc }} />
          </div>
        </div>
      </div>
    </div>

    <div style={{ flex: 1, overflowY: 'auto', padding: '14px 20px 0' }}>
      {/* TODAY HERO */}
      <div style={{ background: `linear-gradient(140deg, ${C.s2} 0%, ${bc(C.acc, 0.07)} 100%)`, borderRadius: 22, border: `1.5px solid ${bc(C.acc, 0.22)}`, padding: 20, position: 'relative', overflow: 'hidden', marginBottom: 12 }}>
        <div style={{ position: 'absolute', top: -20, right: -20, width: 120, height: 120, borderRadius: '50%', background: bc(C.acc, 0.06) }} />
        <Label color={C.acc}>Сегодня — Пятница</Label>
        <h2 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, margin: '6px 0 6px', lineHeight: 1.1 }}>Спина и бицепс</h2>
        <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
          <Chip label="Широчайшие" color={bc(C.ok, 0.15)} text={C.ok} small />
          <Chip label="Бицепс" color={bc('#B0A8FF', 0.15)} text="#B0A8FF" small />
          <Chip label="Трапеции" color={C.s3} text={C.fg2} small />
        </div>
        <div style={{ fontSize: 13, color: C.fg2, marginBottom: 16 }}>7 упражнений · 48 минут · Тренажёрный зал</div>
        <button onClick={onWorkoutStart} style={{ width: '100%', padding: '14px', borderRadius: 14, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: `0 4px 20px ${bc(C.acc, 0.3)}` }}>
          <span>▶</span> Начать тренировку
        </button>
      </div>

      {/* Quick Scan */}
      <button onClick={onScan} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderRadius: 16, border: `1px solid ${C.bd2}`, background: C.s2, cursor: 'pointer', marginBottom: 20, textAlign: 'left' }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: bc('#7C6AFF', 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 22 }}>◉</div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, color: C.fg }}>Незнакомый тренажёр?</div>
          <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>Распознать камерой и получить упражнения →</div>
        </div>
      </button>

      {/* Recovery */}
      <div style={{ marginBottom: 20 }}>
        <Label style={{ marginBottom: 10, display: 'block' }}>Восстановление мышц</Label>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
          {RECOVERY.map((r) => (
            <div key={r.muscle} style={{ flexShrink: 0, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '10px 14px', minWidth: 90, textAlign: 'center' }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: recoveryColor(r.status), margin: '0 auto 6px' }} />
              <div style={{ fontSize: 13, fontWeight: 600, color: C.fg }}>{r.muscle}</div>
              <div style={{ fontSize: 10, color: C.fg2, marginTop: 2 }}>{r.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly stats */}
      <div style={{ marginBottom: 12 }}>
        <Label style={{ marginBottom: 10, display: 'block' }}>Эта неделя</Label>
        <div style={{ display: 'flex', gap: 4, marginBottom: 12 }}>
          {WEEK_DAYS.map((d) => (
            <div key={d.day} style={{ flex: 1, textAlign: 'center' }}>
              <div style={{ fontSize: 9, fontWeight: 600, color: d.active ? C.acc : C.fg3, marginBottom: 4 }}>{d.day}</div>
              <div style={{ width: '100%', aspectRatio: '1', borderRadius: 8, background: d.done ? C.acc : d.rest ? C.s3 : d.active ? bc(C.acc, 0.2) : C.s2, border: d.active ? `1.5px solid ${C.acc}` : `1px solid ${C.bd}` }} />
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[['2', 'тренировки'], ['5 820', 'кг'], ['0', 'рекордов']].map(([val, lbl]) => (
            <div key={lbl} style={{ flex: 1, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '12px 10px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg }}>{val}</div>
              <div style={{ fontSize: 10, color: C.fg2, marginTop: 2 }}>{lbl}</div>
            </div>
          ))}
        </div>
      </div>
      {/* Photo progress home card — shown only when 2+ compatible photos exist */}
      {onPhotoCompare && (
        <div style={{ padding: '0 20px 20px' }}>
          <button onClick={onPhotoCompare} style={{ width: '100%', background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden', cursor: 'pointer', textAlign: 'left', padding: 0 }}>
            <div style={{ display: 'flex', height: 90 }}>
              <PhotoPlaceholder angle="front" index={0} style={{ flex: 1 }} />
              <div style={{ width: 1, background: C.bd }} />
              <PhotoPlaceholder angle="front" index={2} style={{ flex: 1 }} />
            </div>
            <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.fg }}>Изменения за 8 недель</div>
                <div style={{ fontSize: 11, color: C.ok, fontWeight: 600, marginTop: 2 }}>−6.8 кг</div>
              </div>
              <div style={{ padding: '7px 14px', borderRadius: 10, background: C.acc, color: '#060F00', fontSize: 13, fontWeight: 700 }}>Сравнить</div>
            </div>
          </button>
        </div>
      )}
      <div style={{ height: 90 }} />
    </div>
  </div>
)

// ══════════════════════════════════════════════════════════════════════════════
// 4. SCAN SCREEN
// ══════════════════════════════════════════════════════════════════════════════
type ScanPhase = 'ready' | 'analyzing' | 'result'

const ScanScreen = ({ onEquipment, onTabChange }: { onEquipment: () => void; onTabChange: (t: Tab) => void }) => {
  const [phase, setPhase] = useState<ScanPhase>('ready')

  const handleCapture = () => {
    setPhase('analyzing')
    setTimeout(() => setPhase('result'), 2200)
  }
  const handleReset = () => setPhase('ready')

  return (
    <div style={{ height: '100%', position: 'relative', background: '#000', overflow: 'hidden' }}>
      {/* Simulated camera feed */}
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(160deg, #0a0a0a 0%, #111 50%, #080808 100%)' }}>
        {/* Gym texture suggestion */}
        <div style={{ position: 'absolute', inset: 0, backgroundImage: `radial-gradient(circle at 30% 40%, rgba(50,50,80,0.3) 0%, transparent 60%), radial-gradient(circle at 70% 70%, rgba(30,30,60,0.2) 0%, transparent 50%)` }} />
        {/* Equipment silhouette suggestion */}
        <div style={{ position: 'absolute', top: '18%', left: '10%', right: '10%', bottom: '25%', borderRadius: 20, background: 'linear-gradient(135deg, rgba(40,40,60,0.8) 0%, rgba(20,20,40,0.9) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ opacity: 0.15 }}>
            <svg viewBox="0 0 200 160" width={200} height={160}>
              <rect x="80" y="20" width="40" height="120" rx="8" fill="white" />
              <rect x="20" y="60" width="160" height="30" rx="8" fill="white" />
              <rect x="10" y="55" width="30" height="40" rx="6" fill="white" />
              <rect x="160" y="55" width="30" height="40" rx="6" fill="white" />
            </svg>
          </div>
        </div>
      </div>

      {/* Top bar (glass) */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '52px 20px 16px', background: 'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, transparent 100%)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={() => onTabChange('home')} style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 16 }}>‹</button>
        <div style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(12px)', borderRadius: 99, padding: '6px 14px', border: '1px solid rgba(255,255,255,0.15)' }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.9)' }}>Распознавание</span>
        </div>
        <button style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 14 }}>⊡</button>
      </div>

      {/* Scan frame */}
      {phase !== 'result' && (
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -55%)', width: 260, height: 260 }}>
          <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <div className="scan-corner scan-corner-tl" style={{ borderColor: phase === 'analyzing' ? C.acc : 'rgba(255,255,255,0.8)' }} />
            <div className="scan-corner scan-corner-tr" style={{ borderColor: phase === 'analyzing' ? C.acc : 'rgba(255,255,255,0.8)' }} />
            <div className="scan-corner scan-corner-bl" style={{ borderColor: phase === 'analyzing' ? C.acc : 'rgba(255,255,255,0.8)' }} />
            <div className="scan-corner scan-corner-br" style={{ borderColor: phase === 'analyzing' ? C.acc : 'rgba(255,255,255,0.8)' }} />
            {phase === 'ready' && <div className="scan-line" />}
            {phase === 'analyzing' && (
              <>
                <div style={{ position: 'absolute', inset: 0, borderRadius: 4, background: bc(C.acc, 0.06) }} />
                <div className="animate-pulse-ring" style={{ position: 'absolute', inset: -20, borderRadius: 8, border: `2px solid ${C.acc}` }} />
              </>
            )}
          </div>
          {phase === 'ready' && (
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(4px)', borderRadius: 10, padding: '6px 12px' }}>
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', fontWeight: 500 }}>Жим лёжа · скамья</span>
            </div>
          )}
        </div>
      )}

      {/* Analyzing indicator */}
      {phase === 'analyzing' && (
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 36, color: C.acc }} className="animate-spin">◌</div>
          <div style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(12px)', borderRadius: 99, padding: '8px 16px' }}>
            <span style={{ fontSize: 14, color: C.fg, fontWeight: 600 }}>Определяем тренажёр…</span>
          </div>
        </div>
      )}

      {/* Instruction pill */}
      {phase === 'ready' && (
        <div style={{ position: 'absolute', bottom: 180, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <div style={{ background: 'rgba(13,13,26,0.75)', backdropFilter: 'blur(16px)', borderRadius: 99, padding: '10px 20px', border: '1px solid rgba(255,255,255,0.12)' }}>
            <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>Помести тренажёр в центр кадра</span>
          </div>
        </div>
      )}

      {/* Bottom controls */}
      {phase !== 'result' && (
        <div style={{ position: 'absolute', bottom: 80, left: 0, right: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 32, paddingBottom: 8 }}>
          {/* Flash */}
          <button style={{ width: 46, height: 46, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', fontSize: 20, color: '#fff' }}>⚡</button>
          {/* Capture */}
          <button
            onClick={handleCapture}
            disabled={phase === 'analyzing'}
            style={{ width: 72, height: 72, borderRadius: '50%', background: phase === 'analyzing' ? C.acc : '#fff', border: `4px solid rgba(255,255,255,0.3)`, cursor: phase === 'analyzing' ? 'default' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.2s', boxShadow: phase === 'ready' ? `0 0 0 2px rgba(255,255,255,0.5), 0 0 30px ${bc(C.acc, 0.3)}` : 'none' }}>
            {phase === 'analyzing' ? <span style={{ fontSize: 28 }}>◉</span> : <span style={{ fontSize: 24, color: C.s1 }}>◉</span>}
          </button>
          {/* Gallery */}
          <button style={{ width: 46, height: 46, borderRadius: 12, background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', fontSize: 20, color: '#fff' }}>🖼</button>
        </div>
      )}

      {/* Bottom nav behind sheet */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 80, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(20px)', borderTop: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', paddingBottom: 4 }}>
        {NAV_ITEMS.map((item) => {
          const isScan = item.id === 'scan'
          return (
            <button key={item.id} onClick={() => onTabChange(item.id)} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, border: 'none', background: 'none', cursor: 'pointer', padding: '8px 0' }}>
              {isScan ? (
                <div style={{ width: 46, height: 46, borderRadius: '50%', background: C.acc, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: -18, boxShadow: `0 0 20px ${bc(C.acc, 0.5)}` }}>
                  <span style={{ fontSize: 20, color: '#060F00' }}>◉</span>
                </div>
              ) : (
                <span style={{ fontSize: 20, color: isScan ? C.acc : 'rgba(255,255,255,0.3)' }}>{item.icon}</span>
              )}
              <span style={{ fontSize: 10, fontWeight: 600, color: isScan ? C.acc : 'rgba(255,255,255,0.3)', letterSpacing: '0.04em' }}>{item.label}</span>
            </button>
          )
        })}
      </div>

      {/* RESULT BOTTOM SHEET */}
      {phase === 'result' && (
        <div className="animate-slide-up" style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: C.s1, borderRadius: '24px 24px 0 0', border: `1px solid ${C.bd2}`, paddingBottom: 32, maxHeight: '75%', overflowY: 'auto' }}>
          {/* Pull indicator */}
          <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
            <div style={{ width: 40, height: 4, borderRadius: 99, background: C.bd2 }} />
          </div>
          <div style={{ padding: '0 20px' }}>
            {/* Confidence badge */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: bc(C.ok, 0.12), borderRadius: 99, padding: '5px 12px' }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.ok }} />
                <span style={{ fontSize: 12, fontWeight: 700, color: C.ok }}>Определено с высокой точностью</span>
              </div>
            </div>
            {/* Equipment name */}
            <h2 className="font-display" style={{ fontSize: 32, fontWeight: 800, color: C.fg, margin: '0 0 4px', lineHeight: 1.1 }}>Скамья для жима лёжа</h2>
            <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 14px', lineHeight: 1.5 }}>Универсальная регулируемая скамья для жима штанги и гантелей, а также ряда других упражнений</p>
            {/* Muscles */}
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
              <Chip label="Грудь" color={bc('#7C6AFF', 0.15)} text="#B0A8FF" />
              <Chip label="Трицепс" color={bc(C.ok, 0.12)} text={C.ok} />
              <Chip label="Передние дельты" color={C.s3} text={C.fg2} />
            </div>
            {/* Stats row */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
              <div style={{ flex: 1, background: C.s2, borderRadius: 12, padding: '10px', textAlign: 'center', border: `1px solid ${C.bd}` }}>
                <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg }}>23</div>
                <div style={{ fontSize: 10, color: C.fg2 }}>упражнения</div>
              </div>
              <div style={{ flex: 1, background: bc(C.acc, 0.08), borderRadius: 12, padding: '10px', textAlign: 'center', border: `1px solid ${bc(C.acc, 0.25)}` }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: C.acc }}>✓ Подходит</div>
                <div style={{ fontSize: 10, color: C.fg2 }}>для вашей цели</div>
              </div>
            </div>
            {/* CTA */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <button onClick={onEquipment} style={{ width: '100%', padding: '15px', borderRadius: 14, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 16, fontWeight: 700, boxShadow: `0 4px 20px ${bc(C.acc, 0.3)}` }}>
                Открыть тренажёр →
              </button>
              <button onClick={handleReset} style={{ width: '100%', padding: '12px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: 'none', cursor: 'pointer', color: C.fg2, fontSize: 14, fontWeight: 600 }}>
                Повторить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// 5. EQUIPMENT PAGE
// ══════════════════════════════════════════════════════════════════════════════
const EX_LIST = [
  { name: 'Жим штанги лёжа',          muscles: ['Грудь', 'Трицепс'],     color: '#7C3AED', sets: '4×8–10', tag: 'Рекомендовано' },
  { name: 'Жим гантелей на наклонной', muscles: ['Верх груди', 'Дельты'],  color: '#2563EB', sets: '3×10–12' },
  { name: 'Разводка гантелей',         muscles: ['Грудь'],                 color: '#0891B2', sets: '3×12–15' },
  { name: 'Французский жим',           muscles: ['Трицепс'],               color: '#059669', sets: '3×12' },
  { name: 'Жим узким хватом',          muscles: ['Трицепс', 'Грудь'],      color: '#D97706', sets: '3×10' },
]

// ══════════════════════════════════════════════════════════════════════════════
// 5b. EXERCISE PAGE
// ══════════════════════════════════════════════════════════════════════════════
type ExercisePageState = 'loaded' | 'loading' | 'media-unavailable' | 'no-history' | 'restricted'

const EXERCISE_STEPS = [
  { n: 1, title: 'Лёжа на скамье', desc: 'Спина плоская, стопы на полу. Лопатки сведены и зафиксированы на скамье.' },
  { n: 2, title: 'Хват немного шире плеч', desc: 'Большой палец обхватывает гриф. Запястья вертикальны над локтями при опускании.' },
  { n: 3, title: 'Опускание под контролем', desc: 'Медленно 2–3 сек, штанга касается нижней части груди. Локти 70–75° от тела.' },
  { n: 4, title: 'Жим вверх', desc: 'Взрывное усилие, гриф к середине груди. Не блокируйте локти в верхней точке.' },
]

const EXERCISE_HISTORY = [
  { date: '28 июл', weight: 80, reps: 8, sets: 4, pr: false },
  { date: '21 июл', weight: 77.5, reps: 8, sets: 4, pr: false },
  { date: '14 июл', weight: 75, reps: 10, sets: 3, pr: false },
  { date: '7 июл', weight: 75, reps: 8, sets: 3, pr: true },
]

const MuscleMapSVG = ({ primary, secondary }: { primary: string[]; secondary: string[] }) => {
  const muscles: Record<string, { path: string; label: string }> = {
    chest: { path: 'M 58 95 Q 80 88 102 95 Q 106 110 102 120 Q 80 128 58 120 Q 54 110 58 95 Z', label: 'Грудь' },
    triceps_l: { path: 'M 36 100 Q 28 112 30 128 Q 38 130 44 118 Q 46 106 42 97 Z', label: 'Трицепс' },
    triceps_r: { path: 'M 124 100 Q 132 112 130 128 Q 122 130 116 118 Q 114 106 118 97 Z', label: 'Трицепс' },
    front_delt_l: { path: 'M 44 78 Q 34 86 32 98 Q 40 102 48 94 Q 52 84 50 76 Z', label: 'Дельты' },
    front_delt_r: { path: 'M 116 78 Q 126 86 128 98 Q 120 102 112 94 Q 108 84 110 76 Z', label: 'Дельты' },
    abs: { path: 'M 66 128 Q 80 124 94 128 L 94 172 Q 80 176 66 172 Z', label: 'Пресс' },
  }
  const isPrimary = (k: string) => primary.some(p => k.includes(p))
  const isSecondary = (k: string) => secondary.some(s => k.includes(s))

  return (
    <svg viewBox="0 0 160 280" width={130} height={227} style={{ display: 'block' }}>
      {/* body outline */}
      <ellipse cx="80" cy="26" rx="18" ry="22" fill="none" stroke={C.bd2} strokeWidth="1.5" />
      <path d="M 62 46 Q 48 52 44 78 Q 34 88 28 130 Q 36 134 44 130 L 46 168 Q 48 186 54 200 L 52 250 Q 56 258 60 258 Q 64 258 66 250 L 68 200 Q 74 196 80 196 Q 86 196 92 200 L 94 250 Q 96 258 100 258 Q 104 258 108 250 L 106 200 Q 112 186 114 168 L 116 130 Q 124 134 132 130 Q 126 88 116 78 Q 112 52 98 46 Z" fill={C.s2} stroke={C.bd2} strokeWidth="1.2" />
      {/* muscles */}
      {Object.entries(muscles).map(([k, m]) => (
        <path key={k} d={m.path}
          fill={isPrimary(k) ? bc('#7C3AED', 0.75) : isSecondary(k) ? bc('#2563EB', 0.55) : bc(C.fg3, 0.12)}
          stroke={isPrimary(k) ? '#A78BFA' : isSecondary(k) ? '#60A5FA' : 'transparent'}
          strokeWidth="1"
        />
      ))}
    </svg>
  )
}

const ExerciseScreen = ({ onBack, onWorkout, onTechCoach, exerciseName = 'Жим штанги лёжа' }: { onBack: () => void; onWorkout: () => void; onTechCoach?: () => void; exerciseName?: string }) => {
  const [demoState, setDemoState] = useState<ExercisePageState>('loaded')
  const [aiOpen, setAiOpen] = useState(false)
  const [activeStep, setActiveStep] = useState<number | null>(null)

  const states: ExercisePageState[] = ['loaded', 'loading', 'media-unavailable', 'no-history', 'restricted']
  const stateLabels: Record<ExercisePageState, string> = {
    loaded: 'Loaded', loading: 'Loading', 'media-unavailable': 'No media', 'no-history': 'No history', restricted: 'Restricted'
  }

  if (demoState === 'loading') {
    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
        <div style={{ height: 240, background: C.s1, flexShrink: 0, position: 'relative' }}>
          <button onClick={onBack} style={{ position: 'absolute', top: 52, left: 20, width: 38, height: 38, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</button>
          <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(135deg, ${C.s2} 30%, ${C.s3} 100%)` }} className="animate-pulse" />
        </div>
        <div style={{ flex: 1, padding: '20px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[220, 60, 120, 80].map((w, i) => (
            <div key={i} style={{ height: 16, width: `${w}px`, maxWidth: '100%', background: C.s2, borderRadius: 8, opacity: 0.6 + i * 0.1 }} className="animate-pulse" />
          ))}
          <div style={{ height: 80, background: C.s2, borderRadius: 14 }} className="animate-pulse" />
          <div style={{ height: 44, background: C.s2, borderRadius: 14 }} className="animate-pulse" />
          {/* state switcher */}
          <div style={{ position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 6, background: C.s2, borderRadius: 99, padding: 4, border: `1px solid ${C.bd2}`, zIndex: 99 }}>
            {states.map(s => (
              <button key={s} onClick={() => setDemoState(s)} style={{ padding: '5px 10px', borderRadius: 99, border: 'none', cursor: 'pointer', fontSize: 10, fontWeight: 700, background: s === demoState ? C.acc : 'transparent', color: s === demoState ? '#060F00' : C.fg3, transition: 'all 0.15s' }}>{stateLabels[s]}</button>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg, position: 'relative' }}>
      {/* Hero */}
      <div style={{ height: 260, flexShrink: 0, position: 'relative', overflow: 'hidden', background: 'linear-gradient(160deg, #130820 0%, #0a0a18 100%)' }}>
        {demoState === 'media-unavailable' ? (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <div style={{ width: 52, height: 52, borderRadius: 16, background: C.s3, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>🎬</div>
            <div style={{ fontSize: 13, color: C.fg3, fontWeight: 600 }}>Анимация недоступна</div>
            <div style={{ fontSize: 11, color: C.fg3 }}>Ознакомьтесь с описанием техники</div>
          </div>
        ) : (
          <>
            <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse at 30% 60%, ${bc('#7C3AED', 0.45)} 0%, transparent 65%), radial-gradient(ellipse at 80% 20%, ${bc(C.acc, 0.12)} 0%, transparent 50%)` }} />
            {/* animation placeholder */}
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg viewBox="0 0 200 180" width={200} height={180} style={{ opacity: 0.22 }}>
                <ellipse cx="100" cy="28" rx="18" ry="22" fill="white" />
                <rect x="74" y="50" width="52" height="56" rx="10" fill="white" />
                <rect x="20" y="60" width="56" height="22" rx="8" fill="white" />
                <rect x="124" y="60" width="56" height="22" rx="8" fill="white" />
                <rect x="84" y="106" width="32" height="50" rx="8" fill="white" />
                <rect x="4" y="52" width="20" height="36" rx="6" fill="white" />
                <rect x="176" y="52" width="20" height="36" rx="6" fill="white" />
              </svg>
            </div>
            <div style={{ position: 'absolute', bottom: 14, left: 14, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', borderRadius: 8, padding: '5px 12px', display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 11, color: '#A78BFA' }}>▶</span>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 600 }}>Анатомическая анимация</span>
            </div>
          </>
        )}
        {/* back */}
        <button onClick={onBack} style={{ position: 'absolute', top: 52, left: 16, width: 38, height: 38, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</button>
        {/* category */}
        <div style={{ position: 'absolute', top: 56, left: '50%', transform: 'translateX(-50%)' }}>
          <Chip label="Грудь · Трицепс" color="rgba(0,0,0,0.45)" text="rgba(255,255,255,0.75)" small />
        </div>
        {/* name gradient overlay */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '60px 16px 16px', background: 'linear-gradient(to top, rgba(6,6,15,1) 0%, transparent 100%)' }}>
          <h1 className="font-display" style={{ fontSize: 28, fontWeight: 900, color: C.fg, margin: 0, lineHeight: 1.1 }}>{exerciseName}</h1>
        </div>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 120px' }}>

        {/* Restriction banner */}
        {demoState === 'restricted' && (
          <div style={{ background: bc(C.warn, 0.1), border: `1px solid ${bc(C.warn, 0.4)}`, borderRadius: 14, padding: '12px 14px', marginBottom: 16, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 20, flexShrink: 0 }}>⚠️</span>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: C.warn, marginBottom: 3 }}>Ограничение по здоровью</div>
              <div style={{ fontSize: 12, color: C.fg2, lineHeight: 1.5 }}>У вас указана травма плечевого сустава. Жим лёжа с большими весами может создать нагрузку. Проконсультируйтесь с тренером.</div>
              <button style={{ marginTop: 8, padding: '6px 14px', borderRadius: 99, border: 'none', cursor: 'pointer', background: bc(C.warn, 0.2), color: C.warn, fontSize: 12, fontWeight: 700 }}>Показать безопасные альтернативы</button>
            </div>
          </div>
        )}

        {/* Quick stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 16 }}>
          {[
            { label: 'Уровень', value: 'Средний' },
            { label: 'Оборуд.', value: 'Штанга' },
            { label: 'Тип', value: 'Сила' },
          ].map(s => (
            <div key={s.label} style={{ background: C.s2, borderRadius: 12, padding: '10px 10px', border: `1px solid ${C.bd}`, textAlign: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.fg, marginBottom: 2 }}>{s.value}</div>
              <div style={{ fontSize: 10, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Muscle map + chips */}
        <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '14px 16px', marginBottom: 16 }}>
          <Label style={{ display: 'block', marginBottom: 10 }}>Задействованные мышцы</Label>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <MuscleMapSVG primary={['chest', 'abs']} secondary={['triceps', 'front_delt']} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div>
                <div style={{ fontSize: 10, color: C.fg3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 5 }}>Основные</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                  <Chip label="Большая грудная" color={bc('#7C3AED', 0.2)} text="#C4B5FD" small />
                  <Chip label="Малая грудная" color={bc('#7C3AED', 0.15)} text="#C4B5FD" small />
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: C.fg3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 5 }}>Вспомогательные</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                  <Chip label="Трицепс" color={bc('#2563EB', 0.18)} text="#93C5FD" small />
                  <Chip label="Передние дельты" color={bc('#2563EB', 0.12)} text="#93C5FD" small />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technique steps */}
        <div style={{ marginBottom: 16 }}>
          <Label style={{ display: 'block', marginBottom: 10 }}>Техника выполнения</Label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {EXERCISE_STEPS.map(step => (
              <div key={step.n} onClick={() => setActiveStep(activeStep === step.n ? null : step.n)} style={{ background: C.s2, borderRadius: 14, border: `1px solid ${activeStep === step.n ? bc('#7C3AED', 0.5) : C.bd}`, overflow: 'hidden', cursor: 'pointer', transition: 'border-color 0.15s' }}>
                <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 28, height: 28, borderRadius: '50%', background: activeStep === step.n ? '#7C3AED' : C.s3, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'background 0.15s' }}>
                    <span style={{ fontSize: 12, fontWeight: 800, color: activeStep === step.n ? '#fff' : C.fg3 }}>{step.n}</span>
                  </div>
                  <span style={{ fontSize: 14, fontWeight: 600, color: C.fg, flex: 1 }}>{step.title}</span>
                  <span style={{ color: C.fg3, fontSize: 14, transform: activeStep === step.n ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>›</span>
                </div>
                {activeStep === step.n && (
                  <div style={{ padding: '0 14px 12px 54px', fontSize: 13, color: C.fg2, lineHeight: 1.55 }}>{step.desc}</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Tренер по технике entry point */}
        <button onClick={onTechCoach} style={{ width: '100%', background: `linear-gradient(135deg, ${bc('#7C3AED', 0.12)} 0%, ${bc('#7C3AED', 0.06)} 100%)`, borderRadius: 16, border: `1.5px solid ${bc('#7C3AED', 0.4)}`, padding: '14px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12, textAlign: 'left' }}>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: bc('#7C3AED', 0.25), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 22 }}>🎯</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#C4B5FD', marginBottom: 2 }}>Тренер по технике</div>
            <div style={{ fontSize: 12, color: C.fg2 }}>AI-анализ движения через камеру в реальном времени</div>
          </div>
          <span style={{ color: '#C4B5FD', fontSize: 18 }}>›</span>
        </button>

        {/* AI Coach entry point */}
        <button onClick={() => setAiOpen(!aiOpen)} style={{ width: '100%', background: bc('#1D4ED8', 0.08), borderRadius: 16, border: `1.5px solid ${bc('#1D4ED8', 0.3)}`, padding: '14px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16, textAlign: 'left' }}>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: bc('#1D4ED8', 0.18), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 22 }}>✦</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#93C5FD', marginBottom: 2 }}>AI-тренер</div>
            <div style={{ fontSize: 12, color: C.fg2 }}>Задайте вопрос про технику, нагрузку или замену</div>
          </div>
          <span style={{ color: '#93C5FD', fontSize: 18, transform: aiOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>›</span>
        </button>
        {aiOpen && (
          <div style={{ marginTop: -10, marginBottom: 16, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: 14 }}>
            <div style={{ fontSize: 12, color: C.fg3, marginBottom: 10 }}>Популярные вопросы</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {['Какой вес выбрать для начала?', 'Почему болят плечи при жиме?', 'Как правильно дышать?', 'Чем заменить при дискомфорте в запястьях?'].map(q => (
                <button key={q} style={{ padding: '10px 14px', borderRadius: 10, border: `1px solid ${C.bd2}`, background: C.s3, color: C.fg, fontSize: 13, cursor: 'pointer', textAlign: 'left', fontWeight: 500 }}>{q}</button>
              ))}
            </div>
          </div>
        )}

        {/* History */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <Label>История подходов</Label>
            <span style={{ fontSize: 12, color: '#7C3AED', fontWeight: 600 }}>Все записи</span>
          </div>
          {demoState === 'no-history' ? (
            <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '28px 16px', textAlign: 'center' }}>
              <div style={{ fontSize: 36, marginBottom: 10 }}>📊</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.fg, marginBottom: 6 }}>История пустая</div>
              <div style={{ fontSize: 13, color: C.fg2, marginBottom: 14, lineHeight: 1.5 }}>Выполните это упражнение впервые и ваши результаты появятся здесь</div>
              <button onClick={onWorkout} style={{ padding: '10px 22px', borderRadius: 99, background: C.acc, color: '#060F00', fontSize: 13, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Начать тренировку</button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {EXERCISE_HISTORY.map((h, i) => (
                <div key={i} style={{ background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ minWidth: 52, fontSize: 12, color: C.fg3, fontWeight: 600 }}>{h.date}</div>
                  <div style={{ flex: 1, display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span style={{ fontSize: 15, fontWeight: 700, color: C.fg }}>{h.weight} кг</span>
                    <span style={{ fontSize: 12, color: C.fg2 }}>{h.sets}×{h.reps}</span>
                  </div>
                  {h.pr && <Chip label="PR" color={bc(C.acc, 0.2)} text={C.acc} small />}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom CTA */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 16px 32px', background: `linear-gradient(to top, ${C.bg} 70%, transparent 100%)` }}>
        <button onClick={onWorkout} style={{ width: '100%', padding: '16px', borderRadius: 16, background: C.acc, color: '#060F00', fontSize: 16, fontWeight: 800, border: 'none', cursor: 'pointer', letterSpacing: '-0.01em' }}>
          ▶ Добавить в тренировку
        </button>
      </div>

      {/* Dev state switcher */}
      <div style={{ position: 'absolute', top: 52, right: 64, display: 'flex', gap: 4, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', borderRadius: 99, padding: 3, border: `1px solid ${C.bd2}`, zIndex: 99 }}>
        {states.map(s => (
          <button key={s} onClick={() => setDemoState(s)} style={{ padding: '3px 7px', borderRadius: 99, border: 'none', cursor: 'pointer', fontSize: 9, fontWeight: 700, background: s === demoState ? C.acc : 'transparent', color: s === demoState ? '#060F00' : C.fg3, transition: 'all 0.15s', whiteSpace: 'nowrap' }}>{stateLabels[s]}</button>
        ))}
      </div>
    </div>
  )
}

const EquipmentScreen = ({ onBack, onWorkout, onExercise }: { onBack: () => void; onWorkout: () => void; onExercise?: () => void }) => {
  const [aiOpen, setAiOpen] = useState(false)
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      {/* Hero */}
      <div style={{ height: 240, background: 'linear-gradient(145deg, #1a1030 0%, #0d0d1a 100%)', position: 'relative', flexShrink: 0, overflow: 'hidden' }}>
        {/* Equipment illustration */}
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.18 }}>
          <svg viewBox="0 0 280 180" width={280} height={180}>
            <rect x="100" y="20" width="80" height="140" rx="10" fill="white" />
            <rect x="20" y="70" width="240" height="40" rx="8" fill="white" />
            <rect x="8" y="60" width="40" height="60" rx="8" fill="white" />
            <rect x="232" y="60" width="40" height="60" rx="8" fill="white" />
            <rect x="60" y="150" width="30" height="20" rx="4" fill="white" />
            <rect x="190" y="150" width="30" height="20" rx="4" fill="white" />
          </svg>
        </div>
        {/* Gradient mesh */}
        <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle at 30% 50%, ${bc('#7C6AFF', 0.35)} 0%, transparent 60%), radial-gradient(circle at 80% 30%, ${bc(C.acc, 0.15)} 0%, transparent 50%)` }} />
        {/* Back button */}
        <button onClick={onBack} style={{ position: 'absolute', top: 52, left: 20, width: 38, height: 38, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</button>
        {/* Category chip */}
        <div style={{ position: 'absolute', top: 56, left: '50%', transform: 'translateX(-50%)' }}>
          <Chip label="Свободные веса" color="rgba(0,0,0,0.4)" text="rgba(255,255,255,0.8)" small />
        </div>
        {/* Add to program */}
        <button style={{ position: 'absolute', top: 52, right: 20, padding: '8px 14px', borderRadius: 10, background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 13, fontWeight: 600 }}>+ В тренировку</button>
        {/* Name overlay */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '60px 20px 20px', background: 'linear-gradient(to top, rgba(6,6,15,0.95) 0%, transparent 100%)' }}>
          <h1 className="font-display" style={{ fontSize: 32, fontWeight: 900, color: C.fg, margin: 0, lineHeight: 1.1 }}>Скамья для жима лёжа</h1>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px 0' }}>
        {/* Description */}
        <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 14px', lineHeight: 1.6 }}>Регулируемая скамья для жима штанги и гантелей. Угол спинки регулируется для проработки верхней, средней и нижней части грудных мышц.</p>

        {/* Primary muscles */}
        <div style={{ marginBottom: 14 }}>
          <Label style={{ marginBottom: 8, display: 'block' }}>Основные мышцы</Label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <Chip label="Большая грудная" color={bc('#7C6AFF', 0.15)} text="#B0A8FF" />
            <Chip label="Трицепс" color={bc(C.ok, 0.12)} text={C.ok} />
            <Chip label="Передние дельты" color={C.s3} text={C.fg2} />
          </div>
        </div>

        {/* Suitability */}
        <div style={{ background: bc(C.ok, 0.08), borderRadius: 14, border: `1px solid ${bc(C.ok, 0.25)}`, padding: '12px 16px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: bc(C.ok, 0.2), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ color: C.ok, fontSize: 16 }}>✓</span>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.ok }}>Подходит вам</div>
            <div style={{ fontSize: 12, color: C.fg2 }}>На основе вашей цели (стать сильнее) и уровня</div>
          </div>
        </div>

        {/* Recommended exercise — hero */}
        <div style={{ marginBottom: 16 }}>
          <Label style={{ marginBottom: 10, display: 'block' }}>Рекомендовано для вас</Label>
          <div onClick={onExercise ?? onWorkout} style={{ background: `linear-gradient(135deg, ${C.s2} 0%, ${bc('#7C6AFF', 0.1)} 100%)`, borderRadius: 20, border: `1.5px solid ${bc('#7C6AFF', 0.3)}`, overflow: 'hidden', cursor: 'pointer' }}>
            {/* Exercise media placeholder */}
            <div style={{ height: 120, background: 'linear-gradient(135deg, #1a0a30 0%, #0d0d20 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle at 50% 50%, ${bc('#7C3AED', 0.4)} 0%, transparent 70%)` }} />
              <svg viewBox="0 0 160 100" width={160} height={100} style={{ opacity: 0.25 }}>
                <ellipse cx="80" cy="28" rx="14" ry="16" fill="white" />
                <rect x="62" y="42" width="36" height="36" rx="6" fill="white" />
                <rect x="30" y="52" width="32" height="16" rx="6" fill="white" />
                <rect x="98" y="52" width="32" height="16" rx="6" fill="white" />
                <rect x="70" y="78" width="18" height="14" rx="4" fill="white" />
                <rect x="18" y="48" width="16" height="24" rx="4" fill="white" />
                <rect x="126" y="48" width="16" height="24" rx="4" fill="white" />
              </svg>
              <div style={{ position: 'absolute', top: 10, right: 12 }}>
                <Chip label="★ Рекомендовано" color={bc(C.acc, 0.2)} text={C.acc} small />
              </div>
              <div style={{ position: 'absolute', bottom: 10, left: 12, background: 'rgba(0,0,0,0.5)', borderRadius: 8, padding: '4px 10px' }}>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)' }}>▶ Анатомическая анимация</span>
              </div>
            </div>
            <div style={{ padding: '14px 16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <h3 className="font-display" style={{ fontSize: 20, fontWeight: 700, color: C.fg, margin: '0 0 4px' }}>Жим штанги лёжа</h3>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <Chip label="Грудь" color={bc('#7C6AFF', 0.15)} text="#B0A8FF" small />
                    <Chip label="4×8–10" color={C.s3} text={C.fg2} small />
                  </div>
                </div>
                <button onClick={(e) => { e.stopPropagation(); onWorkout() }} style={{ padding: '8px 14px', borderRadius: 10, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 13, fontWeight: 700 }}>▶ Начать</button>
              </div>
            </div>
          </div>
        </div>

        {/* All exercises */}
        <div style={{ marginBottom: 16 }}>
          <Label style={{ marginBottom: 10, display: 'block' }}>Все упражнения · 23</Label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {EX_LIST.map((ex) => (
              <button key={ex.name} onClick={onExercise ?? onWorkout} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 16, border: `1px solid ${C.bd}`, background: C.s2, cursor: 'pointer', textAlign: 'left' }}>
                <div style={{ width: 42, height: 42, borderRadius: 12, background: bc(ex.color, 0.2), flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ fontSize: 18, color: ex.color }}>▶</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: C.fg, marginBottom: 3 }}>{ex.name}</div>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {ex.muscles.map((m) => <Chip key={m} label={m} color={C.s3} text={C.fg2} small />)}
                    <Chip label={ex.sets} color={C.s3} text={C.fg3} small />
                  </div>
                </div>
                {ex.tag && <Chip label={ex.tag} color={bc(C.acc, 0.12)} text={C.acc} small />}
                <span style={{ color: C.fg3, fontSize: 16, flexShrink: 0 }}>›</span>
              </button>
            ))}
          </div>
        </div>

        {/* AI Coach */}
        <div style={{ marginBottom: 16 }}>
          <button onClick={() => setAiOpen(!aiOpen)} style={{ width: '100%', background: bc('#7C6AFF', 0.08), borderRadius: 16, border: `1px solid ${bc('#7C6AFF', 0.25)}`, padding: '14px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left' }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: bc('#7C6AFF', 0.2), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 20 }}>✦</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#B0A8FF' }}>AI-тренер</div>
              <div style={{ fontSize: 12, color: C.fg2 }}>Спросите про технику, нагрузку, замену</div>
            </div>
            <span style={{ color: C.fg3, fontSize: 18, transform: aiOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>›</span>
          </button>
          {aiOpen && (
            <div className="animate-fade-in" style={{ marginTop: 8, background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: 16 }}>
              <div style={{ fontSize: 13, color: C.fg2, marginBottom: 12 }}>Часто спрашивают:</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {['Какой вес выбрать для начала?', 'Как правильно настроить скамью?', 'Почему болят плечи при жиме?', 'Чем заменить при дискомфорте?'].map((q) => (
                  <button key={q} style={{ padding: '10px 14px', borderRadius: 10, border: `1px solid ${C.bd2}`, background: C.s3, color: C.fg, fontSize: 13, cursor: 'pointer', textAlign: 'left', fontWeight: 500 }}>
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div style={{ height: 16 }} />
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// 6. WORKOUT PLAYER
// ══════════════════════════════════════════════════════════════════════════════
interface SetLog { weight: number; reps: number; done: boolean }

const WorkoutPlayer = ({ onBack, onDone, onFormCheck }: { onBack: () => void; onDone: () => void; onFormCheck?: () => void }) => {
  const [currentSet, setCurrentSet] = useState(1)
  const totalSets = 4
  const [weight, setWeight] = useState(60)
  const [reps, setReps] = useState(10)
  const [sets, setSets] = useState<SetLog[]>([])
  const [restActive, setRestActive] = useState(false)
  const [restSecs, setRestSecs] = useState(90)
  const [showSets, setShowSets] = useState(false)
  const [showAI, setShowAI] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [setStarted, setSetStarted] = useState(false)

  useEffect(() => {
    if (!setStarted) return
    const t = setInterval(() => setElapsed((s) => s + 1), 1000)
    return () => clearInterval(t)
  }, [setStarted])

  useEffect(() => {
    if (!restActive) return
    if (restSecs <= 0) { setRestActive(false); setRestSecs(90); setSetStarted(false); return }
    const t = setTimeout(() => setRestSecs((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [restActive, restSecs])

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`

  const handleDoneSet = () => {
    setSets((prev) => [...prev, { weight, reps, done: true }])
    if (currentSet < totalSets) {
      setCurrentSet((s) => s + 1)
      setRestActive(true)
      setRestSecs(90)
    } else {
      onDone()
    }
  }

  const circumference = 2 * Math.PI * 70
  const dashOffset = circumference * (1 - restSecs / 90)

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg, position: 'relative' }}>
      {/* Top bar */}
      <div style={{ padding: '52px 20px 12px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: '50%', background: C.s3, border: 'none', cursor: 'pointer', color: C.fg2, fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</button>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{ fontSize: 12, color: C.fg3, fontWeight: 600 }}>Упражнение 1 из 7</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.fg }}>Спина и бицепс</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, background: C.s3, borderRadius: 10, padding: '5px 10px', border: `1px solid ${setStarted ? C.bd2 : C.bd}` }}>
          <span style={{ fontSize: 11, color: setStarted ? C.fg3 : C.fg3 }}>⏱</span>
          <span style={{ fontSize: 15, fontFamily: 'monospace', fontWeight: 800, color: setStarted ? C.acc : C.fg3, letterSpacing: '0.04em' }}>{formatTime(elapsed)}</span>
        </div>
        <button onClick={onDone} style={{ padding: '6px 12px', borderRadius: 8, background: C.s3, border: `1px solid ${C.bd2}`, cursor: 'pointer', color: C.fg2, fontSize: 12, fontWeight: 600 }}>Завершить</button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Exercise animation area */}
        <div style={{ height: 180, background: `linear-gradient(145deg, #0d0820 0%, #0a0a1a 100%)`, borderRadius: 20, marginBottom: 16, position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(circle at 50% 40%, ${bc('#7C6AFF', 0.3)} 0%, transparent 65%)` }} className="animate-breathe" />
          <svg viewBox="0 0 160 120" width={160} height={120} style={{ opacity: 0.22 }}>
            <ellipse cx="80" cy="20" rx="14" ry="15" fill="white" />
            <rect x="64" y="34" width="32" height="38" rx="6" fill="white" />
            <rect x="28" y="44" width="36" height="20" rx="5" fill="white" />
            <rect x="96" y="44" width="36" height="20" rx="5" fill="white" />
            <rect x="68" y="72" width="10" height="28" rx="4" fill="white" />
            <rect x="82" y="72" width="10" height="28" rx="4" fill="white" />
            <rect x="16" y="40" width="14" height="28" rx="4" fill="white" />
            <rect x="130" y="40" width="14" height="28" rx="4" fill="white" />
          </svg>
          <div style={{ position: 'absolute', bottom: 12, left: 12 }}>
            <Chip label="▶ Анимация техники" color="rgba(0,0,0,0.5)" text="rgba(255,255,255,0.7)" small />
          </div>
          <div style={{ position: 'absolute', bottom: 12, right: 12 }}>
            <Chip label="👁 Form Check" color="rgba(0,0,0,0.5)" text="rgba(255,255,255,0.7)" small />
          </div>
        </div>

        {/* Exercise name + set info */}
        <h2 className="font-display" style={{ fontSize: 28, fontWeight: 800, color: C.fg, margin: '0 0 4px', lineHeight: 1.1 }}>Тяга верхнего блока</h2>
        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          <Chip label={`Подход ${currentSet} из ${totalSets}`} color={bc(C.acc, 0.12)} text={C.acc} />
          <Chip label="Широчайшие" color={bc(C.ok, 0.12)} text={C.ok} />
        </div>

        {/* Previous set */}
        {sets.length > 0 && (
          <div style={{ background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, padding: '10px 14px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, color: C.fg3 }}>Предыдущий:</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: C.fg }}>{sets[sets.length - 1].weight} кг × {sets[sets.length - 1].reps}</span>
            <Chip label="✓" color={bc(C.ok, 0.15)} text={C.ok} small />
          </div>
        )}

        {/* Weight + Reps inputs */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {/* Weight */}
          <div style={{ flex: 1 }}>
            <Label style={{ display: 'block', marginBottom: 6 }}>Вес (кг)</Label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 0, background: C.s3, borderRadius: 14, border: `1.5px solid ${C.bd2}`, overflow: 'hidden' }}>
              <button onClick={() => setWeight((w) => Math.max(0, w - 2.5))} style={{ width: 44, height: 60, background: 'none', border: 'none', color: C.fg2, fontSize: 22, cursor: 'pointer', fontWeight: 300 }}>−</button>
              <div className="font-display" style={{ flex: 1, textAlign: 'center', fontSize: 28, fontWeight: 800, color: C.fg }}>{weight}</div>
              <button onClick={() => setWeight((w) => w + 2.5)} style={{ width: 44, height: 60, background: 'none', border: 'none', color: C.acc, fontSize: 22, cursor: 'pointer', fontWeight: 300 }}>+</button>
            </div>
          </div>
          {/* Reps */}
          <div style={{ flex: 1 }}>
            <Label style={{ display: 'block', marginBottom: 6 }}>Повторения</Label>
            <div style={{ display: 'flex', alignItems: 'center', background: C.s3, borderRadius: 14, border: `1.5px solid ${C.bd2}`, overflow: 'hidden' }}>
              <button onClick={() => setReps((r) => Math.max(1, r - 1))} style={{ width: 44, height: 60, background: 'none', border: 'none', color: C.fg2, fontSize: 22, cursor: 'pointer', fontWeight: 300 }}>−</button>
              <div className="font-display" style={{ flex: 1, textAlign: 'center', fontSize: 28, fontWeight: 800, color: C.fg }}>{reps}</div>
              <button onClick={() => setReps((r) => r + 1)} style={{ width: 44, height: 60, background: 'none', border: 'none', color: C.acc, fontSize: 22, cursor: 'pointer', fontWeight: 300 }}>+</button>
            </div>
          </div>
        </div>

        {/* Secondary actions */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          <button onClick={() => setShowSets(!showSets)} style={{ flex: 1, padding: '10px', borderRadius: 12, border: `1px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
            Все подходы ({sets.length}/{totalSets})
          </button>
          <button onClick={() => setShowAI(true)} style={{ flex: 1, padding: '10px', borderRadius: 12, border: `1px solid ${bc(C.acc, 0.3)}`, background: bc(C.acc, 0.08), color: C.acc, fontSize: 12, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
            🤖 AI Coach
          </button>
        </div>

        {/* Sets table */}
        {showSets && (
          <div className="animate-fade-in" style={{ background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: 14, marginBottom: 16 }}>
            <Label style={{ display: 'block', marginBottom: 10 }}>Журнал подходов</Label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {sets.map((s, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < sets.length - 1 ? `1px solid ${C.bd}` : 'none' }}>
                  <Chip label={`${i + 1}`} color={bc(C.ok, 0.15)} text={C.ok} small />
                  <span style={{ fontSize: 15, fontWeight: 700, color: C.fg, fontFamily: "'Barlow Condensed', sans-serif" }}>{s.weight} кг × {s.reps}</span>
                  <span style={{ marginLeft: 'auto', color: C.ok, fontSize: 14 }}>✓</span>
                </div>
              ))}
              {Array.from({ length: totalSets - sets.length }).map((_, i) => (
                <div key={`p${i}`} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderTop: sets.length > 0 || i > 0 ? `1px solid ${C.bd}` : 'none' }}>
                  <Chip label={`${sets.length + i + 1}`} color={C.s3} text={C.fg3} small />
                  <span style={{ fontSize: 13, color: C.fg3 }}>Предстоит</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ height: 120 }} />
      </div>

      {/* CTA */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 20px 32px', background: `linear-gradient(to top, ${C.bg} 70%, transparent 100%)` }}>
        {!setStarted ? (
          <button
            onClick={() => setSetStarted(true)}
            style={{ width: '100%', padding: '16px', borderRadius: 16, border: `2px solid ${C.acc}`, cursor: 'pointer', background: C.s3, color: C.fg, fontSize: 17, fontWeight: 700, boxShadow: `0 0 24px ${bc(C.acc, 0.25)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}
          >
            <span style={{ fontSize: 20, color: C.acc }}>▶</span>
            Начать подход {currentSet}/{totalSets}
          </button>
        ) : (
          <button
            onClick={handleDoneSet}
            style={{ width: '100%', padding: '16px', borderRadius: 16, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 17, fontWeight: 700, boxShadow: `0 4px 24px ${bc(C.acc, 0.35)}` }}
          >
            Завершить подход {currentSet}/{totalSets}
          </button>
        )}
        {onFormCheck && (
          <button onClick={onFormCheck} style={{ width: '100%', marginTop: 10, padding: '12px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <span>📹</span> Form Check — проверить технику
          </button>
        )}
      </div>

      {/* AI COACH PANEL */}
      {showAI && <AICoachPanel context="Тяга верхнего блока" onClose={() => setShowAI(false)} />}

      {/* REST TIMER OVERLAY */}
      {restActive && (
        <div className="animate-fade-in" style={{ position: 'absolute', inset: 0, background: 'rgba(6,6,15,0.97)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <Label color={C.fg2} style={{ marginBottom: 24, display: 'block' }}>ОТДЫХ</Label>
          {/* Circular timer */}
          <div style={{ position: 'relative', width: 160, height: 160, marginBottom: 24 }}>
            <svg width={160} height={160} style={{ transform: 'rotate(-90deg)' }}>
              <circle cx={80} cy={80} r={70} fill="none" stroke={C.s3} strokeWidth={6} />
              <circle cx={80} cy={80} r={70} fill="none" stroke={C.acc} strokeWidth={6} strokeDasharray={circumference} strokeDashoffset={dashOffset} strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1s linear' }} />
            </svg>
            <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div className="font-display" style={{ fontSize: 44, fontWeight: 800, color: C.fg, lineHeight: 1 }}>{formatTime(restSecs)}</div>
            </div>
          </div>
          <div style={{ fontSize: 13, color: C.fg2, marginBottom: 8 }}>Следующий подход</div>
          <div className="font-display" style={{ fontSize: 22, fontWeight: 700, color: C.fg, marginBottom: 32 }}>{weight} кг × {reps}</div>
          <div style={{ display: 'flex', gap: 12, width: '100%', padding: '0 32px' }}>
            <button onClick={() => { setRestActive(false); setRestSecs(90); setSetStarted(false) }} style={{ flex: 1, padding: '14px', borderRadius: 14, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700 }}>Готов</button>
            <button onClick={() => setRestSecs((s) => s + 30)} style={{ padding: '14px 18px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: 'none', color: C.fg2, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>+30 сек</button>
          </div>
        </div>
      )}
    </div>
  )
}

// ── WORKOUT DONE SUMMARY ──────────────────────────────────────────────────────
const WorkoutDone = ({ onHome }: { onHome: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <div style={{ flex: 1, overflowY: 'auto', padding: '60px 20px 0' }}>
      {/* Success */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 24 }}>
        <div style={{ width: 72, height: 72, borderRadius: '50%', background: bc(C.ok, 0.15), border: `2px solid ${C.ok}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>✓</div>
      </div>
      <h2 className="font-display" style={{ fontSize: 38, fontWeight: 900, color: C.fg, textAlign: 'center', margin: '0 0 6px', lineHeight: 1.1 }}>Тренировка завершена</h2>
      <p style={{ fontSize: 14, color: C.fg2, textAlign: 'center', margin: '0 0 28px' }}>Отличная работа, Иван</p>

      {/* Stats */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {[['12', 'мин'], ['4', 'подхода'], ['280', 'кг']].map(([val, lbl]) => (
          <div key={lbl} style={{ flex: 1, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '14px 10px', textAlign: 'center' }}>
            <div className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.acc }}>{val}</div>
            <div style={{ fontSize: 11, color: C.fg2, marginTop: 2 }}>{lbl}</div>
          </div>
        ))}
      </div>

      {/* Form feedback */}
      <Card style={{ padding: 16, marginBottom: 12 }}>
        <Label style={{ marginBottom: 10, display: 'block' }}>Обратная связь по технике</Label>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: C.ok }}>✓</span>
            <span style={{ fontSize: 13, color: C.fg }}>Жим лёжа — стабильно</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: C.warn }}>⚠</span>
            <span style={{ fontSize: 13, color: C.fg }}>Тяга — следи за нейтральной спиной</span>
          </div>
        </div>
      </Card>

      {/* Recovery */}
      <Card style={{ padding: 16, marginBottom: 12 }}>
        <Label style={{ marginBottom: 8, display: 'block' }}>Восстановление</Label>
        <p style={{ fontSize: 13, color: C.fg2, margin: 0, lineHeight: 1.5 }}>Грудь и трицепс потребуют 48–72 часа. Следующая тренировка на эти группы — не раньше воскресенья.</p>
      </Card>

      {/* Next workout */}
      <div style={{ background: bc(C.acc, 0.08), borderRadius: 16, border: `1px solid ${bc(C.acc, 0.22)}`, padding: 16, marginBottom: 16 }}>
        <Label color={C.acc} style={{ marginBottom: 6, display: 'block' }}>Следующая тренировка</Label>
        <div className="font-display" style={{ fontSize: 22, fontWeight: 700, color: C.fg }}>Ноги · Среда</div>
        <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>6 упражнений · 52 минуты</div>
      </div>
      <div style={{ height: 24 }} />
    </div>
    <div style={{ padding: '12px 20px 32px', flexShrink: 0 }}>
      <Btn label="На главную" onClick={onHome} />
    </div>
  </div>
)

// ══════════════════════════════════════════════════════════════════════════════
// STUB SCREENS (progress / profile / workouts — not in scope yet)
// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// PHOTO PROGRESS FEATURE
// ══════════════════════════════════════════════════════════════════════════════

type PhotoAngle = 'front' | 'side' | 'back' | 'custom'
interface ProgressPhoto { id: string; date: string; angle: PhotoAngle; weightKg?: number; note?: string; milestone?: string }

const ANGLE_META: Record<PhotoAngle, { label: string; bg: string }> = {
  front:  { label: 'Спереди',      bg: 'linear-gradient(160deg, #0f1a2e 0%, #152236 100%)' },
  side:   { label: 'Сбоку',        bg: 'linear-gradient(160deg, #0e1f1e 0%, #122828 100%)' },
  back:   { label: 'Сзади',        bg: 'linear-gradient(160deg, #1a1020 0%, #221528 100%)' },
  custom: { label: 'Произвольное', bg: 'linear-gradient(160deg, #1a1a10 0%, #28261a 100%)' },
}

const INITIAL_PHOTOS: ProgressPhoto[] = [
  { id: '1', date: '2025-06-15', angle: 'front', weightKg: 92.0, milestone: 'Старт' },
  { id: '2', date: '2025-07-13', angle: 'front', weightKg: 88.5, milestone: '4 недели' },
  { id: '3', date: '2025-08-05', angle: 'front', weightKg: 85.2 },
  { id: '4', date: '2025-06-15', angle: 'side',  weightKg: 92.0, milestone: 'Старт' },
  { id: '5', date: '2025-08-05', angle: 'side',  weightKg: 85.2 },
]

const SilhouetteFront = ({ size = 120, color = 'rgba(255,255,255,0.13)' }: { size?: number; color?: string }) => (
  <svg viewBox="0 0 60 120" width={size * 0.5} height={size} fill={color}>
    <ellipse cx="30" cy="12" rx="11" ry="12" />
    <path d="M18 26 Q12 30 10 50 L14 50 Q16 35 18 32 L20 60 L12 95 L18 95 L24 72 L30 80 L36 72 L42 95 L48 95 L40 60 L42 32 Q44 35 46 50 L50 50 Q48 30 42 26 Z" />
  </svg>
)
const SilhouetteSide = ({ size = 120, color = 'rgba(255,255,255,0.13)' }: { size?: number; color?: string }) => (
  <svg viewBox="0 0 40 120" width={size * 0.33} height={size} fill={color}>
    <ellipse cx="22" cy="12" rx="9" ry="11" />
    <path d="M16 24 Q10 28 10 48 L14 48 Q14 34 16 30 L17 58 L12 92 L17 92 L20 75 L22 82 L26 92 L31 92 L28 58 L30 30 Q32 34 32 48 L36 48 Q36 28 30 24 Z" />
  </svg>
)

const PhotoPlaceholder = ({ angle, style, index = 0 }: { angle: PhotoAngle; style?: React.CSSProperties; index?: number }) => {
  const meta = ANGLE_META[angle]
  return (
    <div style={{ background: meta.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden', ...style }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: `linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)`, backgroundSize: '30px 30px' }} />
      {angle === 'side' ? <SilhouetteSide size={120} color={`rgba(255,255,255,${0.1 + index * 0.03})`} /> : <SilhouetteFront size={120} color={`rgba(255,255,255,${0.1 + index * 0.03})`} />}
    </div>
  )
}

const fmtDate = (iso: string) => new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' })
const fmtDateShort = (iso: string) => new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })

const BackBtn = ({ onClick }: { onClick: () => void }) => (
  <button onClick={onClick} style={{ width: 38, height: 38, borderRadius: '50%', background: C.s3, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.fg2, fontSize: 18, flexShrink: 0 }}>‹</button>
)

const ToggleSwitch = ({ val, onToggle, label }: { val: boolean; onToggle: () => void; label: string }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, marginBottom: 8 }}>
    <span style={{ fontSize: 13, color: C.fg2 }}>{label}</span>
    <button onClick={onToggle} style={{ background: val ? C.acc : C.s3, borderRadius: 99, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '2px', transition: 'background 0.2s' }}>
      <div style={{ width: 40, height: 22, borderRadius: 99, display: 'flex', alignItems: 'center', justifyContent: val ? 'flex-end' : 'flex-start', padding: '2px' }}>
        <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'white', transition: 'all 0.2s' }} />
      </div>
    </button>
  </div>
)

// ─── EMPTY STATE ──────────────────────────────────────────────────────────────
const PhotoEmptyState = ({ onAdd }: { onAdd: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 28px', textAlign: 'center', background: C.bg }}>
    <div style={{ width: 120, height: 150, borderRadius: 24, overflow: 'hidden', marginBottom: 24, border: `1.5px solid ${C.bd2}`, flexShrink: 0 }}>
      <PhotoPlaceholder angle="front" style={{ width: '100%', height: '100%' }} />
    </div>
    <h3 className="font-display" style={{ fontSize: 24, fontWeight: 800, color: C.fg, margin: '0 0 10px' }}>Фото прогресса</h3>
    <p style={{ fontSize: 14, color: C.fg2, lineHeight: 1.6, margin: '0 0 8px', maxWidth: 280 }}>
      Сравнивай изменения тела во времени по фотографиям в одинаковом ракурсе.
    </p>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.fg3, marginBottom: 28 }}>
      <span>🔒</span> Фото приватны и не публикуются автоматически
    </div>
    <button onClick={onAdd} style={{ padding: '14px 28px', borderRadius: 14, border: 'none', cursor: 'pointer', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700 }}>
      + Добавить первое фото
    </button>
  </div>
)

// ─── PRIVACY SCREEN ───────────────────────────────────────────────────────────
const PrivacyScreen = ({ onOk, onBack }: { onOk: () => void; onBack: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <div style={{ padding: '54px 20px 20px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
      <BackBtn onClick={onBack} />
      <h2 className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.fg, margin: 0 }}>Приватность</h2>
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
      <div style={{ width: 64, height: 64, borderRadius: 18, background: bc(C.ok, 0.12), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, marginBottom: 20 }}>🔒</div>
      <h3 className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: '0 0 20px', lineHeight: 1.2 }}>Твои фото прогресса приватны</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { icon: '👁', title: 'Видны только тебе', desc: 'Фото не попадают в публичные ленты и не видны другим.' },
          { icon: '🚫', title: 'Без автопубликации', desc: 'Ты сам решаешь, делиться ими или нет.' },
          { icon: '⚙', title: 'Полный контроль при экспорте', desc: 'Выбираешь что показывать: дату, вес, лицо.' },
          { icon: '🗑', title: 'Удали в любой момент', desc: 'Все фото можно удалить в настройках профиля.' },
        ].map((item) => (
          <div key={item.title} style={{ display: 'flex', gap: 12, padding: '14px', background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}` }}>
            <div style={{ fontSize: 20, width: 36, height: 36, borderRadius: 10, background: C.s3, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{item.icon}</div>
            <div><div style={{ fontSize: 14, fontWeight: 700, color: C.fg, marginBottom: 3 }}>{item.title}</div><div style={{ fontSize: 12, color: C.fg2, lineHeight: 1.5 }}>{item.desc}</div></div>
          </div>
        ))}
      </div>
    </div>
    <div style={{ padding: '16px 20px 32px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <Btn label="Понятно" onClick={onOk} />
      <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg2, padding: '10px 0' }}>Назад</button>
    </div>
  </div>
)

// ─── ANGLE SELECT ─────────────────────────────────────────────────────────────
const AngleSelectScreen = ({ onSelect, onBack }: { onSelect: (a: PhotoAngle) => void; onBack: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
    <div style={{ padding: '54px 20px 20px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
      <BackBtn onClick={onBack} />
      <div>
        <h2 className="font-display" style={{ fontSize: 24, fontWeight: 800, color: C.fg, margin: 0 }}>Выбери ракурс</h2>
        <p style={{ fontSize: 12, color: C.fg2, margin: '3px 0 0' }}>Одинаковый ракурс каждый раз — лучшее сравнение</p>
      </div>
    </div>
    <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {(['front', 'side', 'back', 'custom'] as PhotoAngle[]).map((angle) => (
          <button key={angle} onClick={() => onSelect(angle)} style={{ borderRadius: 18, border: `1.5px solid ${C.bd2}`, background: C.s2, cursor: 'pointer', overflow: 'hidden', padding: 0, textAlign: 'left' }}>
            <PhotoPlaceholder angle={angle} style={{ height: 130, width: '100%' }} />
            <div style={{ padding: '10px 14px' }}><div style={{ fontSize: 14, fontWeight: 700, color: C.fg }}>{ANGLE_META[angle].label}</div></div>
          </button>
        ))}
      </div>
    </div>
  </div>
)

// ─── CAPTURE SCREEN ───────────────────────────────────────────────────────────
const CaptureScreen = ({ angle, onCapture, onBack }: { angle: PhotoAngle; onCapture: () => void; onBack: () => void }) => {
  const [timerSec, setTimerSec] = useState<3 | 5 | 10 | null>(null)
  const [countdown, setCountdown] = useState(0)
  const isSide = angle === 'side'

  const doCapture = () => {
    if (!timerSec) { onCapture(); return }
    setCountdown(timerSec)
    const tick = setInterval(() => {
      setCountdown((c) => { if (c <= 1) { clearInterval(tick); onCapture(); return 0 } return c - 1 })
    }, 1000)
  }

  return (
    <div style={{ height: '100%', position: 'relative', background: '#000', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(160deg, #0a0d12 0%, #0d1018 100%)' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: `linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)`, backgroundSize: '60px 60px' }} />
      </div>
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -55%)' }}>
        {isSide ? <SilhouetteSide size={240} color="rgba(255,255,255,0.14)" /> : <SilhouetteFront size={220} color="rgba(255,255,255,0.14)" />}
      </div>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '52px 20px 16px', background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <BackBtn onClick={onBack} />
        <div style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(12px)', borderRadius: 99, padding: '6px 14px', border: '1px solid rgba(255,255,255,0.15)' }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{ANGLE_META[angle].label}</span>
        </div>
        <div style={{ width: 38 }} />
      </div>
      <div style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {([null, 3, 5, 10] as (3 | 5 | 10 | null)[]).map((t) => (
          <button key={String(t)} onClick={() => setTimerSec(t)} style={{ width: 40, height: 40, borderRadius: '50%', border: `1.5px solid ${timerSec === t ? C.acc : 'rgba(255,255,255,0.3)'}`, background: timerSec === t ? bc(C.acc, 0.2) : 'rgba(0,0,0,0.4)', color: timerSec === t ? C.acc : 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: 700, cursor: 'pointer', backdropFilter: 'blur(8px)' }}>
            {t === null ? '–' : `${t}с`}
          </button>
        ))}
      </div>
      {countdown > 0 && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.3)' }}>
          <span className="font-display" style={{ fontSize: 96, fontWeight: 900, color: C.acc }}>{countdown}</span>
        </div>
      )}
      <div style={{ position: 'absolute', bottom: 160, left: 20, right: 64 }}>
        <div style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', borderRadius: 12, padding: '10px 14px', border: '1px solid rgba(255,255,255,0.1)' }}>
          <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', margin: 0, lineHeight: 1.5 }}>Поставь камеру на одинаковую высоту и встань в похожую позу</p>
        </div>
      </div>
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '20px 40px 44px', background: 'linear-gradient(to top, rgba(0,0,0,0.85), transparent)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 20 }}>⟳</button>
        <button onClick={doCapture} disabled={countdown > 0} style={{ width: 76, height: 76, borderRadius: '50%', border: `4px solid ${C.acc}`, background: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 60, height: 60, borderRadius: '50%', background: countdown > 0 ? C.fg3 : C.acc }} />
        </button>
        <button style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 20 }}>⟲</button>
      </div>
    </div>
  )
}

// ─── PHOTO PREVIEW ────────────────────────────────────────────────────────────
const PhotoPreviewScreen = ({ angle, onSave, onRetake }: { angle: PhotoAngle; onSave: () => void; onRetake: () => void }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#000' }}>
    <PhotoPlaceholder angle={angle} index={2} style={{ flex: 1 }} />
    <div style={{ padding: '16px 20px 40px', background: C.bg, display: 'flex', gap: 10 }}>
      <button onClick={onRetake} style={{ flex: 1, padding: '14px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg, fontSize: 15, fontWeight: 600, cursor: 'pointer' }}>Переснять</button>
      <button onClick={onSave} style={{ flex: 2, padding: '14px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>Использовать</button>
    </div>
  </div>
)

// ─── METADATA SCREEN ──────────────────────────────────────────────────────────
const MILESTONES = ['Старт', '4 недели', '8 недель', 'После отпуска', 'Другое']

const MetadataScreen = ({ angle, onSave, onBack }: { angle: PhotoAngle; onSave: (d: { weightKg?: number; note?: string; milestone?: string }) => void; onBack: () => void }) => {
  const [weight, setWeight] = useState('')
  const [note, setNote] = useState('')
  const [milestone, setMilestone] = useState('')
  const today = new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 20px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <h2 className="font-display" style={{ fontSize: 24, fontWeight: 800, color: C.fg, margin: 0 }}>Сохранить фото</h2>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        <div style={{ marginBottom: 14, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>Дата</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: C.fg }}>{today}</div>
          </div>
          <Chip label={ANGLE_META[angle].label} color={C.s3} text={C.fg2} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Вес <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(необязательно)</span></div>
          <div style={{ display: 'flex', alignItems: 'center', background: C.s2, borderRadius: 14, border: `1px solid ${C.bd2}`, padding: '12px 16px', gap: 8 }}>
            <input type="number" placeholder="85.0" value={weight} onChange={(e) => setWeight(e.target.value)} style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: C.fg, fontSize: 20, fontWeight: 700 }} />
            <span style={{ fontSize: 14, color: C.fg2, fontWeight: 600 }}>кг</span>
          </div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Метка <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(необязательно)</span></div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {MILESTONES.map((m) => (
              <button key={m} onClick={() => setMilestone(milestone === m ? '' : m)} style={{ padding: '7px 14px', borderRadius: 99, border: `1.5px solid ${milestone === m ? C.acc : C.bd2}`, background: milestone === m ? bc(C.acc, 0.12) : C.s2, color: milestone === m ? C.acc : C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>{m}</button>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Заметка <span style={{ fontWeight: 400, textTransform: 'none', fontSize: 11 }}>(необязательно)</span></div>
          <textarea placeholder="Как себя чувствуешь..." value={note} onChange={(e) => setNote(e.target.value)} rows={3} style={{ width: '100%', background: C.s2, border: `1px solid ${C.bd2}`, borderRadius: 14, padding: '12px 16px', color: C.fg, fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box', lineHeight: 1.5 }} />
        </div>
      </div>
      <div style={{ padding: '12px 20px 32px', flexShrink: 0 }}>
        <Btn label="Сохранить фото" onClick={() => onSave({ weightKg: weight ? parseFloat(weight) : undefined, note: note || undefined, milestone: milestone || undefined })} />
      </div>
    </div>
  )
}

// ─── NOTIFICATION PROMPT ──────────────────────────────────────────────────────
const NotificationPrompt = ({ onSelect }: { onSelect: () => void }) => (
  <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'flex-end', zIndex: 10 }}>
    <div style={{ width: '100%', background: C.s1, borderRadius: '24px 24px 0 0', padding: '24px 20px 40px' }}>
      <div style={{ width: 40, height: 4, borderRadius: 99, background: C.bd2, margin: '0 auto 24px' }} />
      <h3 className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: '0 0 8px' }}>Напомнить о следующем фото?</h3>
      <p style={{ fontSize: 14, color: C.fg2, margin: '0 0 20px', lineHeight: 1.6 }}>Регулярные фото в одинаковом ракурсе помогают лучше видеть прогресс.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {['Через 2 недели', 'Через 4 недели', 'Через 8 недель', 'Не напоминать'].map((opt, i) => (
          <button key={opt} onClick={onSelect} style={{ padding: '14px', borderRadius: 14, border: `1.5px solid ${i < 3 ? C.bd2 : 'transparent'}`, background: i < 3 ? C.s2 : 'transparent', color: i < 3 ? C.fg : C.fg3, fontSize: 14, fontWeight: i < 3 ? 600 : 500, cursor: 'pointer', textAlign: 'left' }}>{opt}</button>
        ))}
      </div>
    </div>
  </div>
)

// ─── GALLERY / TIMELINE ───────────────────────────────────────────────────────
const GalleryScreen = ({ photos, onAdd, onCompare, onBack }: { photos: ProgressPhoto[]; onAdd: () => void; onCompare: (a: ProgressPhoto, b: ProgressPhoto) => void; onBack: () => void }) => {
  const [angleFilter, setAngleFilter] = useState<PhotoAngle | 'all'>('all')
  const [selected, setSelected] = useState<string[]>([])
  const filtered = angleFilter === 'all' ? photos : photos.filter((p) => p.angle === angleFilter)
  const angles = Array.from(new Set(photos.map((p) => p.angle))) as PhotoAngle[]
  const toggleSel = (id: string) => setSelected((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : prev.length < 2 ? [...prev, id] : [prev[1], id])
  const canCompare = selected.length === 2

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <BackBtn onClick={onBack} />
          <h2 className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.fg, margin: 0, flex: 1 }}>Все фото</h2>
          <button onClick={onAdd} style={{ width: 36, height: 36, borderRadius: '50%', background: C.acc, border: 'none', cursor: 'pointer', fontSize: 20, color: '#060F00', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>+</button>
        </div>
        <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4 }}>
          {(['all', ...angles] as (PhotoAngle | 'all')[]).map((a) => (
            <button key={a} onClick={() => setAngleFilter(a)} style={{ padding: '6px 14px', borderRadius: 99, border: `1.5px solid ${angleFilter === a ? C.acc : C.bd2}`, background: angleFilter === a ? bc(C.acc, 0.12) : C.s2, color: angleFilter === a ? C.acc : C.fg2, fontSize: 12, fontWeight: 700, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap' }}>
              {a === 'all' ? 'Все' : ANGLE_META[a].label}
            </button>
          ))}
        </div>
      </div>
      {selected.length > 0 && (
        <div style={{ padding: '0 20px 10px', flexShrink: 0 }}>
          <div style={{ background: bc(C.acc, 0.1), borderRadius: 12, padding: '10px 14px', border: `1px solid ${bc(C.acc, 0.3)}`, fontSize: 13, color: C.acc, fontWeight: 600 }}>
            {selected.length < 2 ? 'Выбери ещё одно фото для сравнения' : 'Готово — нажми «Сравнить»'}
          </div>
        </div>
      )}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {filtered.map((photo, idx) => {
          const isSel = selected.includes(photo.id)
          return (
            <div key={photo.id} onClick={() => toggleSel(photo.id)} style={{ display: 'flex', background: C.s2, borderRadius: 16, border: `1.5px solid ${isSel ? C.acc : C.bd}`, overflow: 'hidden', cursor: 'pointer', marginBottom: 10, transition: 'border-color 0.15s' }}>
              <PhotoPlaceholder angle={photo.angle} index={idx} style={{ width: 80, flexShrink: 0 }} />
              <div style={{ flex: 1, padding: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: C.fg }}>{fmtDate(photo.date)}</span>
                  {photo.milestone && <Chip label={photo.milestone} color={bc(C.acc, 0.12)} text={C.acc} small />}
                </div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  <Chip label={ANGLE_META[photo.angle].label} color={C.s3} text={C.fg2} small />
                  {photo.weightKg && <span style={{ fontSize: 12, color: C.fg2 }}>{photo.weightKg} кг</span>}
                </div>
              </div>
              {isSel && (
                <div style={{ width: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', background: bc(C.acc, 0.12), flexShrink: 0 }}>
                  <div style={{ width: 20, height: 20, borderRadius: '50%', background: C.acc, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 10, color: '#060F00', fontWeight: 800 }}>✓</span>
                  </div>
                </div>
              )}
            </div>
          )
        })}
        <div style={{ height: 16 }} />
      </div>
      <div style={{ padding: '12px 20px 96px', flexShrink: 0 }}>
        <button onClick={() => { if (canCompare) { const [a, b] = selected.map((id) => photos.find((p) => p.id === id)!); onCompare(a, b) } }} disabled={!canCompare} style={{ width: '100%', padding: '15px', borderRadius: 14, border: 'none', cursor: canCompare ? 'pointer' : 'not-allowed', background: canCompare ? C.acc : C.s3, color: canCompare ? '#060F00' : C.fg3, fontSize: 16, fontWeight: 700, transition: 'all 0.15s' }}>
          {canCompare ? 'Сравнить выбранные' : 'Выбери 2 фото'}
        </button>
      </div>
    </div>
  )
}

// ─── COMPARE SCREEN ───────────────────────────────────────────────────────────
const CompareScreen = ({ photoA, photoB, onExport, onBack, onSwap, onChooseOther }: { photoA: ProgressPhoto; photoB: ProgressPhoto; onExport: () => void; onBack: () => void; onSwap: () => void; onChooseOther: () => void }) => {
  const [mode, setMode] = useState<'side' | 'slider'>('side')
  const [hideWeight, setHideWeight] = useState(false)
  const [sliderPct, setSliderPct] = useState(50)
  const areaRef = useRef<HTMLDivElement>(null)
  const angleWarn = photoA.angle !== photoB.angle

  const onPtrEvt = (e: React.PointerEvent) => {
    if (!(e.buttons & 1) && e.type !== 'pointerdown') return
    const el = areaRef.current; if (!el) return
    const rect = el.getBoundingClientRect()
    setSliderPct(Math.max(5, Math.min(95, ((e.clientX - rect.left) / rect.width) * 100)))
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 12px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <h2 className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: 0, flex: 1 }}>Сравнение</h2>
        <button onClick={onExport} style={{ padding: '8px 14px', borderRadius: 99, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>↑ Экспорт</button>
      </div>
      {angleWarn && (
        <div style={{ padding: '0 20px 8px', flexShrink: 0 }}>
          <div style={{ background: bc(C.warn, 0.1), borderRadius: 10, padding: '8px 12px', border: `1px solid ${bc(C.warn, 0.3)}`, fontSize: 12, color: C.warn }}>
            ⚠ Разные ракурсы: {ANGLE_META[photoA.angle].label} и {ANGLE_META[photoB.angle].label}
          </div>
        </div>
      )}
      <div style={{ padding: '0 20px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', background: C.s2, borderRadius: 12, padding: 3, gap: 2, border: `1px solid ${C.bd}` }}>
          {(['side', 'slider'] as const).map((m) => (
            <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: '9px', borderRadius: 9, border: 'none', cursor: 'pointer', background: mode === m ? C.acc : 'transparent', color: mode === m ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s' }}>
              {m === 'side' ? 'Рядом' : 'Слайдер'}
            </button>
          ))}
        </div>
      </div>
      <div style={{ flex: 1, padding: '0 20px', minHeight: 0 }}>
        {mode === 'side' ? (
          <div style={{ height: '100%', display: 'flex', gap: 8 }}>
            {[photoA, photoB].map((p, i) => (
              <div key={p.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <PhotoPlaceholder angle={p.angle} index={i} style={{ flex: 1, borderRadius: 14, overflow: 'hidden' }} />
                <div style={{ textAlign: 'center', paddingBottom: 4 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.fg }}>{fmtDateShort(p.date)}</div>
                  {!hideWeight && p.weightKg && <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>{p.weightKg} кг</div>}
                  {p.milestone && <div style={{ fontSize: 11, color: C.acc, marginTop: 2 }}>{p.milestone}</div>}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div
            ref={areaRef}
            style={{ height: '100%', position: 'relative', borderRadius: 14, overflow: 'hidden', cursor: 'col-resize', touchAction: 'none' }}
            onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); onPtrEvt(e) }}
            onPointerMove={onPtrEvt}
          >
            <PhotoPlaceholder angle={photoA.angle} index={0} style={{ position: 'absolute', inset: 0 }} />
            <div style={{ position: 'absolute', inset: 0, clipPath: `inset(0 ${100 - sliderPct}% 0 0)` }}>
              <PhotoPlaceholder angle={photoB.angle} index={1} style={{ position: 'absolute', inset: 0 }} />
            </div>
            <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${sliderPct}%`, width: 2, background: 'white', transform: 'translateX(-1px)', zIndex: 2 }}>
              <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 34, height: 34, borderRadius: '50%', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 16px rgba(0,0,0,0.5)', fontSize: 14, color: '#000', fontWeight: 700 }}>⟺</div>
            </div>
            <div style={{ position: 'absolute', top: 12, left: 12, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', borderRadius: 8, padding: '4px 10px', fontSize: 12, color: 'white', fontWeight: 700 }}>До</div>
            <div style={{ position: 'absolute', top: 12, right: 12, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', borderRadius: 8, padding: '4px 10px', fontSize: 12, color: 'white', fontWeight: 700 }}>После</div>
            {!hideWeight && (
              <>
                <div style={{ position: 'absolute', bottom: 12, left: 12, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', borderRadius: 8, padding: '4px 10px', fontSize: 11, color: 'rgba(255,255,255,0.85)' }}>{fmtDateShort(photoA.date)}{photoA.weightKg ? ` · ${photoA.weightKg} кг` : ''}</div>
                <div style={{ position: 'absolute', bottom: 12, right: 12, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', borderRadius: 8, padding: '4px 10px', fontSize: 11, color: 'rgba(255,255,255,0.85)' }}>{fmtDateShort(photoB.date)}{photoB.weightKg ? ` · ${photoB.weightKg} кг` : ''}</div>
              </>
            )}
          </div>
        )}
      </div>
      <div style={{ padding: '10px 20px 28px', flexShrink: 0 }}>
        <ToggleSwitch label="Скрыть вес" val={hideWeight} onToggle={() => setHideWeight(!hideWeight)} />
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onSwap} style={{ flex: 1, padding: '12px', borderRadius: 12, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>⇄ Поменять</button>
          <button onClick={onChooseOther} style={{ flex: 1, padding: '12px', borderRadius: 12, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Другие фото</button>
        </div>
      </div>
    </div>
  )
}

// ─── EXPORT SCREEN ────────────────────────────────────────────────────────────
const ExportScreen = ({ photoA, photoB, onBack }: { photoA: ProgressPhoto; photoB: ProgressPhoto; onBack: () => void }) => {
  const [hideWeight, setHideWeight] = useState(true)
  const [hideDate, setHideDate] = useState(false)
  const [watermark, setWatermark] = useState(true)
  const [exportMode, setExportMode] = useState<'side' | 'slider'>('side')
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 20px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <h2 className="font-display" style={{ fontSize: 24, fontWeight: 800, color: C.fg, margin: 0 }}>Экспорт</h2>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        <div style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 20 }}>
          <div style={{ display: 'flex', height: 160 }}>
            <PhotoPlaceholder angle={photoA.angle} index={0} style={{ flex: 1 }} />
            <div style={{ width: 1, background: C.bd }} />
            <PhotoPlaceholder angle={photoB.angle} index={1} style={{ flex: 1 }} />
          </div>
          <div style={{ padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            {[photoA, photoB].map((p) => (
              <div key={p.id} style={{ textAlign: 'center' }}>
                {!hideDate && <div style={{ fontSize: 11, color: C.fg2 }}>{fmtDateShort(p.date)}</div>}
                {!hideWeight && p.weightKg && <div style={{ fontSize: 12, fontWeight: 700, color: C.fg }}>{p.weightKg} кг</div>}
              </div>
            ))}
          </div>
          {watermark && <div style={{ padding: '6px 14px 10px', borderTop: `1px solid ${C.bd}`, fontSize: 11, color: C.fg3, textAlign: 'center' }}>FitApp · Прогресс</div>}
        </div>
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Режим</div>
          <div style={{ display: 'flex', background: C.s2, borderRadius: 12, padding: 3, gap: 2, border: `1px solid ${C.bd}` }}>
            {(['side', 'slider'] as const).map((m) => (
              <button key={m} onClick={() => setExportMode(m)} style={{ flex: 1, padding: '9px', borderRadius: 9, border: 'none', cursor: 'pointer', background: exportMode === m ? C.acc : 'transparent', color: exportMode === m ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s' }}>{m === 'side' ? 'Рядом' : 'Слайдер'}</button>
            ))}
          </div>
        </div>
        <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '0 14px', marginBottom: 20 }}>
          <ToggleSwitch label="Скрыть вес" val={hideWeight} onToggle={() => setHideWeight(!hideWeight)} />
          <ToggleSwitch label="Скрыть дату" val={hideDate} onToggle={() => setHideDate(!hideDate)} />
          <ToggleSwitch label="Скрыть лицо" val={false} onToggle={() => {}} />
          <ToggleSwitch label="Водяной знак" val={watermark} onToggle={() => setWatermark(!watermark)} />
        </div>
      </div>
      <div style={{ padding: '12px 20px 32px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn label="Сохранить изображение" onClick={() => {}} />
        <button style={{ width: '100%', padding: '14px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg, fontSize: 15, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>↑ Поделиться</button>
      </div>
    </div>
  )
}

// ─── PHOTO PROGRESS MODULE ────────────────────────────────────────────────────
type PhotoFlow = 'gallery' | 'privacy' | 'angle' | 'capture' | 'preview' | 'metadata' | 'notification' | 'compare' | 'export'

const ProgressPhotoModule = ({ initialPhotos, onClose }: { initialPhotos: ProgressPhoto[]; onClose: () => void }) => {
  const [photos, setPhotos] = useState<ProgressPhoto[]>(initialPhotos)
  const [flow, setFlow] = useState<PhotoFlow>('gallery')
  const [pendingAngle, setPendingAngle] = useState<PhotoAngle>('front')
  const [privacySeen] = useState(true)
  const [compareA, setCompareA] = useState<ProgressPhoto>(initialPhotos[0])
  const [compareB, setCompareB] = useState<ProgressPhoto>(initialPhotos[1] ?? initialPhotos[0])

  const goAdd = () => privacySeen ? setFlow('angle') : setFlow('privacy')

  const afterSave = (data: { weightKg?: number; note?: string; milestone?: string }) => {
    const p: ProgressPhoto = { id: Date.now().toString(), date: new Date().toISOString().split('T')[0], angle: pendingAngle, ...data }
    setPhotos((prev) => [p, ...prev])
    setFlow('notification')
  }

  if (flow === 'privacy') return <PrivacyScreen onOk={() => setFlow('angle')} onBack={() => setFlow('gallery')} />
  if (flow === 'angle') return <AngleSelectScreen onSelect={(a) => { setPendingAngle(a); setFlow('capture') }} onBack={() => setFlow('gallery')} />
  if (flow === 'capture') return <CaptureScreen angle={pendingAngle} onCapture={() => setFlow('preview')} onBack={() => setFlow('angle')} />
  if (flow === 'preview') return <PhotoPreviewScreen angle={pendingAngle} onSave={() => setFlow('metadata')} onRetake={() => setFlow('capture')} />
  if (flow === 'metadata') return <MetadataScreen angle={pendingAngle} onSave={afterSave} onBack={() => setFlow('preview')} />
  if (flow === 'compare') return <CompareScreen photoA={compareA} photoB={compareB} onExport={() => setFlow('export')} onBack={() => setFlow('gallery')} onSwap={() => { setCompareA(compareB); setCompareB(compareA) }} onChooseOther={() => setFlow('gallery')} />
  if (flow === 'export') return <ExportScreen photoA={compareA} photoB={compareB} onBack={() => setFlow('compare')} />
  if (flow === 'notification') return (
    <div style={{ height: '100%', position: 'relative', background: C.bg }}>
      <GalleryScreen photos={photos} onAdd={goAdd} onCompare={(a, b) => { setCompareA(a); setCompareB(b); setFlow('compare') }} onBack={onClose} />
      <NotificationPrompt onSelect={() => setFlow('gallery')} />
    </div>
  )
  return photos.length === 0
    ? <PhotoEmptyState onAdd={goAdd} />
    : <GalleryScreen photos={photos} onAdd={goAdd} onCompare={(a, b) => { setCompareA(a); setCompareB(b); setFlow('compare') }} onBack={onClose} />
}

// ─── PROGRESS SCREEN ──────────────────────────────────────────────────────────
const ProgressScreen = () => {
  const [photoOpen, setPhotoOpen] = useState(false)
  const frontPhotos = INITIAL_PHOTOS.filter((p) => p.angle === 'front').sort((a, b) => a.date.localeCompare(b.date))

  if (photoOpen) return <ProgressPhotoModule initialPhotos={INITIAL_PHOTOS} onClose={() => setPhotoOpen(false)} />

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 12px', flexShrink: 0 }}>
        <h1 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, margin: 0, lineHeight: 1.1 }}>Прогресс</h1>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {[['14', 'тренировок'], ['28', 'дней'], ['3', 'рекорда']].map(([val, lbl]) => (
            <div key={lbl} style={{ flex: 1, background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: '14px 10px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.acc }}>{val}</div>
              <div style={{ fontSize: 10, color: C.fg2, marginTop: 2 }}>{lbl}</div>
            </div>
          ))}
        </div>
        <Card style={{ padding: 16, marginBottom: 14 }}>
          <Label style={{ marginBottom: 10, display: 'block' }}>Регулярность — август</Label>
          <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: 50 }}>
            {[0.3, 0.7, 0.5, 1, 0.8, 0.4, 0, 0.9, 0.6, 0.85, 1, 0.5, 0.3, 0, 0.7, 0.9].map((h, i) => (
              <div key={i} style={{ flex: 1, height: `${h * 100}%`, borderRadius: 4, background: h >= 0.9 ? C.acc : h > 0 ? bc(C.acc, 0.4) : C.s3 }} />
            ))}
          </div>
        </Card>
        <Card style={{ padding: 16, marginBottom: 14 }}>
          <Label style={{ marginBottom: 6, display: 'block' }}>Объём (кг) · <span style={{ color: C.ok, fontWeight: 700 }}>+18% за месяц</span></Label>
          <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: 60 }}>
            {[0.4, 0.6, 0.5, 0.8, 0.75, 0.9, 0.7, 1, 0.85, 0.95].map((h, i) => (
              <div key={i} style={{ flex: 1, height: `${h * 100}%`, borderRadius: 4, background: bc(C.ok, 0.4 + h * 0.6) }} />
            ))}
          </div>
        </Card>
        {/* Photo Progress Block */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <Label>Фото прогресса</Label>
            {frontPhotos.length > 0 && <button onClick={() => setPhotoOpen(true)} style={{ fontSize: 12, color: C.acc, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>Все →</button>}
          </div>
          {frontPhotos.length === 0 ? (
            <button onClick={() => setPhotoOpen(true)} style={{ width: '100%', padding: '20px', borderRadius: 18, border: `1.5px dashed ${C.bd2}`, background: 'transparent', cursor: 'pointer', textAlign: 'center' }}>
              <div style={{ fontSize: 26, marginBottom: 8 }}>📷</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.fg }}>Добавить первое фото</div>
              <div style={{ fontSize: 12, color: C.fg2, marginTop: 4 }}>Сравнивай изменения во времени</div>
            </button>
          ) : (
            <div style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
              <div style={{ display: 'flex', height: 140 }}>
                <PhotoPlaceholder angle="front" index={0} style={{ flex: 1 }} />
                <div style={{ width: 1, background: C.bd }} />
                <PhotoPlaceholder angle="front" index={2} style={{ flex: 1 }} />
              </div>
              <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 12, color: C.fg2 }}>{fmtDateShort(frontPhotos[0].date)} → {fmtDateShort(frontPhotos[frontPhotos.length - 1].date)}</div>
                  {frontPhotos[0].weightKg && frontPhotos[frontPhotos.length - 1].weightKg !== undefined && (
                    <div style={{ fontSize: 13, color: C.ok, fontWeight: 700, marginTop: 2 }}>−{(frontPhotos[0].weightKg - frontPhotos[frontPhotos.length - 1].weightKg!).toFixed(1)} кг</div>
                  )}
                </div>
                <button onClick={() => setPhotoOpen(true)} style={{ padding: '9px 18px', borderRadius: 10, border: 'none', background: C.acc, color: '#060F00', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Сравнить</button>
              </div>
            </div>
          )}
        </div>
        <div style={{ height: 90 }} />
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// ТРЕНЕР ПО ТЕХНИКЕ — HUMAN SKELETON
// ══════════════════════════════════════════════════════════════════════════════

// Anatomically correct human skeleton overlay
const HumanSkeleton = ({
  highlightSegment,
  status = 'ok',
  ghost = false,
}: {
  highlightSegment?: 'spine' | 'knees' | 'elbows' | 'hips' | 'shoulders'
  status?: 'ok' | 'warn' | 'lost'
  ghost?: boolean
}) => {
  const baseCol = ghost
    ? 'rgba(255,255,255,0.18)'
    : status === 'ok' ? C.ok : status === 'warn' ? C.warn : 'rgba(255,255,255,0.3)'
  const jointR = ghost ? 4 : 5.5
  const strokeW = ghost ? 2 : 3

  const segCol = (seg: typeof highlightSegment) =>
    !ghost && highlightSegment === seg ? C.err : baseCol

  // Key joint positions in a 160×380 viewBox
  // Head
  const hx = 80; const hy = 28
  // Neck base
  const nx = 80; const ny = 52
  // Shoulder midpoint (top of torso)
  const smx = 80; const smy = 62
  // Shoulders
  const lsx = 52; const lsy = 72; const rsx = 108; const rsy = 72
  // Elbows
  const lex = 37; const ley = 130; const rex = 123; const rey = 130
  // Wrists
  const lwx = 29; const lwy = 184; const rwx = 131; const rwy = 184
  // Hips
  const lhx = 60; const lhy = 200; const rhx = 100; const rhy = 200
  // Hip midpoint (bottom of torso)
  const hmx = 80; const hmy = 195
  // Knees
  const lkx = 56; const lky = 283; const rkx = 104; const rky = 283
  // Ankles
  const lax = 52; const lay = 362; const rax = 108; const ray = 362

  return (
    <svg
      viewBox="0 0 160 390"
      style={{
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        width: '55%',
        height: '85%',
        overflow: 'visible',
      }}
    >
      {/* ── Bones ── */}
      {/* Neck */}
      <line x1={nx} y1={ny} x2={hx} y2={hy + 22} stroke={segCol('spine')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Spine */}
      <line x1={smx} y1={smy} x2={hmx} y2={hmy} stroke={segCol('spine')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Collarbone / shoulder girdle */}
      <line x1={lsx} y1={lsy} x2={smx} y2={smy} stroke={segCol('shoulders')} strokeWidth={strokeW} strokeLinecap="round" />
      <line x1={rsx} y1={rsy} x2={smx} y2={smy} stroke={segCol('shoulders')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Upper arms */}
      <line x1={lsx} y1={lsy} x2={lex} y2={ley} stroke={segCol('elbows')} strokeWidth={strokeW} strokeLinecap="round" />
      <line x1={rsx} y1={rsy} x2={rex} y2={rey} stroke={segCol('elbows')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Forearms */}
      <line x1={lex} y1={ley} x2={lwx} y2={lwy} stroke={baseCol} strokeWidth={strokeW} strokeLinecap="round" />
      <line x1={rex} y1={rey} x2={rwx} y2={rwy} stroke={baseCol} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Torso sides (ribcage outline feel) */}
      <line x1={lsx} y1={lsy} x2={lhx} y2={lhy} stroke={segCol('spine')} strokeWidth={strokeW - 0.5} strokeLinecap="round" opacity={0.55} />
      <line x1={rsx} y1={rsy} x2={rhx} y2={rhy} stroke={segCol('spine')} strokeWidth={strokeW - 0.5} strokeLinecap="round" opacity={0.55} />
      {/* Hip bridge */}
      <line x1={lhx} y1={lhy} x2={rhx} y2={rhy} stroke={segCol('hips')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Thighs */}
      <line x1={lhx} y1={lhy} x2={lkx} y2={lky} stroke={segCol('knees')} strokeWidth={strokeW} strokeLinecap="round" />
      <line x1={rhx} y1={rhy} x2={rkx} y2={rky} stroke={segCol('knees')} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Shins */}
      <line x1={lkx} y1={lky} x2={lax} y2={lay} stroke={baseCol} strokeWidth={strokeW} strokeLinecap="round" />
      <line x1={rkx} y1={rky} x2={rax} y2={ray} stroke={baseCol} strokeWidth={strokeW} strokeLinecap="round" />
      {/* Feet */}
      <line x1={lax} y1={lay} x2={lax - 8} y2={lay + 4} stroke={baseCol} strokeWidth={strokeW - 1} strokeLinecap="round" />
      <line x1={rax} y1={ray} x2={rax + 8} y2={ray + 4} stroke={baseCol} strokeWidth={strokeW - 1} strokeLinecap="round" />

      {/* ── Joints ── */}
      {/* Head */}
      <circle cx={hx} cy={hy} r={ghost ? 10 : 14} fill="none" stroke={segCol('shoulders')} strokeWidth={strokeW} opacity={ghost ? 0.6 : 0.95} />
      {/* Neck + shoulder mid */}
      {[[nx, ny], [smx, smy]].map(([cx, cy], i) => (
        <circle key={`t${i}`} cx={cx} cy={cy} r={jointR - 1} fill={segCol('spine')} opacity={ghost ? 0.5 : 0.8} />
      ))}
      {/* Shoulders */}
      <circle cx={lsx} cy={lsy} r={jointR} fill={segCol('shoulders')} opacity={ghost ? 0.6 : 0.95} />
      <circle cx={rsx} cy={rsy} r={jointR} fill={segCol('shoulders')} opacity={ghost ? 0.6 : 0.95} />
      {/* Elbows */}
      <circle cx={lex} cy={ley} r={jointR} fill={segCol('elbows')} opacity={ghost ? 0.6 : 0.95} />
      <circle cx={rex} cy={rey} r={jointR} fill={segCol('elbows')} opacity={ghost ? 0.6 : 0.95} />
      {/* Wrists */}
      <circle cx={lwx} cy={lwy} r={jointR - 1.5} fill={baseCol} opacity={ghost ? 0.5 : 0.85} />
      <circle cx={rwx} cy={rwy} r={jointR - 1.5} fill={baseCol} opacity={ghost ? 0.5 : 0.85} />
      {/* Hips */}
      <circle cx={lhx} cy={lhy} r={jointR} fill={segCol('hips')} opacity={ghost ? 0.6 : 0.95} />
      <circle cx={rhx} cy={rhy} r={jointR} fill={segCol('hips')} opacity={ghost ? 0.6 : 0.95} />
      {/* Knees */}
      <circle cx={lkx} cy={lky} r={jointR + 1} fill={segCol('knees')} opacity={ghost ? 0.6 : 0.95} />
      <circle cx={rkx} cy={rky} r={jointR + 1} fill={segCol('knees')} opacity={ghost ? 0.6 : 0.95} />
      {/* Ankles */}
      <circle cx={lax} cy={lay} r={jointR - 1} fill={baseCol} opacity={ghost ? 0.5 : 0.85} />
      <circle cx={rax} cy={ray} r={jointR - 1} fill={baseCol} opacity={ghost ? 0.5 : 0.85} />

      {/* Error highlight ring around problem joint */}
      {!ghost && highlightSegment === 'knees' && (
        <>
          <circle cx={lkx} cy={lky} r={14} fill="none" stroke={C.err} strokeWidth={2.5} opacity={0.7} />
          <circle cx={rkx} cy={rky} r={14} fill="none" stroke={C.err} strokeWidth={2.5} opacity={0.7} />
        </>
      )}
      {!ghost && highlightSegment === 'spine' && (
        <rect x={smx - 8} y={smy - 4} width={16} height={hmy - smy + 8} rx={6} fill="none" stroke={C.err} strokeWidth={2} opacity={0.65} />
      )}
    </svg>
  )
}

// ── ANGLE GUIDE DIAGRAM ──────────────────────────────────────────────────────
const AngleGuide = ({ angle }: { angle: 'front' | 'side' | '45deg' }) => (
  <svg viewBox="0 0 120 160" style={{ width: 80, height: 108 }}>
    {/* Phone silhouette */}
    <rect x={5} y={8} width={22} height={40} rx={3} fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth={1.5} />
    <circle cx={16} cy={11} r={1.5} fill="rgba(255,255,255,0.3)" />
    {/* Arrow / direction */}
    {angle === 'front' && (
      <>
        <line x1={50} y1={80} x2={50} y2={20} stroke={C.acc} strokeWidth={2} strokeLinecap="round" />
        <polygon points="50,12 44,24 56,24" fill={C.acc} />
        {/* Body facing front */}
        <circle cx={90} cy={25} r={8} fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={82} y1={40} x2={98} y2={40} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={90} y1={40} x2={90} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={82} y1={55} x2={90} y2={45} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={98} y1={55} x2={90} y2={45} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={82} y1={110} x2={90} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={98} y1={110} x2={90} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
      </>
    )}
    {angle === 'side' && (
      <>
        <line x1={50} y1={80} x2={80} y2={80} stroke={C.acc} strokeWidth={2} strokeLinecap="round" />
        <polygon points="88,80 76,74 76,86" fill={C.acc} />
        {/* Body side silhouette */}
        <circle cx={90} cy={25} r={7} fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={90} y1={32} x2={90} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={2} strokeLinecap="round" />
        <line x1={90} y1={45} x2={80} y2={70} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={90} y1={75} x2={85} y2={110} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={90} y1={75} x2={95} y2={110} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
      </>
    )}
    {angle === '45deg' && (
      <>
        <line x1={50} y1={80} x2={72} y2={55} stroke={C.acc} strokeWidth={2} strokeLinecap="round" />
        <polygon points="78,48 66,52 70,64" fill={C.acc} />
        <circle cx={90} cy={25} r={7} fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={90} y1={32} x2={88} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={2} />
        <line x1={80} y1={58} x2={88} y2={48} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={97} y1={58} x2={88} y2={48} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={82} y1={110} x2={88} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
        <line x1={94} y1={110} x2={88} y2={75} stroke="rgba(255,255,255,0.5)" strokeWidth={1.5} />
      </>
    )}
  </svg>
)

// ── MAIN TECH COACH SCREEN ───────────────────────────────────────────────────
type TechCoachPhase =
  | 'launch'
  | 'preparation'
  | 'quality-check'
  | 'calibration'
  | 'ready'
  | 'active'
  | 'paused'
  | 'summary'

type QualityState = 'loading' | 'too-dark' | 'wrong-angle' | 'body-partial' | 'ok'
type ActiveCue = null | 'spine' | 'knees' | 'depth' | 'tempo'

const EXERCISE_NAME = 'Тяга верхнего блока'
const EXERCISE_ANGLE: 'front' | 'side' | '45deg' = 'front'

const ACTIVE_CUES: Array<{ text: string; segment?: 'spine' | 'knees' | 'elbows' | 'hips' | 'shoulders'; type: 'ok' | 'warn' }> = [
  { text: 'Держи спину нейтральной', segment: 'spine', type: 'warn' },
  { text: 'Сведи лопатки в нижней точке', segment: 'shoulders', type: 'warn' },
  { text: 'Хороший ритм — продолжай', type: 'ok' },
  { text: 'Опускай штангу медленнее', segment: 'elbows', type: 'warn' },
  { text: 'Отличная техника!', type: 'ok' },
]

const PHASES_TEXT = ['Вверх', 'Удержание', 'Вниз', 'Готов к повтору']

const TechCoachScreen = ({ onBack, onDone }: { onBack: () => void; onDone: () => void }) => {
  const [phase, setPhase] = useState<TechCoachPhase>('launch')
  const [quality, setQuality] = useState<QualityState>('loading')
  const [reps, setReps] = useState(0)
  const [phaseIdx, setPhaseIdx] = useState(0)
  const [cueIdx, setCueIdx] = useState(0)
  const [voiceOn, setVoiceOn] = useState(true)
  const [calibPct, setCalibPct] = useState(0)
  const [poseLost, setPoseLost] = useState(false)

  // Quality gate simulation
  useEffect(() => {
    if (phase !== 'quality-check') return
    const steps: QualityState[] = ['loading', 'too-dark', 'wrong-angle', 'ok']
    let i = 0
    setQuality('loading')
    const tick = () => {
      i++
      if (i < steps.length) {
        setQuality(steps[i])
        setTimeout(tick, i === 1 ? 1800 : i === 2 ? 2000 : 1600)
      }
    }
    setTimeout(tick, 1200)
  }, [phase])

  // Calibration simulation
  useEffect(() => {
    if (phase !== 'calibration') return
    setCalibPct(0)
    const iv = setInterval(() => {
      setCalibPct((p) => {
        if (p >= 100) { clearInterval(iv); setTimeout(() => setPhase('ready'), 400); return 100 }
        return p + 4
      })
    }, 60)
    return () => clearInterval(iv)
  }, [phase])

  // Active rep counting
  useEffect(() => {
    if (phase !== 'active') return
    const repIv = setInterval(() => {
      setReps((r) => r + 1)
      setCueIdx((c) => (c + 1) % ACTIVE_CUES.length)
      setPhaseIdx((p) => (p + 1) % PHASES_TEXT.length)
    }, 2800)
    const poseIv = setInterval(() => {
      setPoseLost((v) => !v)
    }, 11000)
    const end = setTimeout(() => { clearInterval(repIv); clearInterval(poseIv); setPhase('summary') }, 18000)
    return () => { clearInterval(repIv); clearInterval(poseIv); clearTimeout(end) }
  }, [phase])

  const currentCue = ACTIVE_CUES[cueIdx]

  // ── SUMMARY ──────────────────────────────────────────────────────────────
  if (phase === 'summary') return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 16px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <div>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Тренер по технике</div>
          <h2 className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: 0 }}>{EXERCISE_NAME}</h2>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Hero stats */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {[['6', 'повторений'], ['5', 'оценены уверенно'], ['1:14', 'длительность']].map(([v, l]) => (
            <div key={l} style={{ flex: 1, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '14px 6px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.acc }}>{v}</div>
              <div style={{ fontSize: 10, color: C.fg2, marginTop: 3, lineHeight: 1.3 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Good */}
        <Card style={{ padding: 16, marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div style={{ width: 24, height: 24, borderRadius: '50%', background: bc(C.ok, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>✓</div>
            <span style={{ fontSize: 13, fontWeight: 700, color: C.ok }}>Что хорошо</span>
          </div>
          {['Стабильный ритм движений', 'Стартовая позиция уверенная', 'Симметрия рук — в норме'].map((t) => (
            <div key={t} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'flex-start' }}>
              <span style={{ color: C.ok, fontSize: 13, marginTop: 1 }}>·</span>
              <span style={{ fontSize: 13, color: C.fg2 }}>{t}</span>
            </div>
          ))}
        </Card>

        {/* Improve */}
        <Card style={{ padding: 16, marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div style={{ width: 24, height: 24, borderRadius: '50%', background: bc(C.warn, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: C.warn }}>→</div>
            <span style={{ fontSize: 13, fontWeight: 700, color: C.warn }}>Что улучшить</span>
          </div>
          {['Держи спину нейтральнее', 'Опускай медленнее — 3 с вниз'].map((t) => (
            <div key={t} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'flex-start' }}>
              <span style={{ color: C.warn, fontSize: 13, marginTop: 1 }}>·</span>
              <span style={{ fontSize: 13, color: C.fg2 }}>{t}</span>
            </div>
          ))}
        </Card>

        {/* Skeleton summary */}
        <div style={{ background: '#0a0c10', borderRadius: 16, border: `1px solid ${C.bd2}`, height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12, position: 'relative', overflow: 'hidden' }}>
          <HumanSkeleton status="ok" />
          <div style={{ position: 'absolute', bottom: 10, left: 0, right: 0, textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>Итоговое положение</div>
        </div>

        <div style={{ background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, padding: 12, fontSize: 11, color: C.fg3, lineHeight: 1.6, marginBottom: 20 }}>
          Камера использовалась только для проверки техники в этой сессии.
        </div>
      </div>
      <div style={{ padding: '10px 20px 32px', flexShrink: 0, display: 'flex', gap: 10 }}>
        <button onClick={() => setPhase('launch')} style={{ flex: 1, padding: '13px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
          Ещё раз
        </button>
        <button onClick={onDone} style={{ flex: 2, padding: '13px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
          Вернуться к тренировке
        </button>
      </div>
    </div>
  )

  // ── ACTIVE / PAUSED ───────────────────────────────────────────────────────
  if (phase === 'active' || phase === 'paused') return (
    <div style={{ height: '100%', position: 'relative', background: '#060810', overflow: 'hidden' }}>
      {/* Camera BG gradient */}
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 60%, #0e1828 0%, #060810 100%)' }} />

      {/* Ghost target silhouette */}
      <HumanSkeleton ghost />

      {/* Live skeleton */}
      {!poseLost && phase === 'active' && (
        <HumanSkeleton
          highlightSegment={currentCue.segment}
          status={currentCue.type === 'warn' ? 'warn' : 'ok'}
        />
      )}

      {/* Pose lost overlay */}
      {poseLost && phase === 'active' && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 5 }}>
          <div style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)', borderRadius: 16, padding: '14px 20px', border: `1.5px solid ${bc(C.warn, 0.5)}`, textAlign: 'center', maxWidth: 240 }}>
            <div style={{ fontSize: 20, marginBottom: 6 }}>👤</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.warn }}>Не вижу позу</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 4 }}>Вернись в кадр, чтобы продолжить</div>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '50px 16px 14px', background: 'linear-gradient(to bottom, rgba(0,0,0,0.85) 0%, transparent 100%)', display: 'flex', alignItems: 'center', gap: 10, zIndex: 10 }}>
        <button onClick={() => setPhase('paused')} style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', color: '#fff', fontSize: 16, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>←</button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Тренер по технике</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{EXERCISE_NAME}</div>
        </div>
        <button onClick={() => setVoiceOn((v) => !v)} style={{ width: 36, height: 36, borderRadius: '50%', background: voiceOn ? bc(C.acc, 0.2) : 'rgba(255,255,255,0.1)', border: `1px solid ${voiceOn ? bc(C.acc, 0.5) : 'rgba(255,255,255,0.15)'}`, color: voiceOn ? C.acc : 'rgba(255,255,255,0.5)', fontSize: 15, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          {voiceOn ? '🔊' : '🔇'}
        </button>
      </div>

      {/* Rep counter — top right corner badge */}
      <div style={{ position: 'absolute', top: 110, right: 16, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', borderRadius: 14, padding: '8px 14px', border: `1px solid rgba(255,255,255,0.1)`, textAlign: 'center', zIndex: 10 }}>
        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.45)', fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase' }}>Повторения</div>
        <div className="font-display" style={{ fontSize: 36, fontWeight: 900, color: C.acc, lineHeight: 1, marginTop: 1 }}>{reps}</div>
        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.35)', marginTop: 1 }}>из 12</div>
      </div>

      {/* Phase indicator — top left */}
      {phase === 'active' && !poseLost && (
        <div style={{ position: 'absolute', top: 110, left: 16, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(8px)', borderRadius: 14, padding: '8px 14px', border: `1px solid rgba(255,255,255,0.1)`, zIndex: 10 }}>
          <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.45)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Фаза</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginTop: 2 }}>{PHASES_TEXT[phaseIdx]}</div>
        </div>
      )}

      {/* Bottom controls area */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 10 }}>
        {/* Cue card */}
        {phase === 'active' && !poseLost && (
          <div style={{ margin: '0 16px 10px', background: 'rgba(10,12,20,0.82)', backdropFilter: 'blur(12px)', borderRadius: 16, padding: '12px 16px', border: `1px solid ${currentCue.type === 'warn' ? bc(C.warn, 0.35) : bc(C.ok, 0.35)}`, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: currentCue.type === 'warn' ? C.warn : C.ok, flexShrink: 0 }} />
            <span style={{ fontSize: 14, fontWeight: 600, color: '#fff', lineHeight: 1.4 }}>{currentCue.text}</span>
          </div>
        )}

        {/* Pause overlay with controls */}
        {phase === 'paused' && (
          <div style={{ margin: '0 16px 10px', background: 'rgba(10,12,20,0.9)', backdropFilter: 'blur(12px)', borderRadius: 16, padding: '14px 16px', border: `1px solid rgba(255,255,255,0.1)`, textAlign: 'center' }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.6)', marginBottom: 4 }}>Пауза</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff' }}>{reps} повторений засчитано</div>
          </div>
        )}

        {/* Buttons */}
        <div style={{ padding: '0 16px 40px', display: 'flex', gap: 10 }}>
          <button
            onClick={() => setPhase(phase === 'active' ? 'paused' : 'active')}
            style={{ flex: 1, padding: '14px', borderRadius: 14, border: `1.5px solid rgba(255,255,255,0.18)`, background: 'rgba(255,255,255,0.08)', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}
          >
            {phase === 'active' ? '⏸ Пауза' : '▶ Продолжить'}
          </button>
          <button
            onClick={() => { if (reps > 0) setPhase('summary'); else onBack() }}
            style={{ flex: 1, padding: '14px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}
          >
            Завершить
          </button>
        </div>
      </div>
    </div>
  )

  // ── CALIBRATION ───────────────────────────────────────────────────────────
  if (phase === 'calibration') return (
    <div style={{ height: '100%', position: 'relative', background: '#060810', overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 60%, #0e1828 0%, #060810 100%)' }} />
      <HumanSkeleton status="ok" />
      <div style={{ position: 'absolute', bottom: 100, left: 20, right: 20, zIndex: 10 }}>
        <div style={{ textAlign: 'center', marginBottom: 14 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 4 }}>Постой спокойно 1–2 секунды</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Калибровка положения тела</div>
        </div>
        <div style={{ height: 4, borderRadius: 99, background: 'rgba(255,255,255,0.1)', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${calibPct}%`, borderRadius: 99, background: C.acc, transition: 'width 0.06s linear' }} />
        </div>
        <div style={{ textAlign: 'center', marginTop: 8, fontSize: 12, color: C.acc, fontWeight: 700 }}>{calibPct}%</div>
      </div>
    </div>
  )

  // ── READY ─────────────────────────────────────────────────────────────────
  if (phase === 'ready') return (
    <div style={{ height: '100%', position: 'relative', background: '#060810', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 55%, #0e1828 0%, #060810 100%)' }} />
      <HumanSkeleton status="ok" />
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '52px 16px', background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', color: '#fff', fontSize: 16, cursor: 'pointer' }}>←</button>
        <span style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>Тренер по технике</span>
      </div>
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '20px 20px 48px', background: 'linear-gradient(to top, rgba(0,0,0,0.92), transparent)' }}>
        <div style={{ background: bc(C.ok, 0.12), border: `1.5px solid ${bc(C.ok, 0.4)}`, borderRadius: 16, padding: '14px 18px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: bc(C.ok, 0.2), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>✓</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.ok }}>Всё видно — можем начинать</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>Счёт начнётся с верхней точки</div>
          </div>
        </div>
        <button onClick={() => setPhase('active')} style={{ width: '100%', padding: '16px', borderRadius: 16, border: 'none', background: C.acc, color: '#060F00', fontSize: 16, fontWeight: 800, cursor: 'pointer' }}>
          Начать
        </button>
      </div>
    </div>
  )

  // ── QUALITY CHECK ─────────────────────────────────────────────────────────
  if (phase === 'quality-check') {
    const GATE_MSGS: Record<QualityState, { title: string; hint: string; icon: string; col: string }> = {
      loading:      { title: 'Проверяю кадр…', hint: 'Подожди секунду', icon: '⏳', col: 'rgba(255,255,255,0.5)' },
      'too-dark':   { title: 'Слишком темно', hint: 'Встань ближе к источнику света', icon: '💡', col: C.warn },
      'wrong-angle':{ title: 'Неверный ракурс', hint: 'Встань лицом к камере — силуэт показан спереди', icon: '🔄', col: C.warn },
      'body-partial':{ title: 'Тело не полностью в кадре', hint: 'Отойди немного дальше', icon: '⬆', col: C.warn },
      ok:           { title: 'Отлично, всё видно', hint: 'Начинаем калибровку', icon: '✓', col: C.ok },
    }
    const msg = GATE_MSGS[quality]

    return (
      <div style={{ height: '100%', position: 'relative', background: '#060810', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 55%, #0e1828 0%, #060810 100%)' }} />
        <HumanSkeleton ghost />
        {quality !== 'loading' && <HumanSkeleton status={quality === 'ok' ? 'ok' : 'warn'} />}

        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '52px 16px', background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', color: '#fff', fontSize: 16, cursor: 'pointer' }}>←</button>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>Тренер по технике</span>
        </div>

        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 20px 48px', background: 'linear-gradient(to top, rgba(0,0,0,0.9), transparent)' }}>
          <div style={{ background: 'rgba(10,12,20,0.85)', backdropFilter: 'blur(12px)', borderRadius: 16, padding: '14px 18px', border: `1.5px solid ${bc(msg.col, 0.35)}`, display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ fontSize: 22, flexShrink: 0 }}>{msg.icon}</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: msg.col }}>{msg.title}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>{msg.hint}</div>
            </div>
          </div>
          {quality === 'ok' && (
            <button onClick={() => setPhase('calibration')} style={{ width: '100%', padding: '15px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>
              Начать калибровку
            </button>
          )}
        </div>
      </div>
    )
  }

  // ── PREPARATION ───────────────────────────────────────────────────────────
  if (phase === 'preparation') return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 16px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={() => setPhase('launch')} />
        <div>
          <div style={{ fontSize: 11, color: C.fg3, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Тренер по технике</div>
          <h2 className="font-display" style={{ fontSize: 20, fontWeight: 800, color: C.fg, margin: 0 }}>{EXERCISE_NAME}</h2>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Angle guide */}
        <div style={{ background: '#0a0c10', borderRadius: 18, border: `1px solid ${C.bd2}`, padding: '16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 16 }}>
          <AngleGuide angle={EXERCISE_ANGLE} />
          <div>
            <div style={{ fontSize: 11, color: C.fg3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Ракурс</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Спереди</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', marginTop: 4, lineHeight: 1.5 }}>Встань лицом к камере — тело полностью в кадре</div>
          </div>
        </div>

        <div style={{ fontSize: 13, fontWeight: 700, color: C.fg2, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 10 }}>Подготовка</div>
        {[
          { icon: '📏', title: '1.5–2 м от камеры', sub: 'Чтобы тело помещалось целиком' },
          { icon: '📱', title: 'Камера на уровне пояса', sub: 'Зафикси телефон — не держи в руках' },
          { icon: '💡', title: 'Хорошее освещение', sub: 'Без яркого контрового света за спиной' },
          { icon: '👕', title: 'Контрастная одежда', sub: 'Не белый на белом фоне' },
        ].map((tip) => (
          <div key={tip.icon} style={{ display: 'flex', gap: 12, padding: '11px 14px', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, marginBottom: 8 }}>
            <span style={{ fontSize: 18, flexShrink: 0 }}>{tip.icon}</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: C.fg }}>{tip.title}</div>
              <div style={{ fontSize: 12, color: C.fg3, marginTop: 2 }}>{tip.sub}</div>
            </div>
          </div>
        ))}

        <div style={{ background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, padding: 12, fontSize: 11, color: C.fg3, lineHeight: 1.6, marginTop: 4, marginBottom: 20 }}>
          Камера используется только для проверки техники во время этой сессии.
        </div>
      </div>
      <div style={{ padding: '10px 20px 32px', flexShrink: 0 }}>
        <Btn label="Готово — включить камеру" onClick={() => setPhase('quality-check')} />
      </div>
    </div>
  )

  // ── LAUNCH SHEET ──────────────────────────────────────────────────────────
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 16px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <h2 className="font-display" style={{ fontSize: 24, fontWeight: 800, color: C.fg, margin: 0 }}>Тренер по технике</h2>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Hero visual */}
        <div style={{ height: 220, borderRadius: 20, background: 'radial-gradient(ellipse at 50% 60%, #0e1828 0%, #060810 100%)', border: `1px solid ${C.bd2}`, marginBottom: 20, position: 'relative', overflow: 'hidden' }}>
          <HumanSkeleton status="ok" />
          <div style={{ position: 'absolute', top: 14, left: 14, background: bc(C.acc, 0.15), border: `1px solid ${bc(C.acc, 0.4)}`, borderRadius: 99, padding: '5px 12px' }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: C.acc }}>Спереди</span>
          </div>
          <div style={{ position: 'absolute', bottom: 14, left: 0, right: 0, textAlign: 'center' }}>
            <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{EXERCISE_NAME}</span>
          </div>
        </div>

        <p style={{ fontSize: 15, color: C.fg2, lineHeight: 1.65, margin: '0 0 20px' }}>
          Покажем, как встать к камере, поможем считать повторения и подскажем основные ошибки.
        </p>

        {[
          { icon: '🔢', text: 'Автоматический счёт повторений' },
          { icon: '💬', text: 'Подсказки по технике в реальном времени' },
          { icon: '📊', text: 'Краткий итог после подхода' },
        ].map((f) => (
          <div key={f.icon} style={{ display: 'flex', gap: 12, padding: '10px 14px', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, marginBottom: 8 }}>
            <span style={{ fontSize: 18 }}>{f.icon}</span>
            <span style={{ fontSize: 13, color: C.fg2 }}>{f.text}</span>
          </div>
        ))}

        <div style={{ marginTop: 14, background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}`, padding: 12, fontSize: 11, color: C.fg3, lineHeight: 1.6 }}>
          Понадобится камера. Камера используется только для проверки техники во время сессии.
        </div>
        <div style={{ height: 20 }} />
      </div>
      <div style={{ padding: '10px 20px 32px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn label="Начать" onClick={() => setPhase('preparation')} />
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg2, padding: '10px 0' }}>Позже</button>
      </div>
    </div>
  )
}

// Alias for backward compat with wiring
const FormCheckScreen = TechCoachScreen

// ══════════════════════════════════════════════════════════════════════════════
// D6 — WORKOUT SUMMARY (expanded from WorkoutDone)
// ══════════════════════════════════════════════════════════════════════════════
const WorkoutSummaryScreen = ({ onHome, onFormCheck }: { onHome: () => void; onFormCheck: () => void }) => {
  const [difficulty, setDifficulty] = useState(3)
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '60px 20px 0' }}>
        {/* Hero */}
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
          <div style={{ width: 76, height: 76, borderRadius: '50%', background: bc(C.ok, 0.15), border: `2px solid ${C.ok}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34 }}>✓</div>
        </div>
        <h2 className="font-display" style={{ fontSize: 36, fontWeight: 900, color: C.fg, textAlign: 'center', margin: '0 0 4px', lineHeight: 1.1 }}>Тренировка завершена</h2>
        <p style={{ fontSize: 14, color: C.fg2, textAlign: 'center', margin: '0 0 24px' }}>Отличная работа, Иван</p>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {[['48', 'мин'], ['7', 'упр.'], ['18', 'подх.'], ['4 820', 'кг']].map(([val, lbl]) => (
            <div key={lbl} style={{ flex: 1, background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, padding: '12px 4px', textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: 20, fontWeight: 800, color: C.acc }}>{val}</div>
              <div style={{ fontSize: 10, color: C.fg2, marginTop: 2 }}>{lbl}</div>
            </div>
          ))}
        </div>

        {/* PR badge */}
        <div style={{ background: `linear-gradient(135deg, ${bc(C.acc, 0.1)}, ${bc(C.ok, 0.1)})`, borderRadius: 14, border: `1px solid ${bc(C.acc, 0.3)}`, padding: '12px 16px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 28 }}>🏆</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.acc }}>Личный рекорд!</div>
            <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>Тяга верхнего блока — 85 кг × 8 повт. (+5 кг)</div>
          </div>
        </div>

        {/* Difficulty */}
        <Card style={{ padding: 16, marginBottom: 12 }}>
          <Label style={{ marginBottom: 10, display: 'block' }}>Ощущение нагрузки</Label>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1,2,3,4,5].map((d) => (
              <button key={d} onClick={() => setDifficulty(d)} style={{ flex: 1, padding: '10px 0', borderRadius: 10, border: `1.5px solid ${difficulty >= d ? C.acc : C.bd2}`, background: difficulty >= d ? bc(C.acc, 0.12) : C.s3, color: difficulty >= d ? C.acc : C.fg3, fontSize: 16, cursor: 'pointer', transition: 'all 0.15s' }}>
                {['😴','😊','💪','🔥','💀'][d-1]}
              </button>
            ))}
          </div>
          <div style={{ marginTop: 8, fontSize: 12, color: C.fg2, textAlign: 'center' }}>
            {['Слишком легко','Комфортно','В меру тяжело','Тяжело','На пределе'][difficulty-1]}
          </div>
        </Card>

        {/* Form feedback */}
        <Card style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <Label>Техника выполнения</Label>
            <button onClick={onFormCheck} style={{ fontSize: 11, color: C.acc, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>Form Check →</button>
          </div>
          {[
            { icon: '✓', color: C.ok,   text: 'Тяга верхнего блока — стабильная спина' },
            { icon: '✓', color: C.ok,   text: 'Подтягивания — полная амплитуда' },
            { icon: '⚠', color: C.warn, text: 'Сгибания на бицепс — читинг в последних повторах' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 8 }}>
              <span style={{ color: item.color, fontWeight: 700, fontSize: 13, marginTop: 1 }}>{item.icon}</span>
              <span style={{ fontSize: 13, color: C.fg2, lineHeight: 1.4 }}>{item.text}</span>
            </div>
          ))}
        </Card>

        {/* Muscle recovery impact */}
        <Card style={{ padding: 16, marginBottom: 12 }}>
          <Label style={{ marginBottom: 10, display: 'block' }}>Нагрузка на мышцы</Label>
          {[
            { muscle: 'Широчайшие', load: 0.92 },
            { muscle: 'Бицепс',     load: 0.80 },
            { muscle: 'Трапеции',   load: 0.65 },
            { muscle: 'Предплечья', load: 0.45 },
          ].map((m) => (
            <div key={m.muscle} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: C.fg2 }}>{m.muscle}</span>
                <span style={{ fontSize: 12, color: m.load > 0.8 ? C.err : m.load > 0.6 ? C.warn : C.ok, fontWeight: 600 }}>
                  {m.load > 0.8 ? 'Высокая' : m.load > 0.6 ? 'Средняя' : 'Низкая'}
                </span>
              </div>
              <div style={{ height: 4, borderRadius: 99, background: C.s3, overflow: 'hidden' }}>
                <div style={{ width: `${m.load * 100}%`, height: '100%', borderRadius: 99, background: m.load > 0.8 ? C.err : m.load > 0.6 ? C.warn : C.ok }} />
              </div>
            </div>
          ))}
          <p style={{ fontSize: 12, color: C.fg3, margin: '8px 0 0', lineHeight: 1.5 }}>Широчайшие и бицепс — 48–72 ч восстановления.</p>
        </Card>

        {/* Next workout */}
        <div style={{ background: bc(C.acc, 0.08), borderRadius: 16, border: `1px solid ${bc(C.acc, 0.22)}`, padding: 16, marginBottom: 20 }}>
          <Label color={C.acc} style={{ marginBottom: 6, display: 'block' }}>Следующая тренировка</Label>
          <div className="font-display" style={{ fontSize: 22, fontWeight: 700, color: C.fg }}>Ноги · Среда</div>
          <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>6 упражнений · 52 минуты · Тренажёрный зал</div>
        </div>
        <div style={{ height: 16 }} />
      </div>
      <div style={{ padding: '12px 20px 32px', flexShrink: 0 }}>
        <Btn label="На главную" onClick={onHome} />
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// D8 — WORKOUTS SCREEN (Programs + Library)
// ══════════════════════════════════════════════════════════════════════════════
const PROGRAMS = [
  { title: 'Силовая база',      weeks: 8,  days: 4, level: 'Средний',  goal: 'Сила',     muscles: ['Всё тело'],                  color: '#7C3AED' },
  { title: 'Гипертрофия',       weeks: 10, days: 4, level: 'Средний',  goal: 'Мышцы',    muscles: ['Грудь', 'Спина', 'Ноги'],    color: '#2563EB' },
  { title: 'Старт в зале',      weeks: 6,  days: 3, level: 'Новичок',  goal: 'Форма',    muscles: ['Всё тело'],                  color: '#059669' },
  { title: 'Рельеф и выносл.',  weeks: 8,  days: 5, level: 'Средний',  goal: 'Похудение', muscles: ['Пресс', 'Кардио'],           color: '#D97706' },
  { title: 'Возврат после пер.', weeks: 4, days: 3, level: 'Любой',    goal: 'Возврат',  muscles: ['Всё тело'],                  color: '#DC2626' },
  { title: 'Плечи и руки',      weeks: 6,  days: 3, level: 'Средний',  goal: 'Мышцы',    muscles: ['Плечи', 'Руки'],             color: '#7C6AFF' },
]

const WorkoutsScreen = ({ onWorkoutStart }: { onWorkoutStart: () => void }) => {
  const [subTab, setSubTab] = useState<'programs' | 'library'>('programs')
  const [goalFilter, setGoalFilter] = useState('Все')
  const [showAI, setShowAI] = useState(false)

  const goals = ['Все', 'Сила', 'Мышцы', 'Похудение', 'Форма', 'Возврат']
  const filtered = goalFilter === 'Все' ? PROGRAMS : PROGRAMS.filter((p) => p.goal === goalFilter)

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg, position: 'relative' }}>
      {showAI && <AICoachPanel context="Силовая база · Спина и бицепс" onClose={() => setShowAI(false)} />}
      <div style={{ padding: '54px 20px 12px', flexShrink: 0 }}>
        <h1 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, margin: '0 0 12px', lineHeight: 1.1 }}>Тренировки</h1>
        <div style={{ display: 'flex', background: C.s2, borderRadius: 12, padding: 3, gap: 2, border: `1px solid ${C.bd}` }}>
          {(['programs', 'library'] as const).map((t) => (
            <button key={t} onClick={() => setSubTab(t)} style={{ flex: 1, padding: '9px', borderRadius: 9, border: 'none', cursor: 'pointer', background: subTab === t ? C.acc : 'transparent', color: subTab === t ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s' }}>
              {t === 'programs' ? 'Программы' : 'Библиотека'}
            </button>
          ))}
        </div>
      </div>

      {subTab === 'programs' && (
        <>
          {/* Current program */}
          <div style={{ padding: '0 20px 12px', flexShrink: 0 }}>
            <div style={{ background: `linear-gradient(140deg, ${C.s2}, ${bc(C.acc, 0.07)})`, borderRadius: 18, border: `1.5px solid ${bc(C.acc, 0.22)}`, padding: 16, position: 'relative', overflow: 'hidden' }}>
              <Label color={C.acc} style={{ marginBottom: 6, display: 'block' }}>Текущая программа</Label>
              <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, marginBottom: 6 }}>Силовая база</div>
              <div style={{ height: 4, borderRadius: 99, background: C.s3, overflow: 'hidden', marginBottom: 8 }}>
                <div style={{ width: '28%', height: '100%', borderRadius: 99, background: C.acc }} />
              </div>
              <div style={{ fontSize: 12, color: C.fg2 }}>Неделя 2 из 8 · 28%</div>
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button onClick={onWorkoutStart} style={{ flex: 1, padding: '12px', borderRadius: 12, border: 'none', background: C.acc, color: '#060F00', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
                  Спина и бицепс →
                </button>
                <button onClick={() => setShowAI(true)} style={{ padding: '12px 14px', borderRadius: 12, border: `1.5px solid ${bc(C.acc, 0.35)}`, background: bc(C.acc, 0.1), color: C.acc, fontSize: 14, cursor: 'pointer', fontWeight: 700 }}>
                  🤖
                </button>
              </div>
            </div>
          </div>
          {/* Filters */}
          <div style={{ padding: '0 20px 10px', flexShrink: 0 }}>
            <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4 }}>
              {goals.map((g) => (
                <button key={g} onClick={() => setGoalFilter(g)} style={{ padding: '6px 14px', borderRadius: 99, border: `1.5px solid ${goalFilter === g ? C.acc : C.bd2}`, background: goalFilter === g ? bc(C.acc, 0.12) : C.s2, color: goalFilter === g ? C.acc : C.fg2, fontSize: 12, fontWeight: 700, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap' }}>
                  {g}
                </button>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
            {filtered.map((p) => (
              <div key={p.title} style={{ background: C.s2, borderRadius: 18, border: `1px solid ${C.bd}`, overflow: 'hidden', marginBottom: 12 }}>
                <div style={{ height: 80, background: `linear-gradient(135deg, ${p.color}33, ${p.color}15)`, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                  <div style={{ position: 'absolute', top: 12, left: 14 }}>
                    <Chip label={p.level} color={`${p.color}25`} text={p.color} small />
                  </div>
                  <div style={{ position: 'absolute', top: 12, right: 14 }}>
                    <Chip label={p.goal} color={bc(C.acc, 0.12)} text={C.acc} small />
                  </div>
                  <span className="font-display" style={{ fontSize: 32, color: `${p.color}60` }}>▶</span>
                </div>
                <div style={{ padding: '12px 14px' }}>
                  <div className="font-display" style={{ fontSize: 18, fontWeight: 800, color: C.fg, marginBottom: 4 }}>{p.title}</div>
                  <div style={{ fontSize: 12, color: C.fg2, marginBottom: 8 }}>{p.weeks} нед. · {p.days} д/нед. · {p.muscles.join(', ')}</div>
                  <button onClick={onWorkoutStart} style={{ width: '100%', padding: '10px', borderRadius: 10, border: `1.5px solid ${C.bd2}`, background: 'transparent', color: C.fg, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                    Начать программу
                  </button>
                </div>
              </div>
            ))}
            <div style={{ height: 90 }} />
          </div>
        </>
      )}

      {subTab === 'library' && (
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
          {/* Search */}
          <div style={{ display: 'flex', alignItems: 'center', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd2}`, padding: '10px 14px', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 16, color: C.fg3 }}>🔍</span>
            <span style={{ fontSize: 14, color: C.fg3 }}>Поиск упражнений...</span>
          </div>
          {/* Category chips */}
          <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 12 }}>
            {['Все', 'Грудь', 'Спина', 'Ноги', 'Плечи', 'Руки', 'Пресс'].map((cat) => (
              <button key={cat} style={{ padding: '6px 14px', borderRadius: 99, border: `1.5px solid ${cat === 'Все' ? C.acc : C.bd2}`, background: cat === 'Все' ? bc(C.acc, 0.12) : C.s2, color: cat === 'Все' ? C.acc : C.fg2, fontSize: 12, fontWeight: 700, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap' }}>
                {cat}
              </button>
            ))}
          </div>
          {/* Exercise list */}
          {[
            { name: 'Тяга верхнего блока',   muscle: 'Спина',  level: 'Средний',  equip: 'Тренажёр', color: '#7C3AED' },
            { name: 'Жим штанги лёжа',        muscle: 'Грудь',  level: 'Средний',  equip: 'Штанга',   color: '#2563EB' },
            { name: 'Приседание со штангой',  muscle: 'Ноги',   level: 'Средний',  equip: 'Штанга',   color: '#059669' },
            { name: 'Подтягивания',           muscle: 'Спина',  level: 'Средний',  equip: 'Турник',   color: '#7C3AED' },
            { name: 'Жим гантелей сидя',      muscle: 'Плечи',  level: 'Начало',   equip: 'Гантели',  color: '#D97706' },
            { name: 'Сгибания на бицепс',     muscle: 'Руки',   level: 'Начало',   equip: 'Гантели',  color: '#DC2626' },
            { name: 'Планка',                  muscle: 'Пресс',  level: 'Начало',   equip: 'Без экип.', color: '#059669' },
          ].map((ex) => (
            <div key={ex.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: `1px solid ${C.bd}` }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: `${ex.color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <span style={{ fontSize: 20, color: ex.color }}>▶</span>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ex.name}</div>
                <div style={{ fontSize: 11, color: C.fg2, marginTop: 2 }}>{ex.muscle} · {ex.equip} · {ex.level}</div>
              </div>
              <span style={{ fontSize: 16, color: C.fg3 }}>›</span>
            </div>
          ))}
          <div style={{ height: 90 }} />
        </div>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// D8 — AI COACH (contextual panel)
// ══════════════════════════════════════════════════════════════════════════════
const AICoachPanel = ({ context, onClose }: { context: string; onClose: () => void }) => {
  const [input, setInput] = useState('')
  const CHIPS = ['Как делать правильно?', 'Какие мышцы работают?', 'Можно с травмой колена?', 'Сколько подходов?']
  const RESPONSE = {
    text: 'Для тяги верхнего блока ключевое — не тянуть плечами. Начни движение, опуская лопатки вниз-назад, затем сгибай локти. Это изолирует широчайшие.',
    reason: 'Твой уровень — Средний, и ты уже работаешь с этим упражнением 3 недели.',
    action: 'Попробуй паузу 1 с в нижней точке — усилит контракцию.',
  }

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', display: 'flex', flexDirection: 'column', zIndex: 20 }}>
      <div style={{ flex: 1 }} onClick={onClose} />
      <div style={{ background: C.s1, borderRadius: '24px 24px 0 0', padding: '20px 20px 0', maxHeight: '75%', display: 'flex', flexDirection: 'column' }}>
        <div style={{ width: 40, height: 4, borderRadius: 99, background: C.bd2, margin: '0 auto 16px' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: bc(C.acc, 0.15), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🤖</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.fg }}>AI Coach</div>
            <div style={{ fontSize: 11, color: C.fg3 }}>{context}</div>
          </div>
          <button onClick={onClose} style={{ marginLeft: 'auto', width: 32, height: 32, borderRadius: '50%', background: C.s3, border: 'none', cursor: 'pointer', color: C.fg2, fontSize: 16 }}>✕</button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 12 }}>
          {/* AI response */}
          <div style={{ background: C.s2, borderRadius: 16, border: `1px solid ${C.bd}`, padding: 16, marginBottom: 12 }}>
            <p style={{ fontSize: 14, color: C.fg, lineHeight: 1.6, margin: '0 0 10px' }}>{RESPONSE.text}</p>
            <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginBottom: 8 }}>
              <span style={{ fontSize: 11, color: C.fg3, fontWeight: 700, marginTop: 1, flexShrink: 0 }}>ПОЧЕМУ</span>
              <span style={{ fontSize: 12, color: C.fg2, lineHeight: 1.5 }}>{RESPONSE.reason}</span>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', padding: '10px 12px', background: bc(C.acc, 0.08), borderRadius: 10 }}>
              <span style={{ fontSize: 14 }}>💡</span>
              <span style={{ fontSize: 12, color: C.acc, lineHeight: 1.5 }}>{RESPONSE.action}</span>
            </div>
          </div>
          {/* Suggestion chips */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {CHIPS.map((c) => (
              <button key={c} style={{ padding: '7px 12px', borderRadius: 99, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 12, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' }}>{c}</button>
            ))}
          </div>
        </div>
        {/* Input */}
        <div style={{ display: 'flex', gap: 10, padding: '12px 0 32px', borderTop: `1px solid ${C.bd}` }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Спроси AI Coach..." style={{ flex: 1, background: C.s2, border: `1px solid ${C.bd2}`, borderRadius: 12, padding: '10px 14px', color: C.fg, fontSize: 14, outline: 'none' }} />
          <button style={{ width: 44, height: 44, borderRadius: 12, background: C.acc, border: 'none', cursor: 'pointer', fontSize: 18, color: '#060F00', flexShrink: 0 }}>↑</button>
        </div>
        <p style={{ fontSize: 11, color: C.fg3, textAlign: 'center', margin: '0 0 8px' }}>AI Coach не является медицинским специалистом</p>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// D8 — PROFILE SCREEN
// ══════════════════════════════════════════════════════════════════════════════
const ProfileScreen = ({ onPaywall }: { onPaywall: () => void }) => {
  const SECTIONS = [
    { title: 'Личные данные', icon: '👤', items: ['Имя, фото профиля', 'Год рождения', 'Рост и вес'] },
    { title: 'Цели',          icon: '🎯', items: ['Главная цель', 'Приоритетные мышцы', 'График тренировок'] },
    { title: 'Единицы',       icon: '📏', items: ['кг / фунты', 'см / дюймы'] },
    { title: 'Интеграции',    icon: '🔗', items: ['Health Connect', 'Носимые устройства'] },
    { title: 'Уведомления',   icon: '🔔', items: ['Напоминания о тренировках', 'Напоминания о фото'] },
    { title: 'Приватность',   icon: '🔒', items: ['Данные Form Check', 'Фото прогресса', 'Экспорт данных'] },
    { title: 'Помощь',        icon: '❓', items: ['FAQ', 'Связаться с поддержкой', 'Версия приложения'] },
  ]

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 16px', flexShrink: 0 }}>
        <h1 className="font-display" style={{ fontSize: 34, fontWeight: 800, color: C.fg, margin: 0 }}>Профиль</h1>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Avatar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 0 20px', borderBottom: `1px solid ${C.bd}`, marginBottom: 16 }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: bc(C.acc, 0.2), border: `2px solid ${C.acc}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.acc }}>И</span>
          </div>
          <div style={{ flex: 1 }}>
            <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg }}>Иван</div>
            <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>Средний уровень · 14 тренировок</div>
          </div>
          <button style={{ padding: '7px 12px', borderRadius: 10, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg2, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Изменить</button>
        </div>

        {/* Subscription CTA */}
        <button onClick={onPaywall} style={{ width: '100%', background: `linear-gradient(135deg, ${bc(C.acc, 0.12)}, ${bc('#7C6AFF', 0.12)})`, borderRadius: 16, border: `1.5px solid ${bc(C.acc, 0.3)}`, padding: '14px 16px', cursor: 'pointer', textAlign: 'left', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 24 }}>⭐</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: C.acc }}>Попробовать Premium</div>
            <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>Form Check · AI Coach · Расширенный прогресс</div>
          </div>
          <span style={{ fontSize: 16, color: C.acc }}>›</span>
        </button>

        {SECTIONS.map((section) => (
          <div key={section.title} style={{ marginBottom: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 0 8px' }}>
              <span style={{ fontSize: 16 }}>{section.icon}</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: C.fg2, textTransform: 'uppercase', letterSpacing: '0.07em' }}>{section.title}</span>
            </div>
            <div style={{ background: C.s2, borderRadius: 14, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
              {section.items.map((item, i) => (
                <div key={item} style={{ display: 'flex', alignItems: 'center', padding: '13px 16px', borderBottom: i < section.items.length - 1 ? `1px solid ${C.bd}` : 'none' }}>
                  <span style={{ flex: 1, fontSize: 14, color: C.fg }}>{item}</span>
                  <span style={{ fontSize: 16, color: C.fg3 }}>›</span>
                </div>
              ))}
            </div>
          </div>
        ))}

        <button style={{ width: '100%', marginTop: 16, padding: '14px', borderRadius: 14, border: `1.5px solid ${bc(C.err, 0.3)}`, background: 'transparent', color: C.err, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
          Выйти из аккаунта
        </button>
        <div style={{ height: 90 }} />
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// D8 — PAYWALL / SUBSCRIPTION
// ══════════════════════════════════════════════════════════════════════════════
const PaywallScreen = ({ onBack }: { onBack: () => void }) => {
  const [plan, setPlan] = useState<'monthly' | 'yearly'>('yearly')

  const FEATURES = [
    { label: 'Тренировки из библиотеки',    free: true,  premium: true  },
    { label: 'Сканер тренажёров',           free: true,  premium: true  },
    { label: 'Базовые программы',           free: '3',   premium: true  },
    { label: 'Form Check (камера)',          free: false, premium: true  },
    { label: 'AI Coach в реальном времени', free: false, premium: true  },
    { label: 'Все программы (18+)',         free: false, premium: true  },
    { label: 'Расширенный прогресс',        free: false, premium: true  },
    { label: 'Фото прогресса — сравнение',  free: '2',   premium: true  },
    { label: 'Health Connect / носимые',    free: false, premium: true  },
  ]

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      <div style={{ padding: '54px 20px 16px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
        <BackBtn onClick={onBack} />
        <h2 className="font-display" style={{ fontSize: 26, fontWeight: 800, color: C.fg, margin: 0 }}>Premium</h2>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {/* Hero */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>⭐</div>
          <h3 className="font-display" style={{ fontSize: 28, fontWeight: 900, color: C.fg, margin: '0 0 8px' }}>Полный доступ к AI-тренеру</h3>
          <p style={{ fontSize: 14, color: C.fg2, lineHeight: 1.6, margin: 0 }}>Form Check, AI Coach и расширенный прогресс без ограничений</p>
        </div>

        {/* Plan toggle */}
        <div style={{ display: 'flex', background: C.s2, borderRadius: 12, padding: 3, gap: 2, border: `1px solid ${C.bd}`, marginBottom: 16 }}>
          {(['monthly', 'yearly'] as const).map((p) => (
            <button key={p} onClick={() => setPlan(p)} style={{ flex: 1, padding: '10px', borderRadius: 9, border: 'none', cursor: 'pointer', background: plan === p ? C.acc : 'transparent', color: plan === p ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s', position: 'relative' }}>
              {p === 'monthly' ? 'Месяц' : 'Год'}
              {p === 'yearly' && plan === 'yearly' && <span style={{ position: 'absolute', top: -8, right: 4, background: C.ok, color: '#060F00', fontSize: 9, fontWeight: 800, padding: '2px 5px', borderRadius: 99 }}>-40%</span>}
            </button>
          ))}
        </div>

        {/* Price */}
        <div style={{ background: C.s2, borderRadius: 16, border: `1.5px solid ${bc(C.acc, 0.3)}`, padding: '16px 20px', marginBottom: 16, textAlign: 'center' }}>
          <div className="font-display" style={{ fontSize: 40, fontWeight: 900, color: C.acc }}>
            {plan === 'monthly' ? '599 ₽' : '299 ₽'}
          </div>
          <div style={{ fontSize: 13, color: C.fg2, marginTop: 4 }}>
            {plan === 'monthly' ? 'в месяц' : 'в месяц · 3 588 ₽/год'}
          </div>
          {plan === 'yearly' && <div style={{ fontSize: 12, color: C.ok, marginTop: 4, fontWeight: 600 }}>Сэкономишь 3 600 ₽ в год</div>}
        </div>

        {/* Features */}
        <Card style={{ padding: 16, marginBottom: 16 }}>
          <div style={{ display: 'flex', marginBottom: 10 }}>
            <div style={{ flex: 1 }} />
            <div style={{ width: 54, textAlign: 'center', fontSize: 11, fontWeight: 700, color: C.fg3 }}>Free</div>
            <div style={{ width: 64, textAlign: 'center', fontSize: 11, fontWeight: 700, color: C.acc }}>Premium</div>
          </div>
          {FEATURES.map((f) => (
            <div key={f.label} style={{ display: 'flex', alignItems: 'center', paddingBottom: 10, marginBottom: 10, borderBottom: `1px solid ${C.bd}` }}>
              <div style={{ flex: 1, fontSize: 12, color: C.fg2 }}>{f.label}</div>
              <div style={{ width: 54, textAlign: 'center', fontSize: 13 }}>
                {f.free === true ? <span style={{ color: C.ok }}>✓</span> : f.free === false ? <span style={{ color: C.fg3 }}>–</span> : <span style={{ fontSize: 11, color: C.fg3 }}>{f.free}</span>}
              </div>
              <div style={{ width: 64, textAlign: 'center', fontSize: 13 }}>
                {f.premium === true ? <span style={{ color: C.acc }}>✓</span> : <span style={{ color: C.fg3 }}>–</span>}
              </div>
            </div>
          ))}
        </Card>

        <div style={{ fontSize: 12, color: C.fg3, lineHeight: 1.6, marginBottom: 20, textAlign: 'center' }}>
          7-дневный бесплатный пробный период. Отменить можно в любой момент. Первое списание — {plan === 'monthly' ? '599 ₽' : '3 588 ₽'} через 7 дней.
        </div>
      </div>

      <div style={{ padding: '12px 20px 32px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn label="Начать 7 дней бесплатно" onClick={onBack} />
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg2, padding: '8px 0' }}>Восстановить покупку</button>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// D9 — SHARED STATES (empty / error / permission)
// ══════════════════════════════════════════════════════════════════════════════
const EmptyState = ({ icon, title, subtitle, cta, onCta }: { icon: string; title: string; subtitle: string; cta?: string; onCta?: () => void }) => (
  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 28px', textAlign: 'center' }}>
    <div style={{ fontSize: 48, marginBottom: 16 }}>{icon}</div>
    <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: '0 0 8px' }}>{title}</div>
    <p style={{ fontSize: 14, color: C.fg2, lineHeight: 1.6, margin: '0 0 24px', maxWidth: 280 }}>{subtitle}</p>
    {cta && onCta && <button onClick={onCta} style={{ padding: '13px 24px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>{cta}</button>}
  </div>
)

const ErrorState = ({ title, subtitle, onRetry }: { title: string; subtitle: string; onRetry?: () => void }) => (
  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 28px', textAlign: 'center' }}>
    <div style={{ width: 64, height: 64, borderRadius: '50%', background: bc(C.err, 0.12), border: `2px solid ${bc(C.err, 0.4)}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16, fontSize: 28 }}>⚠</div>
    <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: '0 0 8px' }}>{title}</div>
    <p style={{ fontSize: 14, color: C.fg2, lineHeight: 1.6, margin: '0 0 24px' }}>{subtitle}</p>
    {onRetry && <button onClick={onRetry} style={{ padding: '12px 24px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: C.s2, color: C.fg, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>Попробовать снова</button>}
  </div>
)

const PermissionState = ({ icon, title, subtitle, cta, note, onCta }: { icon: string; title: string; subtitle: string; cta: string; note?: string; onCta: () => void }) => (
  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 28px', textAlign: 'center' }}>
    <div style={{ width: 80, height: 80, borderRadius: 24, background: C.s2, border: `1.5px solid ${C.bd2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20, fontSize: 36 }}>{icon}</div>
    <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, margin: '0 0 8px' }}>{title}</div>
    <p style={{ fontSize: 14, color: C.fg2, lineHeight: 1.6, margin: '0 0 24px', maxWidth: 280 }}>{subtitle}</p>
    <button onClick={onCta} style={{ padding: '13px 28px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer', marginBottom: 12 }}>{cta}</button>
    {note && <p style={{ fontSize: 12, color: C.fg3, lineHeight: 1.5, maxWidth: 240 }}>{note}</p>}
  </div>
)

const StubScreen = ({ title, icon }: { title: string; icon: string }) => (
  <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: C.bg, padding: '0 32px' }}>
    <div style={{ fontSize: 48, marginBottom: 16 }}>{icon}</div>
    <h2 className="font-display" style={{ fontSize: 28, fontWeight: 700, color: C.fg, margin: '0 0 8px', textAlign: 'center' }}>{title}</h2>
    <p style={{ fontSize: 14, color: C.fg2, textAlign: 'center', lineHeight: 1.6 }}>Этот раздел будет разработан после утверждения текущего направления.</p>
    <div style={{ marginTop: 20 }}>
      <Chip label="В разработке" color={bc(C.warn, 0.12)} text={C.warn} />
    </div>
  </div>
)

// ══════════════════════════════════════════════════════════════════════════════
// VARIANTS COMPARISON SCREEN
// ══════════════════════════════════════════════════════════════════════════════
const VariantsScreen = ({ onBack }: { onBack: () => void }) => {
  const [active, setActive] = useState<'A' | 'B' | 'C'>('A')

  // Shared demo state
  const [year, setYear]           = useState(1990)
  const [heightCm, setHeightCm]   = useState(178)
  const [weightTenths, setWeightTenths]       = useState(955)
  const [targetTenths, setTargetTenths]       = useState(900)
  const [weightUnit, setWeightUnit] = useState<'кг' | 'lbs'>('кг')
  const [heightUnit, setHeightUnit] = useState<'см' | 'ft'>('см')

  const weightKg  = weightTenths / 10
  const targetKg  = targetTenths / 10

  // Unit-aware display helpers
  const fmtW = (kg: number) => weightUnit === 'кг' ? kg.toFixed(1) : (kg * 2.2046).toFixed(1)
  const fmtH = () => heightUnit === 'см' ? `${heightCm}` : `${Math.floor(heightCm / 30.48)}'${Math.round(((heightCm / 30.48) % 1) * 12)}"`

  // Small horizontal unit toggle pill
  const UnitPill = ({ opts, val, onChange }: { opts: string[]; val: string; onChange: (v: string) => void }) => (
    <div style={{ display: 'flex', background: C.s3, borderRadius: 10, padding: 3, border: `1px solid ${C.bd2}`, flexShrink: 0 }}>
      {opts.map(o => (
        <button key={o} onClick={() => onChange(o)} style={{ padding: '5px 13px', borderRadius: 7, border: 'none', cursor: 'pointer', background: val === o ? C.acc : 'transparent', color: val === o ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s', lineHeight: 1 }}>
          {o}
        </button>
      ))}
    </div>
  )

  // Section label row with optional unit toggle
  const SectionHeader = ({ label, toggle }: { label: string; toggle?: React.ReactNode }) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.1em' }}>{label}</div>
      {toggle}
    </div>
  )

  const variantMeta = {
    A: { label: 'Вертикальный скролл', desc: 'Все пикеры на одном длинном экране, прокрутка вниз' },
    B: { label: 'Карусель', desc: 'Один экран, свайп между пикерами' },
    C: { label: 'Компактный', desc: 'Год / Рост / Вес в трёх inline-пикерах без отдельных шагов' },
  }

  // ── Variant A — vertical scroll ───────────────────────────────────────────
  const VariantA = () => (
    <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px 32px' }}>

      {/* ── Year ── */}
      <div style={{ marginBottom: 28 }}>
        <SectionHeader label="Год рождения" />
        <div style={{ background: C.s2, borderRadius: 20, padding: '12px 0', border: `1px solid ${C.bd}` }}>
          <WheelYear value={year} onChange={setYear} />
          <div style={{ textAlign: 'center', fontSize: 14, color: C.fg2, paddingBottom: 8 }}>{2026 - year} лет</div>
        </div>
      </div>

      {/* ── Height ── */}
      <div style={{ marginBottom: 28 }}>
        <SectionHeader label="Рост" toggle={<UnitPill opts={['см', 'ft']} val={heightUnit} onChange={(v) => setHeightUnit(v as 'см' | 'ft')} />} />
        <div style={{ background: C.s2, borderRadius: 20, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <div style={{ flex: 1, padding: '20px 0 20px 24px' }}>
              <div className="font-display" style={{ fontSize: 72, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmtH()}</div>
              <div style={{ fontSize: 18, color: C.fg2, fontWeight: 600, marginTop: 4 }}>{heightUnit}</div>
            </div>
            <div style={{ width: 72, height: 220 }}>
              <VRuler valueCm={heightCm} minCm={100} maxCm={220} onChangeCm={setHeightCm} width={72} />
            </div>
          </div>
          {/* +/- stepper inside card */}
          <div style={{ display: 'flex', gap: 1, borderTop: `1px solid ${C.bd}` }}>
            <button onClick={() => setHeightCm(h => Math.max(100, h - 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 20, cursor: 'pointer', fontWeight: 700 }}>−</button>
            <div style={{ width: 1, background: C.bd }} />
            <button onClick={() => setHeightCm(h => Math.min(220, h + 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 20, cursor: 'pointer', fontWeight: 700 }}>+</button>
          </div>
        </div>
      </div>

      {/* ── Current weight ── */}
      <div style={{ marginBottom: 28 }}>
        <SectionHeader label="Текущий вес" toggle={<UnitPill opts={['кг', 'lbs']} val={weightUnit} onChange={(v) => setWeightUnit(v as 'кг' | 'lbs')} />} />
        <div style={{ background: C.s2, borderRadius: 20, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
          {/* Value row */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, padding: '20px 24px 4px' }}>
            <div>
              <div className="font-display" style={{ fontSize: 72, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmtW(weightKg)}</div>
              <div style={{ fontSize: 18, color: C.fg2, fontWeight: 600, marginTop: 4 }}>{weightUnit}</div>
            </div>
          </div>
          {/* Ruler */}
          <div style={{ padding: '8px 0 4px' }}>
            <HRuler valueTenths={weightTenths} minTenths={300} maxTenths={2000} onChangeTenths={setWeightTenths} />
          </div>
          {/* +/- stepper */}
          <div style={{ display: 'flex', gap: 1, borderTop: `1px solid ${C.bd}` }}>
            <button onClick={() => setWeightTenths(v => Math.max(300, v - 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 16, cursor: 'pointer', fontWeight: 700 }}>−0.1 {weightUnit}</button>
            <div style={{ width: 1, background: C.bd }} />
            <button onClick={() => setWeightTenths(v => Math.min(2000, v + 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 16, cursor: 'pointer', fontWeight: 700 }}>+0.1 {weightUnit}</button>
          </div>
        </div>
        {heightCm > 0 && (
          <div style={{ marginTop: 10 }}>
            <BMICard weightKg={weightKg} heightCm={heightCm} birthYear={year} />
          </div>
        )}
      </div>

      {/* ── Target weight ── */}
      <div style={{ marginBottom: 12 }}>
        <SectionHeader label="Желаемый вес" toggle={<UnitPill opts={['кг', 'lbs']} val={weightUnit} onChange={(v) => setWeightUnit(v as 'кг' | 'lbs')} />} />
        <div style={{ background: C.s2, borderRadius: 20, border: `1px solid ${C.bd}`, overflow: 'hidden' }}>
          {/* Values: target + current reference */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, padding: '20px 24px 4px' }}>
            <div>
              <div style={{ fontSize: 11, color: C.fg3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>Цель</div>
              <div className="font-display" style={{ fontSize: 68, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{fmtW(targetKg)}</div>
              <div style={{ fontSize: 16, color: C.fg2, fontWeight: 600, marginTop: 3 }}>{weightUnit}</div>
            </div>
            <div style={{ paddingBottom: 6 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 13, color: C.fg3 }}>◀</span>
                <span style={{ fontSize: 22, fontWeight: 700, color: C.fg2, fontFamily: "'Barlow Condensed', sans-serif" }}>{fmtW(weightKg)}</span>
                <span style={{ fontSize: 13, color: C.fg3 }}>{weightUnit}</span>
              </div>
              <div style={{ fontSize: 11, color: C.fg3, marginTop: 2 }}>сейчас</div>
            </div>
          </div>
          {/* Ruler with current weight as accent marker */}
          <div style={{ padding: '8px 0 4px' }}>
            <HRuler valueTenths={targetTenths} minTenths={300} maxTenths={2000} onChangeTenths={setTargetTenths} accentTenths={weightTenths} height={96} />
          </div>
          {/* +/- stepper */}
          <div style={{ display: 'flex', gap: 1, borderTop: `1px solid ${C.bd}` }}>
            <button onClick={() => setTargetTenths(v => Math.max(300, v - 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 16, cursor: 'pointer', fontWeight: 700 }}>−0.1 {weightUnit}</button>
            <div style={{ width: 1, background: C.bd }} />
            <button onClick={() => setTargetTenths(v => Math.min(2000, v + 1))} style={{ flex: 1, padding: '11px', background: 'transparent', border: 'none', color: C.fg2, fontSize: 16, cursor: 'pointer', fontWeight: 700 }}>+0.1 {weightUnit}</button>
          </div>
        </div>
        {/* Delta card */}
        <div style={{ marginTop: 10 }}>
          <DeltaCard currentKg={weightKg} targetKg={targetKg} heightCm={heightCm} />
        </div>
      </div>

      {/* CTA */}
      <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn label="Продолжить" onClick={() => {}} />
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg3, padding: '8px 0' }}>Не ставить цель по весу</button>
      </div>
    </div>
  )

  // ── Variant B — carousel / swiper ─────────────────────────────────────────
  const VariantB = () => {
    const [slide, setSlide] = useState(0)
    const slides = ['Год рождения', 'Рост', 'Вес']
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Slide tabs */}
        <div style={{ display: 'flex', gap: 6, padding: '0 20px 16px', flexShrink: 0 }}>
          {slides.map((s, i) => (
            <button key={s} onClick={() => setSlide(i)} style={{ flex: 1, padding: '8px 4px', borderRadius: 10, border: `1.5px solid ${slide === i ? C.acc : C.bd2}`, background: slide === i ? bc(C.acc, 0.1) : 'transparent', color: slide === i ? C.acc : C.fg2, fontSize: 11, fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {s}
            </button>
          ))}
        </div>
        {/* Slide content */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', padding: '0 20px' }}>
          {slide === 0 && (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ textAlign: 'center', marginBottom: 8 }}>
                <div className="font-display" style={{ fontSize: 22, fontWeight: 700, color: C.fg2 }}>{2026 - year} лет</div>
              </div>
              <WheelYear value={year} onChange={setYear} />
            </div>
          )}
          {slide === 1 && (
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <div className="font-display" style={{ fontSize: 80, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{heightCm}</div>
                <div style={{ fontSize: 20, color: C.fg2, fontWeight: 600, marginTop: 4 }}>см</div>
              </div>
              <div style={{ width: 72, alignSelf: 'stretch' }}>
                <VRuler valueCm={heightCm} minCm={100} maxCm={220} onChangeCm={setHeightCm} width={72} />
              </div>
            </div>
          )}
          {slide === 2 && (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 16 }}>
              <div style={{ textAlign: 'center' }}>
                <div className="font-display" style={{ fontSize: 80, fontWeight: 900, color: C.fg, lineHeight: 1 }}>{weightKg.toFixed(1)}</div>
                <div style={{ fontSize: 20, color: C.fg2, fontWeight: 600, marginTop: 4 }}>кг</div>
              </div>
              <HRuler valueTenths={weightTenths} minTenths={300} maxTenths={2000} onChangeTenths={setWeightTenths} />
              {heightCm > 0 && <BMICard weightKg={weightKg} heightCm={heightCm} birthYear={year} />}
            </div>
          )}
        </div>
        {/* Prev / Next */}
        <div style={{ padding: '12px 20px 24px', display: 'flex', gap: 10, flexShrink: 0 }}>
          {slide > 0 && <button onClick={() => setSlide(slide - 1)} style={{ flex: 1, padding: '13px', borderRadius: 14, border: `1.5px solid ${C.bd2}`, background: 'transparent', color: C.fg2, fontSize: 15, fontWeight: 600, cursor: 'pointer' }}>← Назад</button>}
          {slide < slides.length - 1
            ? <button onClick={() => setSlide(slide + 1)} style={{ flex: 2, padding: '13px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>Далее →</button>
            : <button onClick={() => {}} style={{ flex: 2, padding: '13px', borderRadius: 14, border: 'none', background: C.acc, color: '#060F00', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>Продолжить</button>
          }
        </div>
      </div>
    )
  }

  // ── Variant C — compact inline ─────────────────────────────────────────────
  const VariantC = () => {
    const [expanded, setExpanded] = useState<'year' | 'height' | 'weight' | null>('year')
    const rows: { id: 'year' | 'height' | 'weight'; label: string; value: string }[] = [
      { id: 'year', label: 'Год рождения', value: `${year} · ${2026 - year} лет` },
      { id: 'height', label: 'Рост', value: `${heightCm} см` },
      { id: 'weight', label: 'Вес', value: `${weightKg.toFixed(1)} кг` },
    ]
    return (
      <div style={{ flex: 1, padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10, overflowY: 'auto' }}>
        {rows.map((row) => (
          <div key={row.id} style={{ background: C.s2, borderRadius: 18, border: `1.5px solid ${expanded === row.id ? bc(C.acc, 0.35) : C.bd}`, overflow: 'hidden', transition: 'border-color 0.15s' }}>
            {/* Header row */}
            <button onClick={() => setExpanded(expanded === row.id ? null : row.id)} style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: expanded === row.id ? C.acc : C.fg3, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 3 }}>{row.label}</div>
                <div className="font-display" style={{ fontSize: 28, fontWeight: 800, color: C.fg, lineHeight: 1 }}>{row.value}</div>
              </div>
              <span style={{ color: expanded === row.id ? C.acc : C.fg3, fontSize: 18 }}>{expanded === row.id ? '▲' : '▼'}</span>
            </button>
            {/* Expanded picker */}
            {expanded === row.id && (
              <div style={{ borderTop: `1px solid ${C.bd}`, padding: '8px 0' }}>
                {row.id === 'year' && (
                  <>
                    <WheelYear value={year} onChange={setYear} />
                    <div style={{ textAlign: 'center', fontSize: 13, color: C.fg2, paddingBottom: 8 }}>{2026 - year} лет</div>
                  </>
                )}
                {row.id === 'height' && (
                  <div style={{ display: 'flex', alignItems: 'center', padding: '0 16px 12px' }}>
                    <div style={{ flex: 1 }}>
                      <div className="font-display" style={{ fontSize: 60, fontWeight: 900, color: C.fg }}>{heightCm}</div>
                      <div style={{ fontSize: 16, color: C.fg2, fontWeight: 600 }}>см</div>
                    </div>
                    <div style={{ width: 64, height: 200 }}>
                      <VRuler valueCm={heightCm} minCm={100} maxCm={220} onChangeCm={setHeightCm} width={64} />
                    </div>
                  </div>
                )}
                {row.id === 'weight' && (
                  <div style={{ padding: '0 0 12px' }}>
                    <div style={{ textAlign: 'center', marginBottom: 8 }}>
                      <div className="font-display" style={{ fontSize: 60, fontWeight: 900, color: C.fg }}>{weightKg.toFixed(1)}</div>
                      <div style={{ fontSize: 16, color: C.fg2, fontWeight: 600 }}>кг</div>
                    </div>
                    <HRuler valueTenths={weightTenths} minTenths={300} maxTenths={2000} onChangeTenths={setWeightTenths} height={70} />
                    {heightCm > 0 && (
                      <div style={{ padding: '12px 16px 0' }}>
                        <BMICard weightKg={weightKg} heightCm={heightCm} birthYear={year} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        <div style={{ paddingTop: 8, paddingBottom: 24 }}>
          <Btn label="Продолжить" onClick={() => {}} />
          <button style={{ display: 'block', width: '100%', marginTop: 10, background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: C.fg3 }}>Пропустить</button>
        </div>
      </div>
    )
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: C.bg }}>
      {/* Header */}
      <div style={{ padding: '52px 20px 16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: '50%', background: C.s2, border: `1px solid ${C.bd2}`, color: C.fg2, fontSize: 16, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>←</button>
          <div>
            <div className="font-display" style={{ fontSize: 22, fontWeight: 800, color: C.fg, lineHeight: 1 }}>Body Metrics</div>
            <div style={{ fontSize: 12, color: C.fg2, marginTop: 2 }}>3 варианта компоновки</div>
          </div>
        </div>
        {/* Variant tabs */}
        <div style={{ display: 'flex', background: C.s2, borderRadius: 14, padding: 4, gap: 2, border: `1px solid ${C.bd}` }}>
          {(['A', 'B', 'C'] as const).map((v) => (
            <button key={v} onClick={() => setActive(v)} style={{ flex: 1, padding: '10px 4px', borderRadius: 10, border: 'none', cursor: 'pointer', background: active === v ? C.acc : 'transparent', color: active === v ? '#060F00' : C.fg2, fontSize: 13, fontWeight: 700, transition: 'all 0.15s', lineHeight: 1.2 }}>
              {v}
              <div style={{ fontSize: 9, fontWeight: 600, opacity: 0.75, marginTop: 2 }}>{variantMeta[v].label.split(' ')[0]}</div>
            </button>
          ))}
        </div>
        {/* Description */}
        <div style={{ marginTop: 10, padding: '10px 14px', background: C.s2, borderRadius: 12, border: `1px solid ${C.bd}` }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.acc, marginBottom: 3 }}>Вариант {active}</div>
          <div style={{ fontSize: 13, color: C.fg2, lineHeight: 1.5 }}>{variantMeta[active].desc}</div>
        </div>
      </div>

      {/* Content area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {active === 'A' && <VariantA />}
        {active === 'B' && <VariantB />}
        {active === 'C' && <VariantC />}
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// ROOT APP
// ══════════════════════════════════════════════════════════════════════════════
export default function App() {
  const [screen, setScreen] = useState<Screen>('research')
  const [activeTab, setActiveTab] = useState<Tab>('home')

  const goHome = () => { setScreen('home'); setActiveTab('home') }
  const goScan = () => { setScreen('scan'); setActiveTab('scan') }

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab)
    if (tab === 'scan') { setScreen('scan'); return }
    if (tab === 'home') { setScreen('home'); return }
    setScreen('home')
    setActiveTab(tab)
  }

  const showNav = screen === 'home' || (activeTab !== 'scan')

  return (
    <div style={{ width: '100%', height: '100vh', background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      {/* Phone shell */}
      <div style={{ width: '100%', maxWidth: 430, height: '100%', maxHeight: 932, position: 'relative', background: C.bg, overflow: 'hidden', boxShadow: '0 0 80px rgba(0,0,0,0.8)' }}>
        {screen === 'variants' && <VariantsScreen onBack={() => setScreen('research')} />}
        {screen === 'research' && <ResearchScreen onStart={() => setScreen('onboarding')} onVariants={() => setScreen('variants')} />}
        {screen === 'onboarding' && <OnboardingFlow onComplete={goHome} />}
        {screen === 'home' && (
          <div style={{ height: '100%', position: 'relative' }}>
            {activeTab === 'home' && <HomeScreen onScan={goScan} onWorkoutStart={() => setScreen('workout-player')} onPhotoCompare={() => setActiveTab('progress')} />}
            {activeTab === 'workouts' && <WorkoutsScreen onWorkoutStart={() => setScreen('workout-player')} />}
            {activeTab === 'progress' && <ProgressScreen />}
            {activeTab === 'profile' && <ProfileScreen onPaywall={() => setScreen('paywall')} />}
            <BottomNav active={activeTab} onTabChange={handleTabChange} />
          </div>
        )}
        {screen === 'scan' && <ScanScreen onEquipment={() => setScreen('equipment')} onTabChange={handleTabChange} />}
        {screen === 'equipment' && <EquipmentScreen onBack={() => setScreen('scan')} onWorkout={() => setScreen('workout-player')} onExercise={() => setScreen('exercise')} />}
        {screen === 'exercise' && <ExerciseScreen onBack={() => setScreen('equipment')} onWorkout={() => setScreen('workout-player')} onTechCoach={() => setScreen('form-check')} />}
        {screen === 'workout-player' && <WorkoutPlayer onBack={goHome} onDone={() => setScreen('workout-done')} onFormCheck={() => setScreen('form-check')} />}
        {screen === 'workout-done' && <WorkoutSummaryScreen onHome={goHome} onFormCheck={() => setScreen('form-check')} />}
        {screen === 'form-check' && <FormCheckScreen onBack={() => setScreen('workout-done')} onDone={() => setScreen('workout-done')} />}
        {screen === 'paywall' && <PaywallScreen onBack={() => { setScreen('home'); setActiveTab('profile') }} />}
      </div>
    </div>
  )
}
