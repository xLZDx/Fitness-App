Library
/
FIGMA_FULL_APP_REFACTOR_PROMPT_v1.0.md


FITNESS APP — FULL FIGMA REFACTOR PROMPT v1.0
Ты — Lead Product Designer, Senior Mobile UX/UI Designer и Design Systems
Architect с опытом в fitness, health, workout tracking, computer vision,
on-device ML и AI-assisted mobile products.

Нужно провести полный UX/UI-рефактор существующего Fitness App для Android и
iOS. Это не новый продукт с нуля и не запрос на создание красивых отдельных
экранов без связи. Приложение уже существует и содержит работающие функции.
Нужно сохранить продуктовую логику, устранить слабую иерархию стандартного
плиточного интерфейса и собрать целостный современный пользовательский опыт.

Используй приложенные скриншоты текущего приложения, референсы и видео как
материал для исследования. Не копируй чужие приложения один в один. Заимствуй
только доказанно полезные UX-паттерны, адаптируй их под реальные возможности
Fitness App и явно фиксируй, что было принято, изменено или отклонено.

1. Контекст продукта
Fitness App — персональный AI-помощник для тренировок в зале, дома и на улице.

Основные возможности продукта:

Каталог из 1 887 уникальных упражнений.

Лицензированные анатомические анимации упражнений высокого качества.

Техника выполнения и пошаговые инструкции.

Персональные рекомендации по цели, опыту, оборудованию, истории и
ограничениям.

Контекстный AI-тренер.

Распознавание тренажёров камерой.

Страница распознанного оборудования с подходящими упражнениями.

Проверка техники камерой и pose detection.

Персональные тренировочные планы.

Журнал веса, повторений и подходов.

Автоматический таймер отдыха.

История тренировок и прогресс.

Оценка нагрузки и восстановления мышц.

Injury-aware filtering.

Голосовое сопровождение.

Health Connect и носимые устройства.

Фото прогресса и визуальное сравнение снимков.

Светлая и тёмная темы.

Главный продуктовый цикл:

Пользователь приходит в зал → видит незнакомый тренажёр → сканирует его →
получает релевантные упражнения → смотрит технику и анатомическую анимацию →
выполняет подходы → при необходимости включает Form Check → сохраняет
результат → видит прогресс и следующую рекомендацию.

Приложение должно восприниматься не как каталог карточек, а как персональный
AI-помощник непосредственно во время тренировки.

2. Главные проблемы текущего интерфейса
Проведи design audit и визуально покажи Before / After для следующих проблем:

Все функции представлены одинаковыми плитками — нет иерархии.

Главный экран не отвечает, что делать сейчас.

Второстепенные блоки могут быть визуально сильнее тренировки.

Scanner не ощущается главным уникальным преимуществом.

Списки упражнений используют мелкие карточки и слабую media-подачу.

Progress показывает пустые одинаковые tiles без полезной интерпретации.

AI может выглядеть как generic chat, а не контекстный тренер.

Ввод возраста, роста и веса через обычные поля противоречит premium UX.

Workout logging может быть слишком плотным и техническим.

Empty, loading, error и permission states не являются частью единой системы.

Нет цельного перехода от сканирования к упражнению, тренировке и прогрессу.

3. Что взять из референсов
Принять и адаптировать:

один вопрос на один экран;

явный progress onboarding;

wheel/ruler pickers для возраста, роста и веса;

анатомическую карту мышц;

визуальный выбор целей и ограничений;

preview персонального плана до регистрации или оплаты;

media-first карточки;

hero-блок «Сегодня»;

удобный set logger;

автоматический rest timer;

компактные списки программ;

контекстный AI Coach;

визуальный progress comparison;

before/after side-by-side и slider;

мягкие contextual reminders.

Отклонить:

countdown timers продаж;

scratch cards и искусственные скидки;

paywall до ценности;

ложную срочность;

неподтверждённые before/after claims;

ложные точные сроки достижения цели;

BMI как диагноз;

body score и beauty score;

generic AI chat без контекста;

рекламу внутри core flows;

одинаковые плитки для всех функций;

автоматическую публикацию чувствительных фото;

ложную AI-точность.

4. Основные UX-принципы
Каждый главный экран должен отвечать минимум на один вопрос:

Что мне делать сейчас?

Почему это рекомендовано мне?

Как выполнить действие правильно?

Как быстро сохранить результат?

Как изменился мой прогресс?

Что делать следующим?

Используй progressive disclosure:

Главное действие.

Краткая причина или результат.

Дополнительные детали по запросу.

Требования:

одно доминирующее primary action на экран;

максимум три крупных смысловых блока до первого scroll;

важные controls доступны одной рукой;

во время активной тренировки вторичный контент скрывается;

не использовать grid как универсальное решение;

не показывать неподтверждённые метрики;

не смешивать health guidance с медицинской диагностикой;

не использовать цвет как единственный сигнал.

5. Визуальное направление
Сохрани и развивай выбранное направление:

dark premium foundation;

lime accent для primary actions;

крупная выразительная типографика;

media-first композиция;

глубокие нейтральные surfaces;

ограниченные градиенты;

мягкая глубина;

округлые поверхности;

функциональные анимации;

минимум визуального шума.

Создай полноценную light-theme adaptation, а не простую инверсию.

Glassmorphism использовать только:

camera overlays;

floating controls;

modal sheets;

временные status overlays.

Не использовать blur на каждом scrolling card.

6. Information Architecture
Основная нижняя навигация:

Home

Scan

Workouts

Progress

Profile

Вложенные разделы:

Home
Today workout

Continue workout

Quick Scan

Recovery snapshot

Weekly progress

Milestones

Progress photo comparison card при наличии данных

Scan
Camera

Recognition states

Top alternatives

Unknown equipment

Scan history

Saved machine cards

Workouts
Current program

Calendar

Workout library

Exercise library

Equipment library

Saved workouts

Active workout

Progress
Summary

Strength progression

Volume

Consistency

Muscle load and recovery

Measurements

Progress Photos

Achievements

History

Profile
Personal data

Goals

Units

Integrations

Notifications

Privacy

Subscription

Help

Scanner должен быть наиболее заметной уникальной функцией, но Today Workout
остаётся главным действием Home.

7. Полный onboarding flow
Создай короткую обязательную часть и optional personalization.

7.1 Value Proposition
Заголовок:
«Твой AI-помощник в тренажёрном зале»

Подзаголовок:
«Распознавай тренажёры, получай персональные упражнения и проверяй технику
камерой».

Actions:

«Настроить мой план»

«Продолжить без регистрации»

«Войти»

7.2 Главная цель
Single select:

Набрать мышцы

Стать сильнее

Снизить вес

Улучшить форму

Повысить выносливость

Вернуться после перерыва

7.3 Уровень
Начинаю впервые

Новичок

Средний

Опытный

Каждый вариант имеет понятное описание.

7.4 Место тренировок
Тренажёрный зал

Дом

Улица

Смешанный режим

7.5 Оборудование
Multi-select:

Полный зал

Отдельные тренажёры

Гантели

Штанга

Гири

Резинки

Собственный вес

Не знаю названий — буду сканировать камерой

7.6 График
дней в неделю;

длительность тренировки;

предпочтительные дни.

Не запрашивать notification permission здесь.

7.7 Ограничения
Интерактивная модель тела:

плечо;

локоть;

запястье;

верх спины;

поясница;

тазобедренный сустав;

колено;

голеностоп;

ограничений нет.

Текст:
«Используем это, чтобы исключить потенциально неподходящие упражнения. Это не
медицинская диагностика».

7.8 Приоритетные зоны
Интерактивная анатомическая модель, multi-select:

грудь;

спина;

плечи;

руки;

пресс;

ягодицы;

ноги;

всё тело.

Экран optional.

7.9 Основное препятствие
Не знаю, что делать

Не понимаю тренажёры

Сомневаюсь в технике

Не хватает времени

Трудно сохранять регулярность

Есть дискомфорт или ограничения

Ничего из перечисленного

7.10 Год рождения
Вертикальный wheel picker:

selected year крупно;

соседние значения с меньшей opacity;

haptic feedback;

direct input;

кнопки accessibility;

возможность пропустить.

Хранить год рождения, возраст рассчитывать.

7.11 Рост
Ruler picker:

cm/ft;

шаг 1 см;

major ticks;

fixed center indicator;

direct input;

haptic feedback;

− / + controls;

optional.

7.12 Текущий вес
Horizontal ruler picker:

kg/lbs;

шаг 0,1 кг;

fixed indicator;

direct input;

haptic feedback;

optional.

Для взрослых при наличии роста и возраста показывать нейтральную справочную
карточку:

BMI;

ориентировочный диапазон для роста;

разница до ближайшей границы;

пояснение, что BMI не учитывает состав тела и мышечную массу.

Для пользователей младше 20 лет не показывать взрослую BMI-категорию.

Запрещённые формулировки:

неправильный вес;

обязан похудеть;

страдаешь ожирением;

плохая форма.

7.13 Целевой вес
Ruler picker с маркерами current/target.

Показывать:

текущий вес;

целевой вес;

delta kg;

delta percent от текущего веса.

Формула:
(target - current) / current × 100.

Не обещать срок результата. Целевой вес optional.

7.14 Health Connect
Отдельный optional screen:

шаги;

сон;

активность;

восстановление.

Permission только после CTA «Подключить».

7.15 Generating
Показывать только реально введённые параметры.
Не использовать ложный progress и ложные обещания.

7.16 Plan Preview
До аккаунта и paywall показать:

цель;

тренировок в неделю;

длительность;

место;

приоритетные мышцы;

первую тренировку;

реальные exercise posters.

7.17 Account
После preview:

Google

Apple

Email

Продолжить без аккаунта

7.18 Notifications
Contextual prompt после выбора конкретного дня и времени.

8. Home
Перестрой Home вокруг следующего действия.

Порядок:

Greeting.

Program progress.

Hero Today Workout.

Start / Continue CTA.

Quick Scan card.

Recovery snapshot.

Weekly calendar and stats.

Last achievement.

Progress photo comparison card при наличии минимум двух снимков.

Hero пример:

«Сегодня — Спина и бицепс»
7 упражнений · 48 минут
«Начать тренировку»

Quick Scan должен быть вторым по визуальному приоритету после hero.

Не показывать пустой progress-photo блок на Home.

Horizontal recovery list должен иметь scroll affordance и не обрезать
последний item.

9. Scanner
Fullscreen camera flow.

Состояния:

permission;

ready;

targeting;

capturing;

analyzing;

high-confidence result;

Top-3 alternatives;

unknown equipment;

low light;

no equipment in frame;

timeout;

offline fallback;

error;

history.

UI:

corner brackets;

sweep line;

glass instruction pill;

flash;

capture;

cancel;

retry;

history.

Результат открывать bottom sheet:

название;

назначение;

мышцы;

количество упражнений;

suitability;

CTA «Открыть тренажёр»;

alternatives;

«Это другой тренажёр».

Unknown equipment:

фото пользователя;

предполагаемое название;

описание;

uses;

«Контент готовится»;

сохранить карточку;

не подставлять ближайший неправильный объект.

10. Equipment Page
Использовать hero poster связанного лицензированного упражнения.
Не использовать внешние stock images.

Структура:

cinematic hero;

name/category;

purpose;

muscles;

suitability badge;

safety note;

featured recommended exercise;

full exercise list;

AI Coach;

Add to workout.

Первое рекомендуемое упражнение визуально сильнее остальных.

11. Exercise Page
Media-first layout:

anatomical animation;

title;

primary/secondary muscles;

level;

equipment;

why recommended;

3 key technique steps;

common mistakes;

restrictions;

history;

AI Coach;

Form Check;

Start Exercise.

Полные инструкции раскрываются по запросу.

12. Workout Player
Immersive active mode:

large media;

exercise number;

set counter;

total time;

previous performance;

weight input;

reps input;

optional RPE;

notes;

Form Check;

replace/skip;

guarded finish.

Primary CTA:
«Завершить подход».

После сохранения:

haptic;

confirmation;

Undo;

automatic rest timer.

Set history открывается bottom sheet, а не занимает весь экран.

13. Rest Timer
Overlay или dedicated state:

circular countdown;

next target;

«Готов раньше»;

+30 секунд;

pause;

notification/haptic when complete.

14. Form Check
Состояния:

exercise selection;

angle selection;

permission;

initialization;

body not visible;

wrong angle;

ready;

active;

cue;

cannot evaluate;

paused;

completed;

summary.

UI:

live camera;

skeleton overlay;

segment highlights;

in-frame indicator;

rep counter;

current cue;

confidence;

pause/finish.

Не показывать form score, если visibility gate не пройден.
Не показывать internal rule IDs.

15. Workout Summary
Показывать:

duration;

exercises;

sets;

volume;

personal records;

perceived difficulty;

form highlights;

recovery impact;

next workout.

Не превращать summary в бессмысленную gamification.

16. Progress
Структура:

Summary.

Consistency.

Volume.

Key exercise progress.

Goal progress.

Muscle load and recovery.

Measurements.

Progress Photos.

Achievements.

History.

Recovery labels:

высокая;

средняя;

низкая;

недостаточно данных.

Каждый график должен отвечать на конкретный вопрос.

17. Progress Photos
Основной путь:
Progress → Фото прогресса → Gallery → Compare → Export.

Не размещать как основную функцию в Profile и не включать в onboarding.

17.1 Empty State
объяснение пользы;

CTA «Добавить первое фото»;

privacy note.

17.2 Privacy Explanation
Перед первым сохранением:

фото приватны;

не публикуются автоматически;

пользователь контролирует export;

не обещать storage policy, пока она не утверждена.

17.3 Capture
angle: front/side/back/free;

silhouette guide;

fullscreen camera;

grid;

timer 3/5/10;

flash;

switch camera;

preview;

retake/save;

optional metadata: date, weight, note, milestone.

17.4 Gallery
Основной вид — timeline:

thumbnail;

date;

angle;

optional weight;

note/milestone;

filter;

multi-select;

edit/delete/compare.

17.5 Compare
Два режима:

A. Side by side.
B. Interactive slider.

Controls:

swap;

select other photos;

hide weight;

hide date;

fit/fill;

reset.

Manual alignment:

zoom;

x/y offset;

rotation;

reset.

Не использовать body morphing.

17.6 Export
Preview before share:

hide weight/date;

optional face blur;

watermark;

background;

save/share.

По умолчанию вес скрыт.

17.7 Home Card
Показывать только при наличии минимум двух совместимых фото.
Не размещать выше workout и scanner.

17.8 Reminder
После первого снимка предложить 2/4/8 недель или без напоминания.

Запрещено:

body score;

fat percentage from photo;

attractiveness score;

medical conclusions;

automatic posting;

fake AI analysis.

18. Workout Library and Programs
Фильтры:

goal;

level;

location;

equipment;

duration;

muscles;

limitations;

return after break;

short workouts.

Не использовать Men/Women как главную классификацию.

Program card:

poster;

title;

weeks;

days/week;

duration;

level;

equipment;

goal;

honest suitability label.

19. AI Coach
AI открывается в контексте:

equipment;

exercise;

workout;

summary;

recovery;

plan.

Ответ:

Short answer.

Reason.

Personal context.

Practical action.

Expandable details.

Использовать suggestion chips.
Не позиционировать AI как врача.

20. Profile, Settings and Subscription
Profile:

personal data;

goals;

units;

integrations;

notifications;

privacy;

subscription;

help.

Paywall только после preview или доказанной ценности.

Показывать:

free/premium comparison;

monthly/yearly prices;

trial;

billing date;

cancellation terms;

restore purchase.

Не использовать fake countdown или fake discount.

21. Design System
Создай Figma Variables и semantic tokens.

Colors:

backgroundPrimary

backgroundSecondary

surfacePrimary

surfaceElevated

surfaceInteractive

textPrimary

textSecondary

textDisabled

accentPrimary

accentSecondary

success

warning

danger

outline

cameraOverlay

poseCorrect

poseWarning

poseError

Typography:

Display

H1

H2

H3

Title

Body

Body Small

Label

Caption

Numeric Large

Numeric Medium

Spacing:
4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48

Radius:
8 / 12 / 16 / 20 / 24 / Full

Core components:

buttons;

icon buttons;

navigation;

top bars;

choice cards;

chips;

recommendation hero;

media cards;

BodyMetricPicker;

set logger;

rest timer;

camera overlay;

recognition sheet;

AI insight;

progress cards;

progress-photo timeline;

compare slider;

empty/loading/error/permission states.

Для каждого компонента:

default;

pressed;

focused;

selected;

disabled;

loading;

error;

success.

22. Accessibility
Обязательно:

touch targets 44–48 px minimum;

WCAG AA contrast;

Dynamic Type;

text scale 1.0 / 1.3 / 1.6 / 2.0;

screen-reader order;

focus states;

no color-only meaning;

reduced motion;

long Russian strings;

one-hand use;

drag alternatives;

safe areas.

23. Android and iOS Adaptation
Android:

Material 3 behaviour;

predictive back;

edge-to-edge;

permissions;

standard bottom sheets.

IOS:

safe areas;

swipe back;

native modal behaviour;

Dynamic Type;

permission patterns.

Один brand system, не два разных продукта.

24. Motion
Использовать:

150–250 ms controls;

250–400 ms transitions;

fade-through;

shared-axis;

bottom sheet transitions;

scan result animation;

set saved feedback;

rest countdown;

skeleton-to-content.

Учитывать reduced motion.

25. Required States
Для каждого feature подготовить:

loading;

empty;

partial data;

stale data;

retryable error;

terminal error;

offline;

permission denied;

permission permanently denied;

unavailable hardware;

interrupted flow.

26. Figma File Structure
00 — Cover
01 — Research & Reference Analysis
02 — Current UI Audit
03 — UX Principles
04 — Information Architecture
05 — User Flows
06 — Moodboards
07 — Visual Directions
08 — Final Design System
09 — Components
10 — Onboarding
11 — Body Metrics
12 — Home
13 — Scanner
14 — Equipment
15 — Exercise
16 — Workout Player
17 — Form Check
18 — Workout Summary
19 — Progress
20 — Progress Photos
21 — Programs
22 — AI Coach
23 — Profile & Settings
24 — Subscription
25 — States
26 — Android Adaptations
27 — iOS Adaptations
28 — Light Theme
29 — Dark Theme
30 — Interactive Prototype
31 — Before / After
32 — Developer Handoff
33 — Product Decisions

27. Required Prototype
Связать happy path:

First launch
→ Onboarding
→ Body Metrics
→ Generating
→ Plan Preview
→ Account
→ Home
→ Scan
→ Recognition Result
→ Equipment
→ Exercise
→ Workout Player
→ Complete Set
→ Rest Timer
→ Form Check
→ Workout Summary
→ Progress
→ Add Progress Photo
→ Add Second Photo
→ Compare
→ Export Preview
→ Home updated.

Также показать ключевые error/empty/permission paths.

28. Design Gates
Не проектировать всё одновременно без review.

D1 — Research, audit, IA and design system direction.
D2 — Onboarding and Body Metrics.
D3 — Home and Navigation.
D4 — Scanner and Equipment.
D5 — Exercise and Workout Player.
D6 — Form Check and Summary.
D7 — Progress and Progress Photos.
D8 — Programs, AI Coach, Profile and Subscription.
D9 — States, accessibility, platform adaptations and final prototype.

После каждого gate:

показать screens;

показать states;

показать rationale;

перечислить unresolved product decisions;

STOP до review.

29. Definition of Done
Дизайн завершён только когда:

Home больше не является сеткой плиток.

Пользователь всегда понимает следующее действие.

Scanner визуально выражает уникальность продукта.

Onboarding показывает preview до аккаунта/paywall.

Body metrics используют удобные pickers и честные формулировки.

Workout logging удобен одной рукой.

Form Check не оценивает без видимости.

Progress объясняет реальные данные.

Progress Photos приватны и имеют полноценный compare flow.

AI встроен контекстно.

Light/dark разработаны как системы.

Android/iOS адаптации задокументированы.

Accessibility states подготовлены.

Все core empty/loading/error/permission states существуют.

Есть end-to-end clickable prototype.

Есть developer handoff с tokens, dimensions, states и interactions.

Нет придуманных функций или ложных метрик.

Начни с Design Gate D1.
После D1 предоставь результат и STOP.